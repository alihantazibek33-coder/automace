package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** АвтоКрисстал: жақын игрок болса, жанына обсидиан қойып, үстіне кристалл қойып, тез жарады. */
public class AutoCrystal extends Module {
    private final Setting range = num("Нысана қашықтығы", 5.5, 3, 6, 0.5);
    private final Setting selfSafe = num("Өзіңнен мин. қашықтық", 3.0, 1.5, 5, 0.5);
    private final Setting minHp = num("Мин. HP (тоқтау)", 6, 0, 20, 1);
    private final Setting placeObs = bool("Обсидиан қою", true);

    public AutoCrystal() {
        super("autocrystal", "АвтоКрисстал", "Игрок жанына обсидиан + кристалл қойып, тез жарады");
    }

    private static boolean isCrystal(Entity e) {
        return e.getType() == EntityType.END_CRYSTAL && e.isAlive();
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null) return;
        PlayerEntity t = Util.nearestPlayer(mc, p, range.num());
        if (t == null) return;
        if (p.getHealth() + p.getAbsorptionAmount() <= minHp.num()) return;
        if (Util.ignoredNear(mc, Util.pos(t), 9) || Util.ignoredNear(mc, Util.pos(p), 9)) return; // досқа жарылыс тимесін

        Vec3d eye = p.getEyePos();
        double safe = selfSafe.num();

        // 1) кристаллды жару
        for (Entity e : mc.world.getEntities()) {
            if (!isCrystal(e)) continue;
            if (e.distanceTo(t) > 4.5 || e.distanceTo(p) < safe) continue;
            if (Util.boxDist(eye, e.getBoundingBox()) > 4.5) continue;
            Util.aimSilent(p, Util.center(e));
            Util.attack(mc, p, e);
            return;
        }

        int crystal = Util.findHotbar(p, s -> s.isOf(Items.END_CRYSTAL));
        int obsidian = Util.findHotbar(p, s -> s.isOf(Items.OBSIDIAN));
        if (crystal < 0) return;

        BlockPos tp = t.getBlockPos();
        BlockPos bestCrystal = null, bestObsidian = null;
        double bcd = 1e9, bod = 1e9;

        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                BlockPos base = tp.add(dx, 0, dz);
                Vec3d bc = Vec3d.ofCenter(base);
                if (Math.hypot(bc.x - p.getX(), bc.z - p.getZ()) < safe && Math.abs(bc.y - p.getY()) < 2) continue;
                if (eye.distanceTo(bc.add(0, 0.5, 0)) > 4.5) continue;

                BlockState st = mc.world.getBlockState(base);
                boolean airAbove = mc.world.getBlockState(base.up()).isAir() && mc.world.getBlockState(base.up(2)).isAir();
                if (!airAbove) continue;
                double d = eye.distanceTo(bc);

                if (st.isOf(Blocks.OBSIDIAN) || st.isOf(Blocks.BEDROCK)) {
                    boolean taken = !mc.world.getEntitiesByClass(Entity.class, new Box(base.up()), AutoCrystal::isCrystal).isEmpty();
                    if (!taken && d < bcd) { bcd = d; bestCrystal = base; }
                } else if (st.isAir()) {
                    BlockPos sup = base.down();
                    if (mc.world.getBlockState(sup).isSolidBlock(mc.world, sup) && d < bod) { bod = d; bestObsidian = base; }
                }
            }
        }

        // 2) кристалл қою (бар обсидианға)
        if (bestCrystal != null) {
            Util.select(p, crystal);
            Util.aimSilent(p, Vec3d.ofCenter(bestCrystal).add(0, 0.5, 0));
            Util.place(mc, p, bestCrystal, Direction.UP);
            return;
        }
        // 3) обсидиан қою
        if (placeObs.on() && bestObsidian != null && obsidian >= 0) {
            BlockPos sup = bestObsidian.down();
            Util.select(p, obsidian);
            Util.aimSilent(p, Vec3d.ofCenter(sup).add(0, 0.5, 0));
            Util.place(mc, p, sup, Direction.UP);
        }
    }
}
