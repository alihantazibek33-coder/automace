package kz.alih.modules;

import kz.alih.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** АвтоСпринт: алға жүргенде өзі жүгіреді. */
public class AutoSprint extends Module {
    public AutoSprint() {
        super("autosprint", "АвтоСпринт", "Алға жүргенде автоматты жүгіреді");
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options != null) mc.options.sprintKey.setPressed(false);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null) return;
        mc.options.sprintKey.setPressed(mc.options.forwardKey.isPressed() && !p.isSneaking());
    }
}
