package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

import java.util.UUID;

/** АвтоЭлитраМейс: элитра + фейерверкпен көтеріліп, түсіп келе жатып броняға ауысып, мейспен ұрады. */
public class ElytraMace extends Module {
    /** Shift + ПКМ арқылы белгіленген нысана. */
    public static UUID lockedId;

    private enum Phase { TAKEOFF, CLIMB, APPROACH, STRIKE }

    private static final double REACH = 3.0;
    private static final double PREP_DIST = 9.0;
    private static final double SEARCH_RADIUS = 96.0;
    private static final double WEMBU_HEIGHT = 5.0;

    private final Setting height = num("Биіктік", 20, 10, 100, 5);
    private final Setting wembu = bool("Wembu (нысана төбесінен +5)", false);
    private final Setting shield = bool("Щитті балтамен бұзу", true);

    private UUID targetId;
    private Phase phase = Phase.TAKEOFF;
    private double startY;
    private int ticks, fireworkCd, phaseTicks, swapCd;
    private boolean afterAxe;

    public ElytraMace() {
        super("elytramace", "АвтоЭлитраМейс", "Элитра+фейерверкпен көтеріліп, түсіп броняға ауысып мейспен ұрады");
    }

    @Override
    public boolean persistEnabled() { return false; }

    private static boolean isElytra(ItemStack s) { return s.isOf(Items.ELYTRA); }

    @Override
    protected void onEnable() {
        MinecraftClient mc = Util.mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) { setEnabled(false); return; }

        Entity best = null;
        if (lockedId != null) {
            best = Util.entityById(mc, lockedId);
            if (best == null || !best.isAlive()) {
                Util.msg("Белгіленген нысана жақын жерде жоқ (.alih clear — тазалау)");
                setEnabled(false);
                return;
            }
        } else {
            double bd = SEARCH_RADIUS;
            for (Entity o : mc.world.getEntities()) {
                if (!Util.validTarget(p, o, true)) continue;
                double d = o.distanceTo(p);
                if (d < bd) { bd = d; best = o; }
            }
            if (best == null) { Util.msg("Жақын жерде нысана (моб/игрок) жоқ"); setEnabled(false); return; }
        }

        boolean elytra = isElytra(p.getEquippedStack(EquipmentSlot.CHEST)) || Util.findHotbar(p, ElytraMace::isElytra) >= 0;
        if (!elytra) { Util.msg("Хотбарда элитра жоқ"); setEnabled(false); return; }
        if (Util.findHotbar(p, s -> s.isOf(Items.MACE)) < 0) { Util.msg("Хотбарда мейс жоқ"); setEnabled(false); return; }
        if (Util.findHotbar(p, s -> s.isOf(Items.FIREWORK_ROCKET)) < 0) { Util.msg("Хотбарда фейерверк жоқ"); setEnabled(false); return; }

        targetId = best.getUuid();
        afterAxe = false;
        ticks = 0;
        fireworkCd = 0;
        swapCd = 0;
        setPhase(Phase.TAKEOFF);
        Util.msg("АвтоЭлитраМейс → нысана: " + best.getName().getString());
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = Util.mc();
        mc.options.jumpKey.setPressed(false);
        mc.options.forwardKey.setPressed(false);
    }

    private void setPhase(Phase ph) {
        phase = ph;
        phaseTicks = 0;
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ticks++;
        phaseTicks++;
        if (fireworkCd > 0) fireworkCd--;
        if (swapCd > 0) swapCd--;

        Entity e = Util.entityById(mc, targetId);
        if (!(e instanceof LivingEntity t) || !t.isAlive()) {
            if (e != null && e.getUuid().equals(lockedId)) lockedId = null;
            Util.msg(e == null ? "Нысана жоғалды, өшірілді" : "Нысана өлді, өшірілді");
            setEnabled(false);
            return;
        }

        switch (phase) {
            case TAKEOFF -> takeoff(mc, p);
            case CLIMB -> climb(mc, p, t);
            case APPROACH -> approach(mc, p, t);
            case STRIKE -> strike(mc, p, t);
        }
    }

    private void takeoff(MinecraftClient mc, ClientPlayerEntity p) {
        mc.options.forwardKey.setPressed(false);
        if (!isElytra(p.getEquippedStack(EquipmentSlot.CHEST))) {
            if (swapCd == 0) {
                int slot = Util.findHotbar(p, ElytraMace::isElytra);
                if (slot < 0) { Util.msg("Элитра табылмады, өшірілді"); setEnabled(false); return; }
                swapChest(mc, p, slot);
            }
            return;
        }
        if (p.isGliding()) {
            mc.options.jumpKey.setPressed(false);
            startY = p.getY();
            setPhase(Phase.CLIMB);
            return;
        }
        if (p.isOnGround()) {
            mc.options.jumpKey.setPressed(true);
        } else if (p.getVelocity().y < -0.05) {
            mc.options.jumpKey.setPressed(ticks % 2 == 0);
        } else {
            mc.options.jumpKey.setPressed(false);
        }
    }

    private void climb(MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        if (!p.isGliding()) { setPhase(Phase.TAKEOFF); return; }
        Util.smoothPitch(p, -80f);

        double targetTop = t.getY() + t.getHeight();
        double goalY = wembu.on() ? targetTop + WEMBU_HEIGHT : Math.max(startY, targetTop) + height.num();

        int fw = Util.findHotbar(p, s -> s.isOf(Items.FIREWORK_ROCKET));
        if (p.getY() >= goalY || fw < 0 || phaseTicks > 200) {
            setPhase(Phase.APPROACH);
            return;
        }
        if (fireworkCd == 0) {
            Util.select(p, fw);
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            p.swingHand(Hand.MAIN_HAND);
            fireworkCd = 14;
        }
    }

    private void approach(MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        if (!isElytra(p.getEquippedStack(EquipmentSlot.CHEST))) { setPhase(Phase.TAKEOFF); return; }
        if (!p.isGliding()) {
            if (p.isOnGround()) { setPhase(Phase.TAKEOFF); return; }
            mc.options.jumpKey.setPressed(ticks % 2 == 0);
        } else {
            mc.options.jumpKey.setPressed(false);
        }

        int mace = Util.findHotbar(p, s -> s.isOf(Items.MACE));
        if (mace >= 0) Util.select(p, mace);

        boolean ready;
        if (wembu.on()) {
            Util.aimAt(p, t.getX(), t.getY() + t.getHeight() + WEMBU_HEIGHT, t.getZ());
            ready = Math.hypot(t.getX() - p.getX(), t.getZ() - p.getZ()) <= 3.5;
        } else {
            Util.aimAt(p, Util.center(t));
            ready = Util.boxDist(p.getEyePos(), t.getBoundingBox()) <= PREP_DIST;
        }

        if (ready) {
            int chest = Util.findHotbar(p, s -> !isElytra(s) && p.getPreferredEquipmentSlot(s) == EquipmentSlot.CHEST);
            if (chest >= 0) swapChest(mc, p, chest);
            setPhase(Phase.STRIKE);
        }
    }

    private void strike(MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        mc.options.jumpKey.setPressed(false);
        Util.aimAt(p, Util.center(t));
        double hd = Math.hypot(t.getX() - p.getX(), t.getZ() - p.getZ());
        mc.options.forwardKey.setPressed(hd > 1.2);

        int mace = Util.findHotbar(p, s -> s.isOf(Items.MACE));
        int axe = Util.findHotbar(p, s -> s.isIn(ItemTags.AXES));
        double dist = Util.boxDist(p.getEyePos(), t.getBoundingBox());

        if (dist <= REACH + 0.2) {
            if (afterAxe) {
                if (mace >= 0) Util.select(p, mace);
                Util.attack(mc, p, t);
                afterAxe = false;
                setPhase(Phase.TAKEOFF);
                return;
            }
            if (shield.on() && t.isBlocking() && axe >= 0) {
                Util.select(p, axe);
                Util.attack(mc, p, t);
                afterAxe = true;
                return;
            }
            if (mace >= 0) Util.select(p, mace);
            if (p.getAttackCooldownProgress(0.5f) >= 0.9f || phaseTicks > 10) {
                Util.attack(mc, p, t);
                setPhase(Phase.TAKEOFF);
            }
            return;
        }
        if (p.isOnGround() && phaseTicks > 3) {
            setPhase(Phase.TAKEOFF);
        } else if (dist > 40 || phaseTicks > 200) {
            Util.msg("Нысанаға жете алмады, өшірілді");
            setEnabled(false);
        }
    }

    /** Кеудеше слотын (6) хотбар слотымен ауыстырады. */
    private void swapChest(MinecraftClient mc, ClientPlayerEntity p, int hotbarSlot) {
        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, 6, hotbarSlot, SlotActionType.SWAP, p);
        swapCd = 3;
    }
}
