package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Спид: жерде жүргенде жылдамдықты арттырады. */
public class Speed extends Module {
    private final Setting boost = num("Көбейткіш", 1.15, 1.0, 1.6, 0.05);

    public Speed() {
        super("speed", "Спид", "Жерде жүгіргенде жылдамырақ қозғалады");
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (!p.isOnGround() || p.isSneaking() || mc.currentScreen != null) return;
        boolean moving = mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed()
                || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed();
        if (!moving) return;
        Vec3d v = p.getVelocity();
        double sp = Math.hypot(v.x, v.z);
        if (sp < 0.01 || sp > 0.55) return;
        double f = boost.num();
        p.setVelocity(v.x * f, v.y, v.z * f);
    }
}
