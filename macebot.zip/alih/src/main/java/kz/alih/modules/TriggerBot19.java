package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;

/** ТБот 1.9: прицелде нысана болса, қолдағы зат толық зарядталғанда бірден ұрады. */
public class TriggerBot19 extends Module {
    private final Setting mobs = bool("Мобқа да", true);
    private final Setting crits = bool("Тек криттік (құлап келе жатқанда)", false);

    public TriggerBot19() {
        super("tbot19", "ТБот 1.9", "Прицелде нысана (игрок/моб) болса, соққы толық зарядталғанда ұрады");
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null) return;
        Entity t = mc.targetedEntity;
        if (t == null && mc.crosshairTarget instanceof net.minecraft.util.hit.EntityHitResult ehr) t = ehr.getEntity();
        if (!Util.validTarget(p, t, mobs.on())) return;
        if (p.getAttackCooldownProgress(0.5f) < 1.0f) return;
        if (crits.on() && (p.isOnGround() || p.getVelocity().y >= 0 || p.isTouchingWater())) return;
        Util.attack(mc, p, t);
    }
}
