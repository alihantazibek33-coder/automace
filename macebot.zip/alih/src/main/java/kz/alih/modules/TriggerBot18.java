package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;

import java.util.Random;

/** ТБот 1.8: 1.8 PvP үшін, прицелде нысана болса ~12-13 CPS-пен ұрады. */
public class TriggerBot18 extends Module {
    private final Setting cpsMin = num("CPS мин", 12, 5, 20, 0.5);
    private final Setting cpsMax = num("CPS макс", 13, 5, 20, 0.5);
    private final Setting mobs = bool("Мобқа да", true);

    private final Random rnd = new Random();
    private double acc;

    public TriggerBot18() {
        super("tbot18", "ТБот 1.8", "1.8 PvP: прицелдегі нысанаға ~12-13 CPS-пен ұрады");
    }

    @Override
    protected void onEnable() { acc = 0; }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null) return;
        double lo = Math.min(cpsMin.num(), cpsMax.num());
        double hi = Math.max(cpsMin.num(), cpsMax.num());
        double cps = lo + rnd.nextDouble() * (hi - lo);
        acc += cps / 20.0;

        Entity t = mc.targetedEntity;
        if (t == null && mc.crosshairTarget instanceof net.minecraft.util.hit.EntityHitResult ehr) t = ehr.getEntity();
        if (!Util.validTarget(p, t, mobs.on())) {
            acc = Math.min(acc, 1.0);
            return;
        }
        if (acc >= 1.0) {
            acc -= 1.0;
            Util.attack(mc, p, t);
        }
    }
}
