package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;

/** АвтоВеб: ең жақын игроктың аяғына паутина қояды (UHC). */
public class AutoWeb extends Module {
    private final Setting range = num("Қашықтық", 4.5, 2.0, 5.0, 0.5);
    private final Setting interval = num("Аралық (тик)", 25, 5, 100, 5);
    private final Setting autoSelect = bool("Паутинаны өзі таңдау", true);

    private int cooldown, prevSlot = -1;

    public AutoWeb() {
        super("autoweb", "АвтоВеб", "Жақын игроктың аяғына паутина қояды (UHC)");
    }

    @Override
    public void reset() { cooldown = 0; prevSlot = -1; }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (prevSlot >= 0) { Util.select(p, prevSlot); prevSlot = -1; }
        if (cooldown > 0) { cooldown--; return; }
        if (mc.currentScreen != null) return;

        PlayerEntity t = Util.nearestPlayer(mc, p, range.num());
        if (t == null) return;
        BlockPos feet = t.getBlockPos();
        if (!mc.world.getBlockState(feet).isAir()) return;

        int slot = autoSelect.on() ? Util.grab(mc, p, s -> s.isOf(Items.COBWEB))
                : (p.getMainHandStack().isOf(Items.COBWEB) ? Util.selected(p) : -1);
        if (slot < 0) return;
        int cur = Util.selected(p);
        Util.select(p, slot);
        if (Util.placeBlockAt(mc, p, feet)) {
            cooldown = Util.jitter((int) interval.num(), 8);
            if (cur != slot) prevSlot = cur;
        } else {
            Util.select(p, cur);
        }
    }
}
