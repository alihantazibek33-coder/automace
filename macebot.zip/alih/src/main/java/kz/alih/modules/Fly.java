package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** Флай: сурвайвалда ұшуға мүмкіндік береді. Көп серверде "flying is not enabled" деп кик береді. */
public class Fly extends Module {
    private final Setting speed = num("Жылдамдық", 0.05, 0.02, 0.3, 0.01);

    public Fly() {
        super("fly", "Флай", "Ұшуға мүмкіндік береді (көп серверде кик беруі мүмкін)");
    }

    @Override
    public boolean persistEnabled() { return false; }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p != null) {
            boolean keep = p.isCreative() || p.isSpectator();
            p.getAbilities().allowFlying = keep;
            if (!keep) p.getAbilities().flying = false;
            p.getAbilities().setFlySpeed(0.05f);
        }
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        p.getAbilities().allowFlying = true;
        p.getAbilities().setFlySpeed((float) speed.num());
    }
}
