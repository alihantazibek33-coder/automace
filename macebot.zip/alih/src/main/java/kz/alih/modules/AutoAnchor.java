package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * АвтоЯкор: якорьға қарап тұрсаң — светокаменьмен 1 рет зарядтайды, зияны аз қашықтыққа шегінеді,
 * якорьға ауысып ПКМ-мен жарады. Прицелді өзі якорьға бағыттайды.
 * Якорь Overworld/End-те жарылады (Незерде жарылмайды).
 */
public class AutoAnchor extends Module {
    private final Setting safeDist = num("Шегіну қашықтығы", 4.0, 3.0, 4.4, 0.2);

    private BlockPos anchor;
    private int stage, timeout;

    public AutoAnchor() {
        super("autoanchor", "АвтоЯкор", "Якорьды светокаменьмен зарядтап, шегініп, жарып жібереді");
    }

    @Override
    protected void onDisable() {
        reset();
    }

    private void reset() {
        anchor = null;
        stage = 0;
        timeout = 0;
        MinecraftClient mc = Util.mc();
        if (mc.options != null) mc.options.backKey.setPressed(false);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        mc.options.backKey.setPressed(false);

        if (anchor == null) {
            HitResult hr = mc.crosshairTarget;
            if (hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK
                    && mc.world.getBlockState(bhr.getBlockPos()).isOf(Blocks.RESPAWN_ANCHOR)) {
                anchor = bhr.getBlockPos();
                stage = 0;
                timeout = 0;
            } else {
                return;
            }
        }

        if (!mc.world.getBlockState(anchor).isOf(Blocks.RESPAWN_ANCHOR)) {
            // жарылып кетті (немесе жоғалды)
            reset();
            return;
        }
        timeout++;

        Vec3d c = Vec3d.ofCenter(anchor);
        Util.aimAt(p, c);
        double dist = p.getEyePos().distanceTo(c);
        int charges = mc.world.getBlockState(anchor).get(RespawnAnchorBlock.CHARGES);

        switch (stage) {
            case 0 -> { // светокаменьмен зарядтау
                if (charges > 0) { stage = 1; timeout = 0; return; }
                int glow = Util.findHotbar(p, s -> s.isOf(Items.GLOWSTONE));
                if (glow < 0) { Util.msg("Хотбарда светокамень жоқ"); reset(); return; }
                if (dist > 4.5 || timeout > 30) { reset(); return; }
                Util.select(p, glow);
                click(mc, p, c);
            }
            case 1 -> { // зияны аз жерге шегіну
                if (dist < safeDist.num() && timeout < 40) {
                    mc.options.backKey.setPressed(true);
                } else {
                    stage = 2;
                    timeout = 0;
                }
            }
            case 2 -> { // якорьға ауысып жару
                if (dist > 4.5) { stage = 1; return; }
                int slot = Util.findHotbar(p, s -> s.isOf(Items.RESPAWN_ANCHOR));
                if (slot < 0) {
                    int cur = Util.selected(p);
                    if (p.getInventory().getStack(cur).isOf(Items.GLOWSTONE)) {
                        slot = Util.findHotbar(p, s -> !s.isOf(Items.GLOWSTONE));
                    } else {
                        slot = cur;
                    }
                }
                if (slot >= 0) Util.select(p, slot);
                click(mc, p, c);
                if (timeout > 12) reset();
            }
            default -> reset();
        }
    }

    private void click(MinecraftClient mc, ClientPlayerEntity p, Vec3d c) {
        Vec3d eye = p.getEyePos();
        Direction side = Direction.getFacing(eye.x - c.x, eye.y - c.y, eye.z - c.z);
        Vec3d hit = c.add(side.getOffsetX() * 0.5, side.getOffsetY() * 0.5, side.getOffsetZ() * 0.5);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hit, side, anchor, false));
        p.swingHand(Hand.MAIN_HAND);
    }
}
