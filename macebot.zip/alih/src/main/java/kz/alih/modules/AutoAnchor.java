package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Util;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * АвтоЯкор: якорьға қарап тұрсаң — светокаменьмен 1 рет зарядтайды да, тұрған жеріңнен
 * якорьға (немесе басқа затқа) ауысып ПКМ-мен жарады. Прицелді өзі якорьға бағыттайды.
 * Якорь Overworld/End-те жарылады (Незерде жарылмайды).
 */
public class AutoAnchor extends Module {
    public static AutoAnchor INSTANCE;

    private final kz.alih.Setting autoPlace = bool("Авто қою (жақын нысанаға)", false);
    private final kz.alih.Setting placeRange = num("Нысана қашықтығы", 5.0, 3.0, 6.0, 0.5);

    private BlockPos anchor;
    private int stage, timeout, ticks;
    /** Сен қойған якорьлар: позиция -> қойылған тик. */
    private final java.util.Map<BlockPos, Integer> placed = new java.util.HashMap<>();

    public AutoAnchor() {
        super("autoanchor", "АвтоЯкор", "Тек өзің қойған якорьды светокаменьмен зарядтап, бірден жарады");
        INSTANCE = this;
    }

    /** UseBlockCallback шақырады: ойыншы якорь қойды. */
    public void notePlaced(BlockPos pos) {
        placed.put(pos.toImmutable(), ticks);
    }

    @Override
    public void reset() {
        placed.clear();
        anchor = null;
        stage = 0;
        timeout = 0;
    }

    @Override
    protected void onDisable() {
        anchor = null;
        stage = 0;
        timeout = 0;
    }

    private void reset2() {
        anchor = null;
        stage = 0;
        timeout = 0;
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ticks++;
        // өзің қойған якорьларды ғана қарастырады; жоғалғандарын тазалайды
        placed.entrySet().removeIf(e ->
                !mc.world.getBlockState(e.getKey()).isOf(Blocks.RESPAWN_ANCHOR) && ticks - e.getValue() > 40);

        if (anchor == null && autoPlace.on() && placed.isEmpty() && mc.currentScreen == null) {
            tryAutoPlace(mc, p);
        }

        if (anchor == null) {
            BlockPos best = null;
            int bt = -1;
            for (java.util.Map.Entry<BlockPos, Integer> e : placed.entrySet()) {
                BlockPos b = e.getKey();
                if (!mc.world.getBlockState(b).isOf(Blocks.RESPAWN_ANCHOR)) continue;
                if (p.getEyePos().distanceTo(Vec3d.ofCenter(b)) > 4.6) continue;
                if (e.getValue() > bt) { bt = e.getValue(); best = b; }   // ең соңғы қойғаны
            }
            if (best == null) return;
            anchor = best;
            stage = 0;
            timeout = 0;
        }

        if (!mc.world.getBlockState(anchor).isOf(Blocks.RESPAWN_ANCHOR)) {
            placed.remove(anchor);
            reset2(); // жарылып кетті (немесе жоғалды)
            return;
        }
        timeout++;

        Vec3d c = Vec3d.ofCenter(anchor);
        if (Util.ignoredNear(mc, c, 9)) { placed.remove(anchor); reset2(); return; } // досқа жарылыс тимесін
        Util.aimAt(p, c);
        double dist = p.getEyePos().distanceTo(c);
        if (dist > 4.6) { reset2(); return; }
        int charges = mc.world.getBlockState(anchor).get(RespawnAnchorBlock.CHARGES);

        if (stage == 0) { // светокаменьмен зарядтау
            if (charges > 0) { stage = 1; timeout = 0; return; }
            int glow = Util.grab(mc, p, s -> s.isOf(Items.GLOWSTONE));
            if (glow < 0) { Util.msg("Светокамень жоқ"); placed.remove(anchor); reset2(); return; }
            if (timeout > 30) { placed.remove(anchor); reset2(); return; }
            Util.select(p, glow);
            click(mc, p, c);
        } else { // жару: якорьға ауысып ПКМ
            int slot = Util.findHotbar(p, s -> s.isOf(Items.RESPAWN_ANCHOR));
            if (slot < 0) {
                int cur = Util.selected(p);
                if (p.getInventory().getStack(cur).isOf(Items.GLOWSTONE)) {
                    slot = Util.findHotbar(p, s -> !s.isOf(Items.GLOWSTONE));
                } else {
                    slot = cur;
                }
            }
            if (slot >= 0) Util.select(p, slot);
            click(mc, p, c);
            if (timeout > 12) { placed.remove(anchor); reset2(); }
        }
    }

    /** Нысананың жанына (аяғының қасына) якорь қояды; келесі тиктерде өзі зарядтап жарады. */
    private void tryAutoPlace(MinecraftClient mc, ClientPlayerEntity p) {
        net.minecraft.entity.player.PlayerEntity t = Util.nearestPlayer(mc, p, placeRange.num());
        if (t == null) return;
        if (Util.ignoredNear(mc, Util.pos(t), 9) || Util.ignoredNear(mc, Util.pos(p), 9)) return;
        if (!Util.hasInInventory(p, s -> s.isOf(Items.RESPAWN_ANCHOR))) return;

        BlockPos tp = t.getBlockPos();
        Vec3d eye = p.getEyePos();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                BlockPos pos = tp.add(dx, 0, dz);
                BlockPos sup = pos.down();
                if (!mc.world.getBlockState(pos).isAir() || !mc.world.getBlockState(pos.up()).isAir()) continue;
                if (!mc.world.getBlockState(sup).isSolidBlock(mc.world, sup)) continue;
                Vec3d c = Vec3d.ofCenter(pos);
                double d = eye.distanceTo(c);
                if (d > 4.5 || Math.hypot(c.x - p.getX(), c.z - p.getZ()) < 2.5) continue;   // өзіңе жақын емес
                if (d < bd) { bd = d; best = pos; }
            }
        }
        if (best == null) return;
        int slot = Util.grab(mc, p, s -> s.isOf(Items.RESPAWN_ANCHOR));
        if (slot < 0) return;
        Util.select(p, slot);
        Util.place(mc, p, best.down(), net.minecraft.util.math.Direction.UP);
        notePlaced(best);
    }

    private void click(MinecraftClient mc, ClientPlayerEntity p, Vec3d c) {
        Vec3d eye = p.getEyePos();
        Direction side = Direction.getFacing(eye.x - c.x, eye.y - c.y, eye.z - c.z);
        Vec3d hit = c.add(side.getOffsetX() * 0.5, side.getOffsetY() * 0.5, side.getOffsetZ() * 0.5);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hit, side, anchor, false));
        p.swingHand(Hand.MAIN_HAND);
    }
}
