package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** Зум: FOV-ты кішірейтіп, алысты жақындатады. Өшкенде FOV бұрынғы күйіне қайтады. */
public class Zoom extends Module {
    private final Setting fov = num("Зум FOV", 30, 30, 70, 5);
    private Integer original;

    public Zoom() {
        super("zoom", "Зум", "Алысты жақындатады (FOV кішірейеді)");
    }

    @Override
    public boolean persistEnabled() { return false; }

    private void restore(MinecraftClient mc) {
        if (original != null && mc.options != null) mc.options.getFov().setValue(original);
        original = null;
    }

    @Override
    public void reset() { restore(MinecraftClient.getInstance()); setEnabled(false); }

    @Override
    protected void onDisable() { restore(MinecraftClient.getInstance()); }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (original == null) original = mc.options.getFov().getValue();
        mc.options.getFov().setValue((int) fov.num());
    }
}
