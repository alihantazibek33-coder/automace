package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * АвтоМайн: алдындағы блокты өзі қазып, тоннель салып жүреді. Ең дұрыс құралды өзі таңдайды.
 * "Тек руда" режимінде жақындағы рудаға бұрылып, соны қазады. Лава көрінсе тоқтайды.
 */
public class AutoMine extends Module {
    private final Setting mode = mode("Режим", 0, "Алға (тоннель)", "Жақын руда + тоннель");
    private final Setting walk = bool("Алға жүру", true);
    private final Setting tool = bool("Құралды өзі таңдау", true);
    private final Setting oreRadius = num("Руда іздеу радиусы", 5, 2, 8, 1);

    public AutoMine() {
        super("automine", "АвтоМайн", "Алдыңдағы блокты өзі қазып, тоннель салып жүреді (руда режимі бар)");
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = Util.mc();
        if (mc.options != null) {
            mc.options.attackKey.setPressed(false);
            mc.options.forwardKey.setPressed(false);
            mc.options.jumpKey.setPressed(false);
        }
    }

    private static boolean isOre(BlockState st) {
        String id = Registries.BLOCK.getId(st.getBlock()).getPath();
        return id.endsWith("_ore") || id.equals("ancient_debris");
    }

    private boolean solid(MinecraftClient mc, BlockPos pos) {
        return mc.world.getBlockState(pos).isSolidBlock(mc.world, pos);
    }

    private boolean lava(MinecraftClient mc, BlockPos pos) {
        return mc.world.getBlockState(pos).getFluidState().isIn(FluidTags.LAVA);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null) {
            mc.options.attackKey.setPressed(false);
            mc.options.forwardKey.setPressed(false);
            return;
        }

        double rad = Math.toRadians(p.getYaw());
        double fx = -Math.sin(rad), fz = Math.cos(rad);
        BlockPos feet = p.getBlockPos();
        BlockPos aheadFeet = BlockPos.ofFloored(p.getX() + fx * 1.0, p.getY(), p.getZ() + fz * 1.0);
        BlockPos aheadHead = aheadFeet.up();
        BlockPos aheadFeet2 = BlockPos.ofFloored(p.getX() + fx * 2.0, p.getY(), p.getZ() + fz * 2.0);

        // лава қауіпі: алда немесе астында лава болса тоқтайды
        if (lava(mc, aheadFeet) || lava(mc, aheadHead) || lava(mc, aheadFeet2) || lava(mc, aheadFeet2.up())
                || lava(mc, feet.down()) || lava(mc, aheadFeet.down())) {
            Util.msg("Лава көрінді. АвтоМайн тоқтатылды");
            setEnabled(false);
            return;
        }

        // бағыт: руда режимінде жақындағы рудаға, әйтпесе тоннель блогына
        Vec3d aim = null;
        if (mode.mode() == 1) {
            int r = (int) oreRadius.num();
            double bd = Double.MAX_VALUE;
            BlockPos best = null;
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    for (int dz = -r; dz <= r; dz++) {
                        BlockPos pos = feet.add(dx, dy, dz);
                        if (!isOre(mc.world.getBlockState(pos))) continue;
                        double d = Vec3d.ofCenter(pos).squaredDistanceTo(p.getEyePos());
                        if (d < bd) { bd = d; best = pos; }
                    }
                }
            }
            if (best != null) aim = Vec3d.ofCenter(best);
        }
        if (aim == null) {
            if (solid(mc, aheadHead)) aim = Vec3d.ofCenter(aheadHead);
            else if (solid(mc, aheadFeet)) aim = Vec3d.ofCenter(aheadFeet);
        }

        if (aim != null) {
            Util.aimAt(p, aim);
            mc.options.forwardKey.setPressed(false);
            // құралды таңдау (қазылатын блокқа қарай ең жылдам)
            HitResult hr = mc.crosshairTarget;
            if (tool.on() && hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
                BlockState st = mc.world.getBlockState(bhr.getBlockPos());
                int best = Util.selected(p);
                float bm = p.getInventory().getStack(best).getMiningSpeedMultiplier(st);
                for (int i = 0; i < 9; i++) {
                    float m = p.getInventory().getStack(i).getMiningSpeedMultiplier(st);
                    if (m > bm) { bm = m; best = i; }
                }
                Util.select(p, best);
            }
            mc.options.attackKey.setPressed(hr != null && hr.getType() == HitResult.Type.BLOCK);
        } else {
            mc.options.attackKey.setPressed(false);
            mc.options.forwardKey.setPressed(walk.on());
            // алдында 1 блок көтерілу керек болса секіреді
            mc.options.jumpKey.setPressed(p.horizontalCollision && p.isOnGround());
        }
    }
}
