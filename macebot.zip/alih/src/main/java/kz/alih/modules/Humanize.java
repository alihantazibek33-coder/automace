package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * АдамшаБұру: автоматты бұрулар нақты тінтуір қозғалысына ұқсасын:
 * 1) тінтуір сезімталдығына квантау (қадам нақты тінтуір қадамының еселігі);
 * 2) silent rotation: ұрыс функцияларында (КиллАура, АвтоЛук, АвтоКрисстал) камера бұрылмайды,
 *    серверге ғана бұрыш жіберіледі.
 */
public class Humanize extends Module {
    public static Humanize INSTANCE;

    private final Setting silent = bool("Silent rotation (камера бұрылмайды)", true);
    private final Setting quantize = bool("Тінтуір сезімталдығына квантау", true);

    public Humanize() {
        super("humanize", "АдамшаБұру", "Бұрулар нақты тінтуірдей: квантау + silent rotation");
        INSTANCE = this;
    }

    @Override
    public boolean defaultEnabled() { return true; }

    public static boolean silentOn() {
        Humanize h = INSTANCE;
        return h != null && h.enabled && h.silent.on();
    }

    public static boolean quantizeOn() {
        Humanize h = INSTANCE;
        return h != null && h.enabled && h.quantize.on();
    }

    /** Тінтуірдің ең кіші бұру қадамы (градус). */
    public static float step() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return 0f;
        double s = mc.options.getMouseSensitivity().getValue();
        double f = s * 0.6 + 0.2;
        return (float) (f * f * f * 8.0 * 0.15);
    }

    /** Бұру өзгерісін тінтуір қадамына жуықтайды. */
    public static float q(float delta) {
        if (!quantizeOn()) return delta;
        float st = step();
        if (st <= 0.0001f) return delta;
        return Math.round(delta / st) * st;
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        // әрекет Util.aimAt / Util.aimSilent ішінде
    }
}
