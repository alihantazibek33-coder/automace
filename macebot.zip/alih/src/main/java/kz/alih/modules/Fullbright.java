package kz.alih.modules;

import kz.alih.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Фулбрайт: қараңғыда да жарық көрінеді (клиенттегі night vision эффекті). */
public class Fullbright extends Module {
    private int ticks;

    public Fullbright() {
        super("fullbright", "Фулбрайт", "Қараңғыда да жарық көреді (night vision)");
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (ticks++ % 100 == 0 || !p.hasStatusEffect(StatusEffects.NIGHT_VISION)) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
        }
    }
}
