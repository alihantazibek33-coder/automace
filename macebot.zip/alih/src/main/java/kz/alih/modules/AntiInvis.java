package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.HashSet;
import java.util.Set;

/** АнтиИнвиз: көрінбейтін (invisibility) игрок/мобтарды қалыпты көрінетін қылады (клиентте). */
public class AntiInvis extends Module {
    private final Setting mobs = bool("Мобқа да", true);

    private final Set<Integer> changed = new HashSet<>();

    public AntiInvis() {
        super("antiinvis", "АнтиИнвиз", "Невидимость ішіндегі игрок/мобтар қалыпты көрінеді");
    }

    @Override
    public void reset() { changed.clear(); }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null) {
            for (Entity e : mc.world.getEntities()) {
                if (changed.contains(e.getId())) e.setInvisible(true);
            }
        }
        changed.clear();
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        for (Entity e : mc.world.getEntities()) {
            if (!e.isInvisible() || e == p) continue;
            boolean ok = e instanceof PlayerEntity || (mobs.on() && e instanceof LivingEntity);
            if (!ok) continue;
            e.setInvisible(false);
            changed.add(e.getId());
        }
    }
}
