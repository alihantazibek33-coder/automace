package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.Random;

/**
 * АвтоБлок: қарап тұрған жағыңа қарай блок қойып кете береді.
 * 1) Көпір: астына қояды, әр қойғанда секіреді (жылдамдық үшін).
 * 2) Баспалдақ+жабу: 2–3 блок көпір, содан кейін 2 блок жоғары көтеріліп (төбеге де қояды), қайталайды.
 * 3) Жоғары көтерілу: әр қойғанда жоғарылай береді (мұнара).
 * Қосқанда қолыңдағы блок түрі таңдалады.
 */
public class AutoBlock extends Module {
    private final Setting mode = mode("Режим", 0, "Көпір (секіріп)", "Баспалдақ+жабу", "Жоғары көтерілу");
    private final Setting autoWalk = bool("Автожүріс (алға)", true);

    private final Random rnd = new Random();
    private Item blockType;
    private BlockPos baseSupport;
    private int phase, count, goal = 2, up, recentPlaced;

    public AutoBlock() {
        super("autoblock", "АвтоБлок", "Қарап тұрған жағыңа тез блок қояды (көпір / баспалдақ / мұнара)");
    }

    @Override
    protected void onEnable() {
        MinecraftClient mc = Util.mc();
        blockType = null;
        if (mc.player != null) {
            ItemStack hs = mc.player.getMainHandStack();
            if (hs.getItem() instanceof BlockItem) blockType = hs.getItem();
        }
        phase = 0; count = 0; up = 0; goal = 2 + rnd.nextInt(2); baseSupport = null;
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = Util.mc();
        if (mc.options != null) {
            mc.options.forwardKey.setPressed(false);
            mc.options.jumpKey.setPressed(false);
        }
    }

    @Override
    public void reset() { baseSupport = null; }

    private int blockSlot(MinecraftClient mc, ClientPlayerEntity p) {
        int slot = -1;
        if (blockType != null) {
            final Item t = blockType;
            slot = Util.grab(mc, p, s -> s.isOf(t));
        }
        if (slot < 0) slot = Util.grab(mc, p, s -> Util.isBuildBlock(mc.world, s));
        return slot;
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null) return;
        int slot = blockSlot(mc, p);
        if (slot < 0) {
            Util.msg("Блок жоқ, тоқтатылды");
            setEnabled(false);
            return;
        }
        Util.select(p, slot);
        if (recentPlaced > 0) recentPlaced--;

        switch (mode.mode()) {
            case 0 -> bridge(mc, p, true);
            case 1 -> stairs(mc, p);
            default -> {
                mc.options.forwardKey.setPressed(false);
                pillar(mc, p);
            }
        }
    }

    private void stairs(MinecraftClient mc, ClientPlayerEntity p) {
        if (phase == 0) {
            if (bridge(mc, p, true)) {
                if (++count >= goal) { phase = 1; up = 0; count = 0; }
            }
        } else {
            mc.options.forwardKey.setPressed(false);
            if (pillar(mc, p)) up++;
            BlockPos ceil = p.getBlockPos().up(2);           // төбеге де қояды (қолдау болса)
            BlockState cs = mc.world.getBlockState(ceil);
            if (cs.isAir()) placeAt(mc, p, ceil);
            if (up >= 2) { phase = 0; goal = 2 + rnd.nextInt(2); }
        }
    }

    /** Астына көпір қояды; true — осы тик блок қойылды. */
    private boolean bridge(MinecraftClient mc, ClientPlayerEntity p, boolean jump) {
        double rad = Math.toRadians(p.getYaw());
        double fx = -Math.sin(rad), fz = Math.cos(rad);
        if (autoWalk.on()) mc.options.forwardKey.setPressed(true);

        BlockPos tgt = BlockPos.ofFloored(p.getX() + fx * 0.4, p.getY() - 1.0, p.getZ() + fz * 0.4);
        BlockState st = mc.world.getBlockState(tgt);
        boolean placed = false;
        if (st.isAir() || st.isReplaceable()) placed = placeAt(mc, p, tgt);
        if (placed) recentPlaced = 3;
        mc.options.jumpKey.setPressed(jump && p.isOnGround() && recentPlaced > 0);
        return placed;
    }

    /** Секіріп, ауада тұрғанда астына блок қойып көтеріледі. true — блок қойылды. */
    private boolean pillar(MinecraftClient mc, ClientPlayerEntity p) {
        if (p.isOnGround()) {
            baseSupport = BlockPos.ofFloored(p.getX(), p.getY() - 0.5, p.getZ());
            mc.options.jumpKey.setPressed(true);
            return false;
        }
        mc.options.jumpKey.setPressed(false);
        if (baseSupport != null && p.getY() >= baseSupport.getY() + 2.0) {
            BlockState above = mc.world.getBlockState(baseSupport.up());
            if (above.isAir() || above.isReplaceable()) {
                Util.place(mc, p, baseSupport, Direction.UP);
                return true;
            }
        }
        return false;
    }

    private boolean placeAt(MinecraftClient mc, ClientPlayerEntity p, BlockPos pos) {
        Direction[] dirs = { Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP };
        for (Direction d : dirs) {
            BlockPos n = pos.offset(d);
            BlockState ns = mc.world.getBlockState(n);
            if (!ns.isAir() && ns.getFluidState().isEmpty() && !ns.isReplaceable()) {
                Util.place(mc, p, n, d.getOpposite());
                return true;
            }
        }
        return false;
    }
}
