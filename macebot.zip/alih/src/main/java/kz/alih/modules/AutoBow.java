package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

/** АвтоЛук: лукпен көздегенде прицелді нысанаға өзі апарады (қозғалысты және жебенің түсуін ескереді). */
public class AutoBow extends Module {
    private final Setting fov = num("FOV (°)", 60, 10, 180, 5);
    private final Setting range = num("Қашықтық", 60, 10, 100, 5);
    private final Setting mobs = bool("Мобқа да", true);

    public AutoBow() {
        super("autobow", "АвтоЛук", "Лукпен көздегенде прицелді өзі апарып береді");
    }

    /** Нысананың қозғалысы мен гравитацияны ескерген көздеу нүктесі. */
    public static Vec3d lead(ClientPlayerEntity p, Entity t, double speed) {
        Vec3d eye = p.getEyePos();
        Vec3d c = Util.center(t);
        Vec3d v = Util.vel(t);
        double sp = Math.max(speed, 0.5);
        double ticks = eye.distanceTo(c) / sp;
        for (int i = 0; i < 3; i++) {
            Vec3d fut = c.add(v.multiply(ticks));
            ticks = eye.distanceTo(fut) / sp;
        }
        Vec3d fut = c.add(v.multiply(ticks));
        double drop = 0.5 * 0.05 * ticks * ticks * 1.1;
        return fut.add(0, drop, 0);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ItemStack st = p.getMainHandStack();
        boolean bow = st.isOf(Items.BOW);
        boolean xbow = st.isOf(Items.CROSSBOW);
        if (!(bow || xbow) || !p.isUsingItem()) return;

        Entity best = null;
        double ba = fov.num();
        for (Entity e : mc.world.getEntities()) {
            if (!Util.validTarget(p, e, mobs.on())) continue;
            if (e.distanceTo(p) > range.num()) continue;
            double a = Util.angleTo(p, Util.center(e));
            if (a < ba) { ba = a; best = e; }
        }
        if (best == null) return;
        Util.aimSilent(p, lead(p, best, xbow ? 3.15 : 3.0));
    }
}
