package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * XRay (контур): таңдалған блоктарды (руда, сундук, обсидиан...) қабырға арқылы түсті сызық-контурмен көрсетеді.
 * Блоктарды өзгертпейді, экранға 3D→2D жобалап сызады. Қосымша блок: .alih xray add <блок_id>.
 */
public class XRay extends Module {
    public static XRay INSTANCE;
    /** Қолмен қосылған блоктар (id path, мысалы diamond_block). */
    public static final Set<String> CUSTOM = new LinkedHashSet<>();

    private final Setting ores = bool("Руда (бәрі)", true);
    private final Setting storage = bool("Сақтау блоктары (сундук, бочка, шалкер)", true);
    private final Setting obsidian = bool("Обсидиан / якорь", true);
    private final Setting spawner = bool("Спавнер", true);
    private final Setting range = num("Қашықтық (блок)", 64, 16, 128, 16);
    private final Setting maxBoxes = num("Макс. контур саны", 150, 30, 400, 10);
    private final Setting light = bool("Жарық (night vision)", false);

    private Set<Block> targets = new HashSet<>();
    private final Map<Long, List<BlockPos>> cache = new HashMap<>();
    private final Map<Long, Integer> scannedAt = new HashMap<>();
    private final Map<Block, Integer> colors = new HashMap<>();
    private List<BlockPos> visible = new ArrayList<>();
    private List<Integer> visibleColors = new ArrayList<>();
    private String lastSig = "";
    private int ticks;

    public XRay() {
        super("xray", "XRay", "Таңдаған блоктарды қабырға арқылы сызық-контурмен көрсетеді");
        INSTANCE = this;
    }

    public static boolean addCustom(String raw) {
        String id = raw.toLowerCase().replace("minecraft:", "").trim();
        if (!Registries.BLOCK.containsId(Identifier.ofVanilla(id))) return false;
        CUSTOM.add(id);
        return true;
    }

    private String signature() {
        return ores.on() + "|" + storage.on() + "|" + obsidian.on() + "|" + spawner.on() + "|" + CUSTOM;
    }

    private void rebuild() {
        Set<Block> out = new HashSet<>();
        colors.clear();
        for (Block b : Registries.BLOCK) {
            String id = Registries.BLOCK.getId(b).getPath();
            boolean take = false;
            int color = 0xFFFFFFFF;
            if (ores.on() && (id.endsWith("_ore") || id.equals("ancient_debris"))) {
                take = true;
                if (id.contains("diamond")) color = 0xFF3DE4FF;
                else if (id.contains("emerald")) color = 0xFF3DFF6B;
                else if (id.contains("gold")) color = 0xFFFFD83D;
                else if (id.contains("iron")) color = 0xFFE0B090;
                else if (id.contains("coal")) color = 0xFF9A9A9A;
                else if (id.contains("redstone")) color = 0xFFFF3B3B;
                else if (id.contains("lapis")) color = 0xFF3B6BFF;
                else if (id.contains("copper")) color = 0xFFFF9A4D;
                else if (id.contains("debris")) color = 0xFFB05A3A;
                else color = 0xFFFFFFFF;
            }
            if (storage.on() && (id.equals("chest") || id.equals("trapped_chest") || id.equals("barrel")
                    || id.equals("ender_chest") || id.endsWith("shulker_box"))) { take = true; color = 0xFFFFC857; }
            if (obsidian.on() && (id.equals("obsidian") || id.equals("crying_obsidian") || id.equals("respawn_anchor"))) {
                take = true; color = 0xFFB04DFF;
            }
            if (spawner.on() && (id.equals("spawner") || id.equals("trial_spawner"))) { take = true; color = 0xFFFF2D2D; }
            if (CUSTOM.contains(id)) { take = true; color = 0xFFFFFFFF; }
            if (take) { out.add(b); colors.put(b, color); }
        }
        targets = out;
        cache.clear();
        scannedAt.clear();
        lastSig = signature();
    }

    @Override
    protected void onEnable() { rebuild(); }

    @Override
    protected void onDisable() {
        cache.clear();
        scannedAt.clear();
        visible = new ArrayList<>();
        visibleColors = new ArrayList<>();
        MinecraftClient mc = Util.mc();
        if (mc.player != null && light.on()) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
    }

    @Override
    public void reset() {
        cache.clear();
        scannedAt.clear();
        visible = new ArrayList<>();
        visibleColors = new ArrayList<>();
    }

    // ================================================================ скан

    private void scanChunk(MinecraftClient mc, int cx, int cz) {
        long key = ChunkPos.toLong(cx, cz);
        scannedAt.put(key, ticks);
        Chunk ch = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
        if (!(ch instanceof WorldChunk wc)) { cache.remove(key); return; }
        List<BlockPos> out = new ArrayList<>();
        ChunkSection[] secs = wc.getSectionArray();
        int bottom = wc.getBottomY();
        for (int i = 0; i < secs.length; i++) {
            ChunkSection s = secs[i];
            if (s == null || s.isEmpty()) continue;
            if (!s.hasAny(st -> targets.contains(st.getBlock()))) continue;
            int y0 = bottom + i * 16;
            for (int x = 0; x < 16; x++) {
                for (int y = 0; y < 16; y++) {
                    for (int z = 0; z < 16; z++) {
                        if (targets.contains(s.getBlockState(x, y, z).getBlock())) {
                            out.add(new BlockPos(cx * 16 + x, y0 + y, cz * 16 + z));
                        }
                    }
                }
            }
        }
        cache.put(key, out);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ticks++;
        if (!signature().equals(lastSig)) rebuild();

        int r = (int) Math.ceil(range.num() / 16.0);
        int pcx = p.getBlockPos().getX() >> 4, pcz = p.getBlockPos().getZ() >> 4;

        // жақын чанктардан бастап, әр тикте ең көбі 3 чанк (қайта скан — 120 тикте бір)
        int budget = 3;
        for (int ring = 0; ring <= r && budget > 0; ring++) {
            for (int cx = pcx - ring; cx <= pcx + ring && budget > 0; cx++) {
                for (int cz = pcz - ring; cz <= pcz + ring && budget > 0; cz++) {
                    if (Math.max(Math.abs(cx - pcx), Math.abs(cz - pcz)) != ring) continue;
                    Integer last = scannedAt.get(ChunkPos.toLong(cx, cz));
                    if (last == null || ticks - last > 120) {
                        scanChunk(mc, cx, cz);
                        budget--;
                    }
                }
            }
        }

        if (ticks % 10 == 0) refreshVisible(mc, p);

        if (light.on() && (ticks % 100 == 1 || !p.hasStatusEffect(StatusEffects.NIGHT_VISION))) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
        }
    }

    private void refreshVisible(MinecraftClient mc, ClientPlayerEntity p) {
        double r2 = range.num() * range.num();
        Vec3d eye = p.getEyePos();
        List<BlockPos> all = new ArrayList<>();
        for (List<BlockPos> l : cache.values()) {
            for (BlockPos b : l) {
                if (Vec3d.ofCenter(b).squaredDistanceTo(eye) <= r2) all.add(b);
            }
        }
        all.sort((a, b) -> Double.compare(Vec3d.ofCenter(a).squaredDistanceTo(eye), Vec3d.ofCenter(b).squaredDistanceTo(eye)));
        List<BlockPos> vis = new ArrayList<>();
        List<Integer> cols = new ArrayList<>();
        int max = (int) maxBoxes.num();
        for (BlockPos b : all) {
            if (vis.size() >= max) break;
            Block blk = mc.world.getBlockState(b).getBlock();      // әлі сол блок па (қазылып кетпеген бе)
            if (!targets.contains(blk)) continue;
            vis.add(b);
            cols.add(colors.getOrDefault(blk, 0xFFFFFFFF));
        }
        visible = vis;
        visibleColors = cols;
    }

    // ================================================================ сызу (HUD)

    public static void renderHud(DrawContext ctx) {
        XRay x = INSTANCE;
        if (x == null || !x.enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        x.draw(ctx, mc, mc.player);
    }

    private void draw(DrawContext ctx, MinecraftClient mc, ClientPlayerEntity p) {
        List<BlockPos> list = visible;
        if (list.isEmpty()) return;

        Vec3d eye = p.getEyePos();
        double yr = Math.toRadians(p.getYaw()), pr = Math.toRadians(p.getPitch());
        double cy = Math.cos(yr), sy = Math.sin(yr), cp = Math.cos(pr), sp = Math.sin(pr);
        Vec3d f = new Vec3d(-sy * cp, -sp, cy * cp);
        Vec3d r = new Vec3d(-cy, 0, -sy);
        Vec3d u = r.crossProduct(f);

        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        double tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        double aspect = (double) w / h;

        double[][] cam = new double[8][3];
        for (int n = 0; n < list.size(); n++) {
            BlockPos b = list.get(n);
            int color = visibleColors.get(n);
            for (int i = 0; i < 8; i++) {
                Vec3d d = new Vec3d(b.getX() + (i & 1) - eye.x, b.getY() + ((i >> 1) & 1) - eye.y, b.getZ() + ((i >> 2) & 1) - eye.z);
                cam[i][0] = d.dotProduct(r);
                cam[i][1] = d.dotProduct(u);
                cam[i][2] = d.dotProduct(f);
            }
            for (int i = 0; i < 8; i++) {
                for (int bit = 1; bit <= 4; bit <<= 1) {
                    if ((i & bit) != 0) continue;
                    line(ctx, cam[i], cam[i | bit], color, w, h, tanHalf, aspect);
                }
            }
        }
    }

    private static void line(DrawContext ctx, double[] a, double[] b, int color, int w, int h, double tanHalf, double aspect) {
        double near = 0.1;
        double ax = a[0], ay = a[1], az = a[2], bx = b[0], by = b[1], bz = b[2];
        if (az < near && bz < near) return;
        if (az < near) {
            double t = (near - az) / (bz - az);
            ax += (bx - ax) * t; ay += (by - ay) * t; az = near;
        } else if (bz < near) {
            double t = (near - bz) / (az - bz);
            bx += (ax - bx) * t; by += (ay - by) * t; bz = near;
        }
        double x1 = ((ax / az) / (tanHalf * aspect) * 0.5 + 0.5) * w, y1 = (0.5 - (ay / az) / tanHalf * 0.5) * h;
        double x2 = ((bx / bz) / (tanHalf * aspect) * 0.5 + 0.5) * w, y2 = (0.5 - (by / bz) / tanHalf * 0.5) * h;

        if ((x1 < -50 && x2 < -50) || (x1 > w + 50 && x2 > w + 50) || (y1 < -50 && y2 < -50) || (y1 > h + 50 && y2 > h + 50)) return;
        double dx = x2 - x1, dy = y2 - y1;
        int steps = (int) Math.max(Math.abs(dx), Math.abs(dy));
        if (steps > 900) return;
        steps = Math.max(1, steps);
        for (int i = 0; i <= steps; i += 2) {
            double t = i / (double) steps;
            int px = (int) (x1 + dx * t), py = (int) (y1 + dy * t);
            if (px < 0 || py < 0 || px >= w || py >= h) continue;
            ctx.fill(px, py, px + 2, py + 2, color);
        }
    }
}
