package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * XRay (жарқыл): таңдалған блоктарды (руда, сундук, обсидиан...) қабырға арқылы түсті жарқылмен көрсетеді (экранға салынады).
 * Блоктарды өзгертпейді, экранға 3D→2D жобалап сызады. Қосымша блок: .alih xray add <блок_id>.
 */
public class XRay extends Module {
    public static XRay INSTANCE;
    /** Қолмен қосылған блоктар (id path, мысалы diamond_block). */
    public static final Set<String> CUSTOM = new LinkedHashSet<>();

    private final Setting ores = bool("Руда (бәрі)", true);
    private final Setting storage = bool("Сақтау блоктары (сундук, бочка, шалкер)", true);
    private final Setting obsidian = bool("Обсидиан / якорь", true);
    private final Setting spawner = bool("Спавнер", true);
    private final Setting range = num("Қашықтық (блок)", 100, 20, 200, 20);
    private final Setting maxBoxes = num("Макс. контур саны", 150, 30, 400, 10);
    private final Setting light = bool("Жарық (night vision)", false);

    private Set<Block> targets = new HashSet<>();
    private final Map<Long, List<BlockPos>> cache = new HashMap<>();
    private final Map<Long, Integer> scannedAt = new HashMap<>();
    private final Map<Block, Integer> colors = new HashMap<>();
    private List<BlockPos> visible = new ArrayList<>();
    private List<Integer> visibleColors = new ArrayList<>();
    private String lastSig = "";
    private int ticks;
    private boolean lightAdded;

    public XRay() {
        super("xray", "XRay", "Таңдаған блоктарды қабырға арқылы жарқыратып көрсетеді (200 блокқа дейін)");
        INSTANCE = this;
    }

    public static boolean addCustom(String raw) {
        String id = raw.toLowerCase().replace("minecraft:", "").trim();
        if (!Registries.BLOCK.containsId(Identifier.ofVanilla(id))) return false;
        CUSTOM.add(id);
        return true;
    }

    private String signature() {
        return ores.on() + "|" + storage.on() + "|" + obsidian.on() + "|" + spawner.on() + "|" + CUSTOM;
    }

    private void rebuild() {
        Set<Block> out = new HashSet<>();
        colors.clear();
        for (Block b : Registries.BLOCK) {
            String id = Registries.BLOCK.getId(b).getPath();
            boolean take = false;
            int color = 0xFFFFFFFF;
            if (ores.on() && (id.endsWith("_ore") || id.equals("ancient_debris"))) {
                take = true;
                if (id.contains("diamond")) color = 0xFF3DE4FF;
                else if (id.contains("emerald")) color = 0xFF3DFF6B;
                else if (id.contains("gold")) color = 0xFFFFD83D;
                else if (id.contains("iron")) color = 0xFFE0B090;
                else if (id.contains("coal")) color = 0xFF9A9A9A;
                else if (id.contains("redstone")) color = 0xFFFF3B3B;
                else if (id.contains("lapis")) color = 0xFF3B6BFF;
                else if (id.contains("copper")) color = 0xFFFF9A4D;
                else if (id.contains("debris")) color = 0xFFB05A3A;
                else color = 0xFFFFFFFF;
            }
            if (storage.on() && (id.equals("chest") || id.equals("trapped_chest") || id.equals("barrel")
                    || id.equals("ender_chest") || id.endsWith("shulker_box"))) { take = true; color = 0xFFFFC857; }
            if (obsidian.on() && (id.equals("obsidian") || id.equals("crying_obsidian") || id.equals("respawn_anchor"))) {
                take = true; color = 0xFFB04DFF;
            }
            if (spawner.on() && (id.equals("spawner") || id.equals("trial_spawner"))) { take = true; color = 0xFFFF2D2D; }
            if (CUSTOM.contains(id)) { take = true; color = 0xFFFFFFFF; }
            if (take) { out.add(b); colors.put(b, color); }
        }
        targets = out;
        cache.clear();
        scannedAt.clear();
        lastSig = signature();
    }

    @Override
    protected void onEnable() { rebuild(); }

    @Override
    protected void onDisable() {
        cache.clear();
        scannedAt.clear();
        visible = new ArrayList<>();
        visibleColors = new ArrayList<>();
        MinecraftClient mc = Util.mc();
        if (mc.player != null && lightAdded) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        lightAdded = false;
    }

    @Override
    public void reset() {
        cache.clear();
        scannedAt.clear();
        visible = new ArrayList<>();
        visibleColors = new ArrayList<>();
    }

    // ================================================================ скан

    private void scanChunk(MinecraftClient mc, int cx, int cz) {
        long key = ChunkPos.toLong(cx, cz);
        scannedAt.put(key, ticks);
        Chunk ch = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
        if (!(ch instanceof WorldChunk wc)) { cache.remove(key); return; }
        List<BlockPos> out = new ArrayList<>();
        ChunkSection[] secs = wc.getSectionArray();
        int bottom = wc.getBottomY();
        for (int i = 0; i < secs.length; i++) {
            ChunkSection s = secs[i];
            if (s == null || s.isEmpty()) continue;
            if (!s.hasAny(st -> targets.contains(st.getBlock()))) continue;
            int y0 = bottom + i * 16;
            for (int x = 0; x < 16; x++) {
                for (int y = 0; y < 16; y++) {
                    for (int z = 0; z < 16; z++) {
                        if (targets.contains(s.getBlockState(x, y, z).getBlock())) {
                            out.add(new BlockPos(cx * 16 + x, y0 + y, cz * 16 + z));
                        }
                    }
                }
            }
        }
        cache.put(key, out);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ticks++;
        if (!signature().equals(lastSig)) rebuild();

        int r = (int) Math.ceil(range.num() / 16.0);
        int pcx = p.getBlockPos().getX() >> 4, pcz = p.getBlockPos().getZ() >> 4;

        // жақын чанктардан бастап, әр тикте ең көбі 8 чанк (қайта скан — 200 тикте бір)
        int budget = 8;
        for (int ring = 0; ring <= r && budget > 0; ring++) {
            for (int cx = pcx - ring; cx <= pcx + ring && budget > 0; cx++) {
                for (int cz = pcz - ring; cz <= pcz + ring && budget > 0; cz++) {
                    if (Math.max(Math.abs(cx - pcx), Math.abs(cz - pcz)) != ring) continue;
                    Integer last = scannedAt.get(ChunkPos.toLong(cx, cz));
                    if (last == null || ticks - last > 200) {
                        scanChunk(mc, cx, cz);
                        budget--;
                    }
                }
            }
        }

        if (ticks % 10 == 0) refreshVisible(mc, p);

        if (light.on()) {
            boolean has = p.hasStatusEffect(StatusEffects.NIGHT_VISION);
            if (!has || (lightAdded && ticks % 100 == 1)) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
                lightAdded = true;
            }
        }

        // алыстап кеткен чанктардың кэшін тазалау (ұзақ ұшқанда жад толмасын)
        if (ticks % 200 == 0) {
            final int keep = r + 2;
            cache.keySet().removeIf(k -> chunkFar(k, pcx, pcz, keep));
            scannedAt.keySet().removeIf(k -> chunkFar(k, pcx, pcz, keep));
        }
    }

    private static boolean chunkFar(long key, int pcx, int pcz, int keep) {
        int cx = (int) (key & 0xFFFFFFFFL), cz = (int) (key >>> 32);
        return Math.max(Math.abs(cx - pcx), Math.abs(cz - pcz)) > keep;
    }

    private record Cand(double d, BlockPos pos) {}

    private void refreshVisible(MinecraftClient mc, ClientPlayerEntity p) {
        double r2 = range.num() * range.num();
        Vec3d eye = p.getEyePos();
        int max = (int) maxBoxes.num();
        // ең жақын max блокты ғана алады (бүкіл тізімді сұрыптамай, heap арқылы)
        java.util.PriorityQueue<Cand> heap = new java.util.PriorityQueue<>((a, b) -> Double.compare(b.d(), a.d()));
        for (List<BlockPos> l : cache.values()) {
            for (BlockPos b : l) {
                double dx = b.getX() + 0.5 - eye.x, dy = b.getY() + 0.5 - eye.y, dz = b.getZ() + 0.5 - eye.z;
                double d = dx * dx + dy * dy + dz * dz;
                if (d > r2) continue;
                if (heap.size() < max) heap.add(new Cand(d, b));
                else if (d < heap.peek().d()) { heap.poll(); heap.add(new Cand(d, b)); }
            }
        }
        List<Cand> sorted = new ArrayList<>(heap);
        sorted.sort(java.util.Comparator.comparingDouble(Cand::d));
        List<BlockPos> vis = new ArrayList<>();
        List<Integer> cols = new ArrayList<>();
        for (Cand c : sorted) {
            Block blk = mc.world.getBlockState(c.pos()).getBlock();      // әлі сол блок па (қазылып кетпеген бе)
            if (!targets.contains(blk)) continue;
            vis.add(c.pos());
            cols.add(colors.getOrDefault(blk, 0xFFFFFFFF));
        }
        visible = vis;
        visibleColors = cols;
    }

    // ================================================================ жарқыл (HUD)

    public static void renderHud(DrawContext ctx) {
        XRay x = INSTANCE;
        if (x == null || !x.enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        x.draw(ctx, mc, mc.player);
    }

    private void draw(DrawContext ctx, MinecraftClient mc, ClientPlayerEntity p) {
        List<BlockPos> list = visible;
        if (list.isEmpty()) return;

        Vec3d eye = p.getEyePos();
        double yr = Math.toRadians(p.getYaw()), pr = Math.toRadians(p.getPitch());
        double cy = Math.cos(yr), sy = Math.sin(yr), cp = Math.cos(pr), sp = Math.sin(pr);
        Vec3d f = new Vec3d(-sy * cp, -sp, cy * cp);
        Vec3d r = new Vec3d(-cy, 0, -sy);
        Vec3d u = r.crossProduct(f);

        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        double tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        double aspect = (double) w / h;
        final double near = 0.1;

        for (int n = 0; n < list.size(); n++) {
            BlockPos b = list.get(n);
            int color = visibleColors.get(n);
            double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
            boolean any = false;
            for (int i = 0; i < 8; i++) {
                double dx = b.getX() + (i & 1) - eye.x, dy = b.getY() + ((i >> 1) & 1) - eye.y, dz = b.getZ() + ((i >> 2) & 1) - eye.z;
                double cz = dx * f.x + dy * f.y + dz * f.z;
                if (cz < near) continue;                                   // камера артында
                double cx = dx * r.x + dy * r.y + dz * r.z;
                double cyv = dx * u.x + dy * u.y + dz * u.z;
                double px = ((cx / cz) / (tanHalf * aspect) * 0.5 + 0.5) * w;
                double py = (0.5 - (cyv / cz) / tanHalf * 0.5) * h;
                if (px < minX) minX = px;
                if (px > maxX) maxX = px;
                if (py < minY) minY = py;
                if (py > maxY) maxY = py;
                any = true;
            }
            if (!any) continue;
            if (maxX < -30 || minX > w + 30 || maxY < -30 || minY > h + 30) continue;

            double mx = (minX + maxX) / 2.0, my = (minY + maxY) / 2.0;
            double half = Math.max(2.5, Math.max(maxX - minX, maxY - minY) / 2.0);   // алыс блок та көрінсін
            glow(ctx, mx, my, half, color);
        }
    }

    /** Жарқыл: ортасы тығыз, шетіне қарай мөлдір болатын бірнеше қабат. */
    private static void glow(DrawContext ctx, double cx, double cy, double half, int argb) {
        int rgb = argb & 0xFFFFFF;
        int[] pad = { 6, 4, 2, 0 };
        int[] alpha = { 0x14, 0x24, 0x40, 0x78 };
        for (int i = 0; i < pad.length; i++) {
            int x1 = (int) Math.floor(cx - half - pad[i]), y1 = (int) Math.floor(cy - half - pad[i]);
            int x2 = (int) Math.ceil(cx + half + pad[i]), y2 = (int) Math.ceil(cy + half + pad[i]);
            ctx.fill(x1, y1, x2, y2, (alpha[i] << 24) | rgb);
        }
    }
}
