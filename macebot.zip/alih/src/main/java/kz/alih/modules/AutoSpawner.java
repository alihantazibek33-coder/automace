package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.function.Predicate;

/**
 * АвтоСпавнер: спавнер іздейді, оған барады (шұңқыр, лава, су қауіптерін айналып; элитра болса ұшып, абайлап түсіп),
 * спавнерге қарай қазады да, жеткенде өзі өшеді. Нақты pathfinding жоқ: түзу барады, қауіпті айналады.
 */
public class AutoSpawner extends Module {
    private enum State { SEARCH, GOTO, DIG }
    private enum Fly { NONE, TAKEOFF, CRUISE, LAND }

    private final Setting useElytra = bool("Элитрамен ұшу", true);
    private final Setting cruiseY = num("Ұшу биіктігі (Y)", 110, 70, 300, 10);
    private final Setting fwLimit = num("Фейерверк лимиті", 30, 5, 200, 5);
    private final Setting reach = num("Жету қашықтығы (блок)", 3.5, 2.0, 4.5, 0.5);

    private final Random rnd = new Random();
    private final Set<Long> visited = new HashSet<>();

    private State state = State.SEARCH;
    private Fly fly = Fly.NONE;
    private BlockPos target;
    private float heading, avoidYaw;
    private int ticks, fwCd, fwUsed, swapCd, avoidT;
    private Vec3d lastPos = Vec3d.ZERO;

    public AutoSpawner() {
        super("autospawner", "АвтоСпавнер", "Спавнер іздеп, барып, қазып жетеді де өзі өшеді");
    }

    @Override
    public boolean persistEnabled() { return false; }

    @Override
    protected void onEnable() {
        MinecraftClient mc = Util.mc();
        if (mc.player == null) { setEnabled(false); return; }
        state = State.SEARCH;
        fly = Fly.NONE;
        target = null;
        heading = mc.player.getYaw();
        fwUsed = 0;
        Util.msg("АвтоСпавнер: спавнер іздеп жатыр");
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = Util.mc();
        if (mc.options != null) release(mc);
    }

    @Override
    public void reset() {
        state = State.SEARCH;
        fly = Fly.NONE;
        target = null;
        if (enabled) setEnabled(false);
    }

    private void release(MinecraftClient mc) {
        mc.options.forwardKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
        mc.options.attackKey.setPressed(false);
    }

    // ================================================================ негізгі цикл

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ticks++;
        if (fwCd > 0) fwCd--;
        if (swapCd > 0) swapCd--;
        if (mc.currentScreen != null) return;
        release(mc);

        if (ticks % 20 == 0) scan(mc, p);

        // нысана жоғалса (жарылып/қазылып кетсе) — қайта іздейді
        if (target != null && state != State.SEARCH && !(mc.world.getBlockEntity(target) instanceof MobSpawnerBlockEntity)) {
            target = null;
            state = State.SEARCH;
        }

        switch (state) {
            case SEARCH -> search(mc, p);
            case GOTO -> goTo(mc, p);
            case DIG -> dig(mc, p);
        }
    }

    // ================================================================ спавнер іздеу

    private void scan(MinecraftClient mc, ClientPlayerEntity p) {
        if (state == State.DIG) return;
        int vd = mc.options.getViewDistance().getValue();
        int pcx = p.getBlockPos().getX() >> 4, pcz = p.getBlockPos().getZ() >> 4;
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int cx = pcx - vd; cx <= pcx + vd; cx++) {
            for (int cz = pcz - vd; cz <= pcz + vd; cz++) {
                Chunk ch = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
                if (!(ch instanceof WorldChunk wc)) continue;
                for (BlockEntity be : wc.getBlockEntities().values()) {
                    if (!(be instanceof MobSpawnerBlockEntity)) continue;
                    BlockPos bp = be.getPos();
                    if (visited.contains(bp.asLong())) continue;
                    double d = Util.pos(p).squaredDistanceTo(Vec3d.ofCenter(bp));
                    if (d < bd) { bd = d; best = bp; }
                }
            }
        }
        if (best != null && (target == null || !best.equals(target))) {
            target = best;
            state = State.GOTO;
            Util.msg("Спавнер табылды: " + best.getX() + " " + best.getY() + " " + best.getZ());
        }
    }

    private void search(MinecraftClient mc, ClientPlayerEntity p) {
        if (fly == Fly.NONE && p.isOnGround() && canFly(p)) fly = Fly.TAKEOFF;
        if (fly != Fly.NONE) { flyStep(mc, p, null); return; }
        if (ticks % 200 == 0) heading += rnd.nextInt(100) - 50;
        double rad = Math.toRadians(heading);
        walkToward(mc, p, p.getX() - Math.sin(rad) * 30, p.getZ() + Math.cos(rad) * 30);
    }

    private void goTo(MinecraftClient mc, ClientPlayerEntity p) {
        if (target == null) { state = State.SEARCH; return; }
        double hd = Math.hypot(target.getX() + 0.5 - p.getX(), target.getZ() + 0.5 - p.getZ());
        if (fly == Fly.NONE && hd > 80 && p.isOnGround() && canFly(p)) fly = Fly.TAKEOFF;
        if (fly != Fly.NONE) { flyStep(mc, p, Vec3d.ofCenter(target)); return; }
        if (hd > 6) { walkToward(mc, p, target.getX() + 0.5, target.getZ() + 0.5); return; }
        state = State.DIG;
    }

    // ================================================================ қазу

    private void dig(MinecraftClient mc, ClientPlayerEntity p) {
        Vec3d c = Vec3d.ofCenter(target);
        if (p.getEyePos().distanceTo(c) <= reach.num()) {
            visited.add(target.asLong());
            Util.msg("Спавнерге жетті. АвтоСпавнер өшірілді");
            setEnabled(false);
            return;
        }

        double hd = Math.hypot(c.x - p.getX(), c.z - p.getZ());
        double dy = c.y - p.getY();
        BlockPos feet = p.getBlockPos();

        // төмен қазу: нысана төмен болса, үстіне келіп тік қазады
        if (dy < -2.0) {
            if (hd > 1.5) { walkToward(mc, p, c.x, c.z); return; }
            if (danger(mc, feet.down()) || danger(mc, feet.down(2)) || danger(mc, feet.down(3))) {
                Util.msg("Астында лава бар. АвтоСпавнер тоқтатылды");
                setEnabled(false);
                return;
            }
            mineTool(mc, p, mc.world.getBlockState(feet.down()));
            Util.smoothPitch(p, 90f);
            mc.options.attackKey.setPressed(true);
            return;
        }

        // көлденең тоннель: спавнерге қарап, алдындағы блокты қазады
        Util.aimAt(p, c);
        HitResult hr = mc.crosshairTarget;
        if (hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
            BlockPos hit = bhr.getBlockPos();
            if (dangerAround(mc, hit)) {
                Util.msg("Қазатын жерде лава бар. АвтоСпавнер тоқтатылды");
                setEnabled(false);
                return;
            }
            if (Vec3d.ofCenter(hit).distanceTo(p.getEyePos()) <= 4.5) {
                mineTool(mc, p, mc.world.getBlockState(hit));
                mc.options.attackKey.setPressed(true);
                return;
            }
        }
        // алды ашық болса — жақындайды
        if (hd > 1.0) {
            walkToward(mc, p, c.x, c.z);
        }
    }

    private boolean danger(MinecraftClient mc, BlockPos pos) {
        return mc.world.getBlockState(pos).getFluidState().isIn(FluidTags.LAVA);
    }

    private boolean dangerAround(MinecraftClient mc, BlockPos pos) {
        if (danger(mc, pos)) return true;
        for (net.minecraft.util.math.Direction d : net.minecraft.util.math.Direction.values()) {
            if (danger(mc, pos.offset(d))) return true;
        }
        return false;
    }

    private void mineTool(MinecraftClient mc, ClientPlayerEntity p, BlockState st) {
        int pick = Util.grab(mc, p, s -> s.isIn(ItemTags.PICKAXES));
        if (pick >= 0) Util.select(p, pick);
        else {
            int best = Util.selected(p);
            float bm = p.getInventory().getStack(best).getMiningSpeedMultiplier(st);
            for (int i = 0; i < 9; i++) {
                float m = p.getInventory().getStack(i).getMiningSpeedMultiplier(st);
                if (m > bm) { bm = m; best = i; }
            }
            Util.select(p, best);
        }
    }

    // ================================================================ жүру

    private boolean solid(MinecraftClient mc, BlockPos pos) {
        return mc.world.getBlockState(pos).isSolidBlock(mc.world, pos);
    }

    private void walkToward(MinecraftClient mc, ClientPlayerEntity p, double x, double z) {
        double dx = x - p.getX(), dz = z - p.getZ();
        float yaw = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        if (avoidT > 0) { avoidT--; yaw = avoidYaw; }
        Util.smoothYaw(p, yaw);
        Util.smoothPitch(p, 0f);

        double rad = Math.toRadians(yaw);
        double fx = -Math.sin(rad), fz = Math.cos(rad);
        BlockPos feetAhead = BlockPos.ofFloored(p.getX() + fx * 1.0, p.getY(), p.getZ() + fz * 1.0);
        BlockPos feetAhead2 = BlockPos.ofFloored(p.getX() + fx * 2.0, p.getY(), p.getZ() + fz * 2.0);
        BlockPos headAhead = feetAhead.up();
        boolean inWater = p.isTouchingWater();

        // қауіп: лава, терең шұңқыр (су болса — жүзеді)
        boolean lava = danger(mc, feetAhead) || danger(mc, feetAhead.down()) || danger(mc, feetAhead2) || danger(mc, feetAhead2.down());
        boolean waterAhead = mc.world.getBlockState(feetAhead).getFluidState().isIn(FluidTags.WATER);
        boolean pit = !solid(mc, feetAhead.down()) && !solid(mc, feetAhead.down(2)) && !solid(mc, feetAhead.down(3)) && !waterAhead;
        if (lava || pit) {
            avoidYaw = yaw + 90f * (rnd.nextBoolean() ? 1 : -1);
            avoidT = 25;
            return;
        }

        mc.options.forwardKey.setPressed(true);
        mc.options.sprintKey.setPressed(true);

        boolean feetBlocked = solid(mc, feetAhead);
        boolean headBlocked = solid(mc, headAhead);
        if (feetBlocked && !headBlocked && p.isOnGround()) {
            mc.options.jumpKey.setPressed(true);                       // 1 блок секіру
        } else if (feetBlocked && headBlocked) {
            BlockPos wall = headBlocked ? headAhead : feetAhead;
            if (dangerAround(mc, wall)) {
                avoidYaw = yaw + 90f;
                avoidT = 30;
            } else {
                mineTool(mc, p, mc.world.getBlockState(wall));
                Util.aimAt(p, Vec3d.ofCenter(wall));
                mc.options.attackKey.setPressed(true);
            }
        }
        // суда тұншықпау: бетінде жүзеді
        if (inWater || p.isSubmergedInWater()) mc.options.jumpKey.setPressed(true);

        if (ticks % 40 == 0) {                                          // тұрып қалса — бағытты өзгертеді
            Vec3d now = new Vec3d(p.getX(), p.getY(), p.getZ());
            if (now.distanceTo(lastPos) < 0.8) {
                avoidYaw = yaw + 70f * (rnd.nextBoolean() ? 1 : -1);
                avoidT = 30;
                heading += 60;
            }
            lastPos = now;
        }
    }

    // ================================================================ элитра

    private boolean canFly(ClientPlayerEntity p) {
        boolean elytra = p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)
                || Util.hasInInventory(p, s -> s.isOf(Items.ELYTRA));
        return useElytra.on() && elytra && fwUsed < fwLimit.num()
                && Util.hasInInventory(p, s -> s.isOf(Items.FIREWORK_ROCKET));
    }

    private static int screenSlot(int invIndex) { return invIndex < 9 ? 36 + invIndex : invIndex; }

    private void equipFromInventory(MinecraftClient mc, ClientPlayerEntity p, Predicate<ItemStack> f) {
        if (swapCd > 0) return;
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isEmpty() && f.test(s)) {
                int from = screenSlot(i);
                int sid = p.playerScreenHandler.syncId;
                mc.interactionManager.clickSlot(sid, from, 0, SlotActionType.PICKUP, p);
                mc.interactionManager.clickSlot(sid, 6, 0, SlotActionType.PICKUP, p);
                mc.interactionManager.clickSlot(sid, from, 0, SlotActionType.PICKUP, p);
                swapCd = 4;
                return;
            }
        }
    }

    private void equipChestplate(MinecraftClient mc, ClientPlayerEntity p) {
        equipFromInventory(mc, p, s -> !s.isOf(Items.ELYTRA) && p.getPreferredEquipmentSlot(s) == EquipmentSlot.CHEST);
    }

    private double groundDist(MinecraftClient mc, ClientPlayerEntity p) {
        BlockPos b = p.getBlockPos();
        for (int k = 0; k < 90; k++) {
            if (solid(mc, b.down(k)) || mc.world.getBlockState(b.down(k)).getFluidState().isIn(FluidTags.WATER)) {
                return k - 1 + (p.getY() - b.getY());
            }
        }
        return 90;
    }

    private void flyStep(MinecraftClient mc, ClientPlayerEntity p, Vec3d tgt) {
        if (fly == Fly.TAKEOFF) {
            if (!p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) {
                equipFromInventory(mc, p, s -> s.isOf(Items.ELYTRA));
                return;
            }
            if (p.isGliding()) { fly = Fly.CRUISE; return; }
            if (p.isOnGround()) mc.options.jumpKey.setPressed(true);
            else if (p.getVelocity().y < -0.05) mc.options.jumpKey.setPressed(ticks % 2 == 0);
            return;
        }
        if (!p.isGliding()) {
            if (p.isOnGround() || fly == Fly.LAND) { fly = Fly.NONE; return; }
            mc.options.jumpKey.setPressed(ticks % 2 == 0);
            return;
        }

        double hd = tgt == null ? 9999 : Math.hypot(tgt.x - p.getX(), tgt.z - p.getZ());
        boolean fwLeft = fwUsed < fwLimit.num() && Util.hasInInventory(p, s -> s.isOf(Items.FIREWORK_ROCKET));
        if (fly == Fly.CRUISE && ((tgt != null && hd < 70) || !fwLeft)) fly = Fly.LAND;

        float yaw = tgt != null
                ? (float) (MathHelper.atan2(tgt.z - p.getZ(), tgt.x - p.getX()) * 180.0 / Math.PI) - 90f
                : heading;
        Util.smoothYaw(p, yaw);

        double gd = groundDist(mc, p);
        double speed = Math.hypot(p.getVelocity().x, p.getVelocity().z);
        float pitch;
        if (fly == Fly.LAND) {
            pitch = gd > 25 ? 28f : (gd > 8 ? 14f : 6f);
            if (gd <= 2.5) {                           // жерге жақын: элитраны алып, абайлап түседі
                fly = Fly.NONE;
                equipChestplate(mc, p);
                return;
            }
        } else {
            double err = cruiseY.num() - p.getY();
            pitch = (float) (err > 0 ? -Math.min(45, err * 0.6) : Math.min(15, -err * 0.3));
        }

        double rad = Math.toRadians(yaw);
        for (int k = 3; k <= 12; k += 3) {            // алда тау/ағаш болса көтеріледі
            BlockPos ahead = BlockPos.ofFloored(p.getX() - Math.sin(rad) * k, p.getY(), p.getZ() + Math.cos(rad) * k);
            if (solid(mc, ahead) || solid(mc, ahead.up())) { pitch = -45f; break; }
        }
        Util.smoothPitch(p, pitch);

        if (fly == Fly.CRUISE && fwCd == 0 && (speed < 0.9 || (cruiseY.num() - p.getY()) > 12)) {
            int fw = Util.grab(mc, p, s -> s.isOf(Items.FIREWORK_ROCKET));
            if (fw >= 0) {
                Util.select(p, fw);
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                fwCd = 30;
                fwUsed++;
            }
        }
    }
}
