package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.Random;
import java.util.UUID;

/**
 * АвтоУХК: жақын игрокты нысанаға алып, өзі PvP жасайды — критпен ұру, щит, алтын алма, шегіну,
 * паутина, лава (қойып қайта алады), алыстан лук.
 */
public class AutoUhc extends Module {
    private final Setting eatHp = num("Алма жеу HP", 10, 4, 18, 1);
    private final Setting bowDist = num("Лук қашықтығы", 9, 6, 30, 1);
    private final Setting lava = bool("Лава", true);
    private final Setting web = bool("Паутина", true);
    private final Setting bowS = bool("Лук", true);
    private final Setting shieldS = bool("Щит (оң қолда)", true);

    private final Random rnd = new Random();
    private UUID targetId;
    private int eatTicks, webCd, lavaCd, strafeT, strafeDir = 1, hitWait;
    private BlockPos lavaPos;
    private int lavaT;

    public AutoUhc() {
        super("autouhc", "АвтоУХК", "Жақын игрокпен өзі PvP жасайды: крит, щит, алма, паутина, лава, лук");
    }

    @Override
    protected void onEnable() {
        targetId = null;
        eatTicks = 0; webCd = 0; lavaCd = 0; lavaPos = null; hitWait = 0;
    }

    @Override
    protected void onDisable() {
        releaseKeys(Util.mc());
    }

    private void releaseKeys(MinecraftClient mc) {
        mc.options.forwardKey.setPressed(false);
        mc.options.backKey.setPressed(false);
        mc.options.leftKey.setPressed(false);
        mc.options.rightKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
        mc.options.useKey.setPressed(false);
    }

    private PlayerEntity resolveTarget(MinecraftClient mc, ClientPlayerEntity p) {
        if (targetId != null) {
            var e = Util.entityById(mc, targetId);
            if (e != null && Util.validPlayer(p, e) && e.distanceTo(p) < 60) return (PlayerEntity) e;
        }
        PlayerEntity n = Util.nearestPlayer(mc, p, 40);
        targetId = n == null ? null : n.getUuid();
        return n;
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (webCd > 0) webCd--;
        if (lavaCd > 0) lavaCd--;
        releaseKeys(mc);
        if (mc.currentScreen != null) return;

        PlayerEntity t = resolveTarget(mc, p);
        if (t == null) return;

        double dist = Util.boxDist(p.getEyePos(), t.getBoundingBox());
        float hp = p.getHealth() + p.getAbsorptionAmount();

        if (handleLava(mc, p)) return;

        // ---- алтын алма жеу
        int apple = Util.findHotbar(p, s -> s.isOf(Items.ENCHANTED_GOLDEN_APPLE) || s.isOf(Items.GOLDEN_APPLE));
        if (hp <= eatHp.num() && apple >= 0) {
            Util.aimAt(p, Util.center(t));
            if (eatTicks == 0 && dist < 3.0 && hp > 6) {
                mc.options.backKey.setPressed(true); // алдымен шегінеді
                return;
            }
            Util.select(p, apple);
            mc.options.useKey.setPressed(true);
            eatTicks++;
            if (eatTicks > 45 || (eatTicks > 4 && !p.isUsingItem())) eatTicks = 0;
            return;
        }
        eatTicks = 0;

        // ---- алыстан лук
        int bow = Util.findHotbar(p, s -> s.isOf(Items.BOW));
        boolean hasArrow = Util.hasInInventory(p, s -> s.isIn(ItemTags.ARROWS));
        if (bowS.on() && bow >= 0 && hasArrow && dist > bowDist.num() && dist < 45) {
            Util.select(p, bow);
            Util.aimAt(p, AutoBow.lead(p, t, 3.0));
            mc.options.useKey.setPressed(true);
            if (p.getItemUseTime() >= 20) mc.options.useKey.setPressed(false); // жібереді
            return;
        }

        // ---- қару таңдау және нысанаға қарау
        int weapon = Util.findHotbar(p, s -> s.isIn(ItemTags.SWORDS));
        if (weapon < 0) weapon = Util.findHotbar(p, s -> s.isIn(ItemTags.AXES));
        if (weapon < 0) weapon = Util.findHotbar(p, s -> s.isOf(Items.MACE));
        if (weapon >= 0) Util.select(p, weapon);
        Util.aimAt(p, Util.center(t));

        // ---- паутина
        if (web.on() && webCd == 0 && dist >= 2.0 && dist <= 4.2) {
            int cw = Util.findHotbar(p, s -> s.isOf(Items.COBWEB));
            BlockPos tp = t.getBlockPos();
            if (cw >= 0 && mc.world.getBlockState(tp).isAir()
                    && mc.world.getBlockState(tp.down()).isSolidBlock(mc.world, tp.down())) {
                Util.select(p, cw);
                Util.place(mc, p, tp.down(), Direction.UP);
                webCd = 120;
                return;
            }
        }

        // ---- лава: нысана барар жолға
        if (lava.on() && lavaCd == 0 && lavaPos == null && dist >= 3.5 && dist <= 9) {
            int lb = Util.findHotbar(p, s -> s.isOf(Items.LAVA_BUCKET));
            if (lb >= 0) {
                Vec3d fut = new Vec3d(t.getX(), t.getY(), t.getZ()).add(Util.vel(t).multiply(6));
                BlockPos bp = BlockPos.ofFloored(fut);
                BlockPos sup = bp.down();
                Vec3d bc = Vec3d.ofCenter(bp);
                boolean ok = mc.world.getBlockState(bp).isAir()
                        && mc.world.getBlockState(sup).isSolidBlock(mc.world, sup)
                        && p.getEyePos().distanceTo(bc) <= 4.5
                        && Math.hypot(bc.x - p.getX(), bc.z - p.getZ()) >= 2.5;
                if (ok) {
                    Util.select(p, lb);
                    Util.aimAt(p, Vec3d.ofCenter(sup).add(0, 0.5, 0));
                    mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                    lavaPos = bp;
                    lavaT = 0;
                    lavaCd = 160;
                    return;
                }
            }
        }

        // ---- қозғалыс
        if (dist > 2.8) {
            mc.options.forwardKey.setPressed(true);
            mc.options.sprintKey.setPressed(true);
        }
        if (dist < 5) {
            if (--strafeT <= 0) {
                strafeT = 8 + rnd.nextInt(8);
                strafeDir = rnd.nextBoolean() ? 1 : -1;
            }
            mc.options.leftKey.setPressed(strafeDir > 0);
            mc.options.rightKey.setPressed(strafeDir < 0);
        }

        // ---- соққы (крит) және щит
        float cd = p.getAttackCooldownProgress(0.5f);
        boolean offShield = shieldS.on() && p.getOffHandStack().isOf(Items.SHIELD);
        if (dist <= 3.0) {
            mc.options.forwardKey.setPressed(false);
            if (cd >= 0.95f) {
                if (p.isOnGround()) {
                    mc.options.jumpKey.setPressed(true);
                    if (++hitWait > 8) { Util.attack(mc, p, t); hitWait = 0; }
                } else if (p.getVelocity().y < 0) {
                    p.setSprinting(false);
                    Util.attack(mc, p, t);
                    hitWait = 0;
                }
            } else if (offShield) {
                mc.options.useKey.setPressed(true);
            }
        } else {
            hitWait = 0;
        }
    }

    /** Қойылған лаваны алу. true — осы тик лава үшін жұмсалды. */
    private boolean handleLava(MinecraftClient mc, ClientPlayerEntity p) {
        if (lavaPos == null) return false;
        lavaT++;
        BlockState st = mc.world.getBlockState(lavaPos);
        if (!st.getFluidState().isIn(FluidTags.LAVA) || lavaT > 90) {
            if (lavaT > 5 || !st.getFluidState().isIn(FluidTags.LAVA)) lavaPos = null;
            return false;
        }
        Vec3d c = Vec3d.ofCenter(lavaPos);
        double d = p.getEyePos().distanceTo(c);
        if (lavaT >= 22 || d < 2.6) {
            int b = Util.findHotbar(p, s -> s.isOf(Items.BUCKET));
            if (b >= 0 && d <= 4.5) {
                Util.select(p, b);
                Util.aimAt(p, c);
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                return true;
            }
            lavaPos = null;
        }
        return false;
    }
}
