package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;

import java.util.UUID;

/**
 * АвтоПрицел: FOV (прицелдің айналасындағы конус) ішіне игрок/моб кірсе, прицелді соған апарады.
 * Өзің соңғы ұрған нысана FOV ішінде болса, соған басымдық береді.
 */
public class AutoAim extends Module {
    /** Соңғы соққы берілген нысана (AttackEntityCallback арқылы жаңарады). */
    public static UUID lastHit;

    private final Setting range = num("Қашықтық", 8, 3, 20, 1);
    private final Setting fov = num("FOV (°)", 90, 10, 360, 10);
    private final Setting smooth = num("Бұру жылдамдығы (°/тик)", 30, 5, 180, 5);
    private final Setting mobs = bool("Мобқа да", true);

    public AutoAim() {
        super("autoaim", "АвтоПрицел", "FOV-қа кірген нысанаға (соңғы ұрғаныңа басымдық) прицелді апарады");
    }

    @Override
    public void reset() { lastHit = null; }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null) return;
        double half = fov.num() / 2.0;
        Entity best = null;
        double bs = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!Util.validTarget(p, e, mobs.on())) continue;
            if (Util.boxDist(p.getEyePos(), e.getBoundingBox()) > range.num()) continue;
            double a = Util.angleTo(p, Util.center(e));
            if (fov.num() < 360 && a > half) continue;
            double score = e.getUuid().equals(lastHit) ? a - 1000 : a;
            if (score < bs) { bs = score; best = e; }
        }
        if (best == null) return;
        Util.smoothAim(p, Util.center(best), (float) smooth.num());
    }
}
