package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.registry.tag.ItemTags;

/** АвтоСбивЩита: нысана щит ұстаса, балтаға ауысып щитті бұзады да, бұрынғы затқа қайта ауысады. */
public class AutoShieldBreak extends Module {
    private final Setting delay = num("Кідіріс (тик)", 0, 0, 10, 1);

    private int prevSlot = -1;
    private int waited;

    public AutoShieldBreak() {
        super("shieldbreak", "АвтоСбивЩита", "Щит ұстаған нысананы балтамен соғып, бұрынғы затқа қайтады");
    }

    @Override
    public void reset() { prevSlot = -1; waited = 0; }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (prevSlot >= 0) {
            Util.select(p, prevSlot);
            prevSlot = -1;
            return;
        }
        if (mc.currentScreen != null) return;
        Entity t = mc.targetedEntity;
        if (!(t instanceof LivingEntity pl) || !Util.validTarget(p, pl, true) || !pl.isBlocking()) {
            waited = 0;
            return;
        }
        int axe = Util.findHotbar(p, s -> s.isIn(ItemTags.AXES));
        if (axe < 0) return;
        if (waited < (int) delay.num()) { waited++; return; }
        waited = 0;

        int cur = Util.selected(p);
        if (cur != axe) {
            prevSlot = cur;
            Util.select(p, axe);
        }
        Util.attack(mc, p, pl);
    }
}
