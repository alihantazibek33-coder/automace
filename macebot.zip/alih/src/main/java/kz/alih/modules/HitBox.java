package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Optional;

/**
 * ХитБокс: нысананың хитбоксын үлкейтеді (прицел бағыттау үшін). EntityMixin арқылы жұмыс істейді.
 * Ескерту: сервер ұруды өзі тексереді, әдетте ~1 блокқа дейін ғана кешіреді.
 */
public class HitBox extends Module {
    public static HitBox INSTANCE;

    private final Setting size = num("Үлкейту (блок)", 0.3, 0.1, 1.0, 0.1);
    private final Setting playersOnly = bool("Тек игрок", true);

    public HitBox() {
        super("hitbox", "ХитБокс", "Нысананың хитбоксын үлкейтеді (прицелге оңай түседі)");
        INSTANCE = this;
    }

    /** EntityMixin шақырады: энтитиге қосымша хитбокс өрісі (блок). 0 — өзгеріссіз. */
    public static float marginFor(Entity e) {
        HitBox h = INSTANCE;
        if (h == null || !h.enabled) return 0f;
        if (!(e instanceof LivingEntity) || e == MinecraftClient.getInstance().player) return 0f;
        if (h.playersOnly.on() && !(e instanceof PlayerEntity)) return 0f;
        if (Util.isIgnored(e)) return 0f;
        return (float) h.size.num();
    }

    /**
     * Тик басында шақырылады: прицел ешкімді көрмесе, үлкейтілген хитбоксқа түсіп тұрған нысананы прицел нысанасы етеді.
     * Сонда ұру (ЛКМ), ТБот, КиллАура т.б. соны ұрады. Mixin-ге тәуелсіз.
     */
    public void assist(MinecraftClient mc) {
        if (!enabled || mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (mc.crosshairTarget instanceof EntityHitResult) return;

        ClientPlayerEntity p = mc.player;
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1.0f);
        double reach = p.getEntityInteractionRange();
        Vec3d end = eye.add(look.multiply(reach));

        double blockDist = Double.MAX_VALUE;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.BLOCK) {
            blockDist = mc.crosshairTarget.getPos().distanceTo(eye);
        }

        Entity best = null;
        Vec3d bestHit = null;
        double bd = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity) || e == p || !e.isAlive()) continue;
            if (playersOnly.on() && !(e instanceof PlayerEntity)) continue;
            if (Util.isIgnored(e)) continue;
            Box box = e.getBoundingBox().expand(size.num());
            Optional<Vec3d> hit = box.raycast(eye, end);
            if (hit.isEmpty()) continue;
            double d = hit.get().distanceTo(eye);
            if (d < bd && d < blockDist) { bd = d; best = e; bestHit = hit.get(); }
        }
        if (best == null) return;
        mc.targetedEntity = best;
        mc.crosshairTarget = new EntityHitResult(best, bestHit);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        // әрекет assist() және EntityMixin ішінде
    }
}
