package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/** АвтоТотем: сол қолда (offhand) тотем жоқ болса, инвентарьдан өзі салып береді. */
public class AutoTotem extends Module {
    private int cooldown;

    public AutoTotem() {
        super("autototem", "АвтоТотем", "Сол қолға тотем бессмертияны өзі салып тұрады");
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (cooldown > 0) { cooldown--; return; }
        if (mc.currentScreen != null) return;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int screenSlot = i < 9 ? 36 + i : i;
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, screenSlot, 40, SlotActionType.SWAP, p);
                cooldown = 4;
                return;
            }
        }
    }
}
