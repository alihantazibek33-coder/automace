package kz.alih.modules;

import kz.alih.Builder;
import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * АвтоПостройка: екі нүктемен (pos1, pos2) ғимаратты көшіріп, таңдаған жеріңе (here) тез салып береді.
 * Орны бөлшектермен (контур) көрсетіліп тұрады. Блок жетпесе, не жетпейтіні чатқа шығады, барымен салады.
 * Командалар: .alih build pos1 | pos2 | copy | here | start | stop | status | clear
 */
public class AutoBuild extends Module {
    public static AutoBuild INSTANCE;

    private static final class SEntry {
        final int dx, dy, dz;
        final Block block;

        SEntry(int dx, int dy, int dz, Block block) {
            this.dx = dx; this.dy = dy; this.dz = dz; this.block = block;
        }
    }

    private final Setting perTick = num("Блок/тик", 4, 1, 10, 1);
    private final Setting rotation = mode("Бұру", 0, "0°", "90°", "180°", "270°");
    private final Setting breakB = bool("Кедергіні сындыру", true);
    private final Setting clearAir = bool("Бос орынды да тазалау", false);
    private final Setting walkS = bool("Жүріп салу", true);
    private final Setting outline = bool("Контурды көрсету", true);

    private final List<SEntry> structure = new ArrayList<>();
    private final Builder builder = new Builder();
    private int sw, sh, sd;
    private BlockPos pos1, pos2, origin;
    private boolean building;
    private int ticks;

    public AutoBuild() {
        super("autobuild", "АвтоПостройка", "Ғимаратты көшіріп, басқа жерге тез салады (.alih build ...)");
        INSTANCE = this;
    }

    @Override
    public boolean persistEnabled() { return false; }

    @Override
    protected void onDisable() {
        building = false;
        builder.clear();
        MinecraftClient mc = Util.mc();
        if (mc.options != null) mc.options.forwardKey.setPressed(false);
    }

    // ================================================================ командалар

    private BlockPos looked(MinecraftClient mc, boolean adjacent) {
        if (mc.crosshairTarget instanceof BlockHitResult bhr && mc.crosshairTarget.getType() == HitResult.Type.BLOCK) {
            return adjacent ? bhr.getBlockPos().offset(bhr.getSide()) : bhr.getBlockPos();
        }
        return mc.player.getBlockPos();
    }

    public void setPos1() { pos1 = looked(Util.mc(), false); Util.msg("pos1: " + fmt(pos1)); }
    public void setPos2() { pos2 = looked(Util.mc(), false); Util.msg("pos2: " + fmt(pos2)); }

    public void setHere() {
        origin = looked(Util.mc(), true);
        Util.msg("Салу орны (min бұрыш): " + fmt(origin));
        setEnabled(true);
    }

    public void copy() {
        MinecraftClient mc = Util.mc();
        if (pos1 == null || pos2 == null) { Util.msg("Алдымен pos1 және pos2 қой"); return; }
        int x1 = Math.min(pos1.getX(), pos2.getX()), x2 = Math.max(pos1.getX(), pos2.getX());
        int y1 = Math.min(pos1.getY(), pos2.getY()), y2 = Math.max(pos1.getY(), pos2.getY());
        int z1 = Math.min(pos1.getZ(), pos2.getZ()), z2 = Math.max(pos1.getZ(), pos2.getZ());
        long vol = (long) (x2 - x1 + 1) * (y2 - y1 + 1) * (z2 - z1 + 1);
        if (vol > 40000) { Util.msg("Тым үлкен (" + vol + " блок). Максимум 40000"); return; }

        structure.clear();
        for (int x = x1; x <= x2; x++) {
            for (int y = y1; y <= y2; y++) {
                for (int z = z1; z <= z2; z++) {
                    BlockState st = mc.world.getBlockState(new BlockPos(x, y, z));
                    Block b = st.getBlock();
                    if (st.isAir()) {
                        if (clearAir.on()) structure.add(new SEntry(x - x1, y - y1, z - z1, b));
                        continue;
                    }
                    if (b.asItem() == net.minecraft.item.Items.AIR) continue;   // су, от т.б. — салынбайды
                    structure.add(new SEntry(x - x1, y - y1, z - z1, b));
                }
            }
        }
        sw = x2 - x1 + 1; sh = y2 - y1 + 1; sd = z2 - z1 + 1;
        Util.msg("Көшірілді: " + structure.size() + " блок (" + sw + "x" + sh + "x" + sd + "). Енді .alih build here, сосын start");
        setEnabled(true);
    }

    public void start() {
        MinecraftClient mc = Util.mc();
        if (structure.isEmpty()) { Util.msg("Алдымен .alih build copy"); return; }
        if (origin == null) { Util.msg("Алдымен .alih build here (салатын жерге қарап)"); return; }
        builder.clear();
        int rot = rotation.mode();
        for (SEntry e : structure) {
            int x, z;
            switch (rot) {
                case 1 -> { x = sd - 1 - e.dz; z = e.dx; }
                case 2 -> { x = sw - 1 - e.dx; z = sd - 1 - e.dz; }
                case 3 -> { x = e.dz; z = sw - 1 - e.dx; }
                default -> { x = e.dx; z = e.dz; }
            }
            builder.entries.add(new Builder.Entry(origin.add(x, e.dy, z), e.block));
        }
        final Vec3d pp = Util.pos(mc.player);
        builder.entries.sort((a, b) -> {
            int c = Integer.compare(a.pos.getY(), b.pos.getY());
            if (c != 0) return c;
            return Double.compare(Vec3d.ofCenter(a.pos).squaredDistanceTo(pp), Vec3d.ofCenter(b.pos).squaredDistanceTo(pp));
        });
        building = true;
        setEnabled(true);
        Util.msg("Салу басталды: " + builder.entries.size() + " блок");
    }

    public void stop() {
        building = false;
        builder.clear();
        MinecraftClient mc = Util.mc();
        if (mc.options != null) mc.options.forwardKey.setPressed(false);
        Util.msg("Салу тоқтатылды");
    }

    public void clearAll() {
        stop();
        structure.clear();
        pos1 = pos2 = origin = null;
        Util.msg("АвтоПостройка тазаланды");
    }

    public void status() {
        Util.msg("Құрылым: " + structure.size() + " блок, орын: " + (origin == null ? "жоқ" : fmt(origin))
                + ", қалды: " + builder.entries.size());
        printMissing();
    }

    private static String fmt(BlockPos b) { return b.getX() + " " + b.getY() + " " + b.getZ(); }

    private void printMissing() {
        Map<String, Integer> miss = builder.missing();
        if (miss.isEmpty()) return;
        StringBuilder sb = new StringBuilder("Жетпейді: ");
        for (Map.Entry<String, Integer> e : miss.entrySet()) sb.append(e.getKey()).append(" x").append(e.getValue()).append("; ");
        Util.msg(sb.toString());
    }

    // ================================================================ тик

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ticks++;
        if (outline.on() && origin != null && !structure.isEmpty() && ticks % 6 == 0) drawOutline(mc);
        if (!building) return;
        if (mc.currentScreen != null) return;

        builder.perTick = (int) perTick.num();
        builder.breakBlocks = breakB.on();
        builder.walk = walkS.on();
        boolean done = builder.tick(mc, p);
        if (done) {
            building = false;
            mc.options.forwardKey.setPressed(false);
            Util.msg("Салынды!");
        } else {
            if (ticks % 200 == 0) printMissing();
        }
    }

    private void drawOutline(MinecraftClient mc) {
        int w = rotation.mode() % 2 == 0 ? sw : sd;
        int d = rotation.mode() % 2 == 0 ? sd : sw;
        double x0 = origin.getX(), y0 = origin.getY(), z0 = origin.getZ();
        double x1 = x0 + w, y1 = y0 + sh, z1 = z0 + d;
        double[][] c = {
            {x0, y0, z0}, {x1, y0, z0}, {x1, y0, z1}, {x0, y0, z1},
            {x0, y1, z0}, {x1, y1, z0}, {x1, y1, z1}, {x0, y1, z1}
        };
        int[][] edges = { {0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7} };
        for (int[] e : edges) {
            double[] a = c[e[0]], b = c[e[1]];
            double len = Math.sqrt(Math.pow(b[0]-a[0],2) + Math.pow(b[1]-a[1],2) + Math.pow(b[2]-a[2],2));
            int n = (int) Math.min(40, Math.max(2, Math.ceil(len / 1.5)));
            for (int i = 0; i <= n; i++) {
                double t = i / (double) n;
                mc.particleManager.addParticle(ParticleTypes.END_ROD,
                        a[0] + (b[0]-a[0]) * t, a[1] + (b[1]-a[1]) * t, a[2] + (b[2]-a[2]) * t, 0, 0, 0);
            }
        }
    }
}
