package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ФПС Буст: ойынның бейнебаптауларын FPS үшін оңтайландырады (render/simulation distance, бөлшектер, көлеңке,
 * графика, бұлт, VSync...). Өшіргенде бұрынғы баптауларды қайтарады. Нәтиже компьютеріңе тәуелді.
 */
public class FpsBoost extends Module {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("alihclient-fpsboost-backup.txt");

    private final Setting view = num("Render distance", 8, 4, 16, 1);
    private final Setting sim = num("Simulation distance", 6, 5, 12, 1);
    private final Setting lowGfx = bool("Төмен графика (бөлшек, көлеңке, бұлт)", true);
    private final Setting noVsync = bool("VSync өшіру", true);

    private String lastSig = "";

    public FpsBoost() {
        super("fpsboost", "ФПС Буст", "Баптауларды FPS үшін оңтайландырады (өшіргенде бұрынғысы қайтады)");
    }

    @Override
    public boolean persistEnabled() { return false; }

    private String sig() {
        return view.num() + "|" + sim.num() + "|" + lowGfx.on() + "|" + noVsync.on();
    }

    private void backup(GameOptions o) {
        if (Files.exists(FILE)) return;      // алдыңғы (бүлінбеген) түпнұсқа сақталып тұр
        List<String> lines = List.of(
                "view=" + o.getViewDistance().getValue(),
                "sim=" + o.getSimulationDistance().getValue(),
                "particles=" + ((Enum<?>) (Object) o.getParticles().getValue()).name(),
                "shadows=" + o.getEntityShadows().getValue(),
                "biome=" + o.getBiomeBlendRadius().getValue(),
                "entscale=" + o.getEntityDistanceScaling().getValue(),
                "clouds=" + o.getCloudRenderMode().getValue().name(),
                "vsync=" + o.getEnableVsync().getValue(),
                "maxfps=" + o.getMaxFps().getValue());
        try {
            Files.write(FILE, lines);
        } catch (IOException ignored) {
        }
    }

    /** Enum түріндегі баптауды түрін атамай қояды: name == null болса — соңғы мән (MINIMAL). */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void setEnum(net.minecraft.client.option.SimpleOption opt, String name) {
        Object cur = opt.getValue();
        if (!(cur instanceof Enum<?> e)) return;
        Object[] consts = e.getDeclaringClass().getEnumConstants();
        if (name == null) {
            opt.setValue(consts[consts.length - 1]);
            return;
        }
        for (Object c : consts) {
            if (((Enum<?>) c).name().equals(name)) { opt.setValue(c); return; }
        }
    }

    private void apply(GameOptions o) {
        o.getViewDistance().setValue((int) view.num());
        o.getSimulationDistance().setValue((int) sim.num());
        if (lowGfx.on()) {
            setEnum(o.getParticles(), null);   // ең соңғысы = MINIMAL
            o.getEntityShadows().setValue(false);
            o.getBiomeBlendRadius().setValue(0);
            o.getEntityDistanceScaling().setValue(0.5);
            o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        }
        if (noVsync.on()) o.getEnableVsync().setValue(false);
        o.getMaxFps().setValue(260);
        lastSig = sig();
    }

    private void restore(GameOptions o) {
        if (!Files.exists(FILE)) return;
        Map<String, String> m = new HashMap<>();
        try {
            for (String line : Files.readAllLines(FILE)) {
                int i = line.indexOf('=');
                if (i > 0) m.put(line.substring(0, i), line.substring(i + 1));
            }
        } catch (IOException e) {
            return;
        }
        try {
            o.getViewDistance().setValue(Integer.parseInt(m.get("view")));
            o.getSimulationDistance().setValue(Integer.parseInt(m.get("sim")));
            setEnum(o.getParticles(), m.get("particles"));
            o.getEntityShadows().setValue(Boolean.parseBoolean(m.get("shadows")));
            o.getBiomeBlendRadius().setValue(Integer.parseInt(m.get("biome")));
            o.getEntityDistanceScaling().setValue(Double.parseDouble(m.get("entscale")));
            o.getCloudRenderMode().setValue(CloudRenderMode.valueOf(m.get("clouds")));
            o.getEnableVsync().setValue(Boolean.parseBoolean(m.get("vsync")));
            o.getMaxFps().setValue(Integer.parseInt(m.get("maxfps")));
        } catch (RuntimeException ignored) {
        }
        try {
            Files.deleteIfExists(FILE);
        } catch (IOException ignored) {
        }
    }

    private void reload(MinecraftClient mc) {
        if (mc.worldRenderer != null && mc.world != null) mc.worldRenderer.reload();
    }

    @Override
    protected void onEnable() {
        MinecraftClient mc = Util.mc();
        if (mc.options == null) return;
        backup(mc.options);
        apply(mc.options);
        reload(mc);
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = Util.mc();
        if (mc.options == null) return;
        restore(mc.options);
        reload(mc);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (!sig().equals(lastSig)) {          // баптау өзгерсе қайта қолданады
            apply(mc.options);
            reload(mc);
        }
    }
}
