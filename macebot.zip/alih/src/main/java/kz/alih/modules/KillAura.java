package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;

/** КиллАура: қол жететін қашықтықтағы ең жақын нысанаға өзі қарап, автоматты ұрады. */
public class KillAura extends Module {
    private final Setting range = num("Қашықтық", 3.0, 2.0, 6.0, 0.5);
    private final Setting mobs = bool("Мобқа да", true);
    private final Setting fov = num("FOV (°)", 180, 30, 360, 10);
    private final Setting rotate = bool("Нысанаға бұрылу", true);

    public KillAura() {
        super("killaura", "КиллАура", "FOV ішіндегі жақын нысанаға өзі бұрылып, автоматты ұрады");
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null) return;
        LivingEntity best = null;
        double bd = range.num();
        for (var e : mc.world.getEntities()) {
            if (!Util.validTarget(p, e, mobs.on())) continue;
            double d = Util.boxDist(p.getEyePos(), e.getBoundingBox());
            if (fov.num() < 360 && Util.angleTo(p, Util.center(e)) > fov.num() / 2.0) continue;
            if (d <= bd) { bd = d; best = (LivingEntity) e; }
        }
        if (best == null) return;
        if (rotate.on()) Util.aimSilent(p, Util.center(best));
        if (p.getAttackCooldownProgress(0.5f) >= 0.95f) Util.attack(mc, p, best);
    }
}
