package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;

/** Рич: ұру қашықтығын үлкейтеді. Сервер әдетте ~1 блоктан артығын қабылдамайды. */
public class Reach extends Module {
    private final Setting range = num("Қашықтық", 3.6, 3.0, 4.5, 0.1);

    public Reach() {
        super("reach", "Рич", "Ұру қашықтығын үлкейтеді (серверде ~4 блоктан артығы өтпейді)");
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
            if (a != null) a.setBaseValue(3.0);
        }
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        EntityAttributeInstance a = p.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
        if (a != null) a.setBaseValue(range.num());
    }
}
