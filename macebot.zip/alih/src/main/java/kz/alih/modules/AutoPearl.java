package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * АвтоПерл: HP аз болып, жақында қарсылас тұрса, қарсыластан ең алыс бағытқа перл лақтырып қашады.
 */
public class AutoPearl extends Module {
    private final Setting minHp = num("HP шегі", 8, 2, 20, 1);
    private final Setting threatRange = num("Қауіп қашықтығы", 8, 3, 20, 1);
    private final Setting delay = num("Кідіріс (тик)", 80, 20, 400, 10);

    private int cooldown, prevSlot = -1;

    public AutoPearl() {
        super("autopearl", "АвтоПерл", "HP аз болса, қарсыластан алыс бағытқа перл лақтырып қашады");
    }

    @Override
    public void reset() { cooldown = 0; prevSlot = -1; }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (prevSlot >= 0) { Util.select(p, prevSlot); prevSlot = -1; return; }
        if (cooldown > 0) { cooldown--; return; }
        if (mc.currentScreen != null) return;
        if (p.getHealth() + p.getAbsorptionAmount() > minHp.num()) return;

        List<Vec3d> threats = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (Util.validPlayer(p, e) && e.distanceTo(p) <= threatRange.num()) threats.add(Util.pos(e));
        }
        if (threats.isEmpty()) return;
        if (!Util.hasInInventory(p, s -> s.isOf(Items.ENDER_PEARL))) return;

        // 16 бағыттың ішінен: алды ашық және қарсыластардан ең алыс түсетін бағыт
        Vec3d me = Util.pos(p);
        double bestScore = -1;
        double bx = 0, bz = 0;
        for (int a = 0; a < 16; a++) {
            double ang = a * Math.PI / 8.0;
            double dx = -Math.sin(ang), dz = Math.cos(ang);
            if (!clear(mc, p, dx, dz)) continue;
            Vec3d land = new Vec3d(me.x + dx * 18, me.y, me.z + dz * 18);
            double score = Double.MAX_VALUE;
            for (Vec3d t : threats) score = Math.min(score, t.distanceTo(land));
            if (score > bestScore) { bestScore = score; bx = dx; bz = dz; }
        }
        if (bestScore < 0) return;

        int slot = Util.grab(mc, p, s -> s.isOf(Items.ENDER_PEARL));
        if (slot < 0) return;
        int cur = Util.selected(p);
        Util.select(p, slot);
        Util.aimNow(p, new Vec3d(me.x + bx * 18, p.getEyeY() + 9, me.z + bz * 18));
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        if (cur != slot) prevSlot = cur;
        cooldown = (int) delay.num();
    }

    /** Бағыттың алдында 4 блок бос па (перл қабырғаға соғылмасын). */
    private boolean clear(MinecraftClient mc, ClientPlayerEntity p, double dx, double dz) {
        for (int k = 1; k <= 4; k++) {
            BlockPos feet = BlockPos.ofFloored(p.getX() + dx * k, p.getY(), p.getZ() + dz * k);
            BlockPos head = feet.up(2);
            if (mc.world.getBlockState(feet.up()).isSolidBlock(mc.world, feet.up())) return false;
            if (mc.world.getBlockState(head).isSolidBlock(mc.world, head)) return false;
        }
        return true;
    }
}
