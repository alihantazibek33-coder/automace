package kz.alih;

import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Silent rotation: камера бұрылмайды, серверге ғана керекті бұрыш жіберіледі.
 * ClientPlayerEntityMixin қозғалыс пакеттерін жіберер алдында бұрышты ауыстырып, кейін қайтарады.
 */
public final class SilentAim {
    private static boolean pending, applied;
    private static float tYaw, tPitch, savedYaw, savedPitch;
    public static float curYaw, curPitch;
    private static int ticks, lastSet = -100;

    private SilentAim() {}

    public static void set(float yaw, float pitch) {
        pending = true;
        tYaw = yaw;
        tPitch = pitch;
        curYaw = yaw;
        curPitch = pitch;
        lastSet = ticks;
    }

    /** Соңғы тиктерде silent бұру қолданылды ма (бастапқы бұрыш ретінде жалғастыру үшін). */
    public static boolean baselineValid() { return ticks - lastSet <= 6; }

    public static void tickEnd() { ticks++; }

    public static void apply(ClientPlayerEntity p) {
        if (!pending) return;
        savedYaw = p.getYaw();
        savedPitch = p.getPitch();
        p.setYaw(tYaw);
        p.setPitch(tPitch);
        applied = true;
    }

    public static void restore(ClientPlayerEntity p) {
        if (applied) {
            p.setYaw(savedYaw);
            p.setPitch(savedPitch);
            applied = false;
        }
        pending = false;
    }
}
