package kz.alih;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Блок қойып салушы қозғалтқыш (АвтоПостройка және АвтоШаблон үшін ортақ). */
public final class Builder {
    public static final class Entry {
        public final BlockPos pos;
        public final Block block;

        public Entry(BlockPos pos, Block block) {
            this.pos = pos;
            this.block = block;
        }
    }

    public final List<Entry> entries = new ArrayList<>();
    public boolean walk = true;
    public boolean breakBlocks = true;
    public int perTick = 4;
    public int lastPlaced;

    private final Map<Long, Integer> placedAt = new HashMap<>();
    private final Map<String, Integer> missing = new LinkedHashMap<>();
    private int tick;

    public Map<String, Integer> missing() { return missing; }

    public void clear() {
        entries.clear();
        placedAt.clear();
        missing.clear();
    }

    private static Map<Item, Integer> counts(ClientPlayerEntity p) {
        Map<Item, Integer> have = new HashMap<>();
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isEmpty()) have.merge(s.getItem(), s.getCount(), Integer::sum);
        }
        ItemStack off = p.getOffHandStack();
        if (!off.isEmpty()) have.merge(off.getItem(), off.getCount(), Integer::sum);
        return have;
    }

    private static boolean wantsAir(Entry e) {
        return e.block.getDefaultState().isAir();
    }

    private void refreshMissing(MinecraftClient mc, ClientPlayerEntity p) {
        Map<Item, Integer> need = new HashMap<>();
        for (Entry e : entries) {
            if (wantsAir(e)) continue;
            if (mc.world.getBlockState(e.pos).isOf(e.block)) continue;
            Item it = e.block.asItem();
            if (it == Items.AIR) continue;
            need.merge(it, 1, Integer::sum);
        }
        Map<Item, Integer> have = counts(p);
        missing.clear();
        for (Map.Entry<Item, Integer> n : need.entrySet()) {
            int lack = n.getValue() - have.getOrDefault(n.getKey(), 0);
            if (lack > 0) missing.put(n.getKey().getName().getString(), lack);
        }
    }

    /** true — салу бітті (бәрі қойылды). */
    public boolean tick(MinecraftClient mc, ClientPlayerEntity p) {
        tick++;
        lastPlaced = 0;
        if (entries.isEmpty()) return true;
        if (tick % 20 == 1) refreshMissing(mc, p);

        Map<Item, Integer> have = counts(p);
        Vec3d eye = p.getEyePos();
        boolean broke = false;
        Entry nearest = null;
        double nd = Double.MAX_VALUE;
        int scanned = 0;

        Iterator<Entry> it = entries.iterator();
        while (it.hasNext() && lastPlaced < perTick) {
            Entry e = it.next();
            if (++scanned > 700) break;
            BlockState cur = mc.world.getBlockState(e.pos);
            boolean wantAir = wantsAir(e);

            if (wantAir ? cur.isAir() : cur.isOf(e.block)) { it.remove(); continue; }
            Integer pt = placedAt.get(e.pos.asLong());
            if (pt != null && tick - pt < 8) continue;

            double d = eye.distanceTo(Vec3d.ofCenter(e.pos));
            boolean free = cur.isAir() || cur.isReplaceable();

            if (!free || wantAir) {                       // алдымен сындыру керек
                if (!breakBlocks) { if (!wantAir) continue; it.remove(); continue; }
                if (d <= 4.5) {
                    if (!broke) { breakAt(mc, p, e.pos, cur); broke = true; }
                } else if (d < nd) { nd = d; nearest = e; }
                continue;
            }

            Item item = e.block.asItem();
            if (item == Items.AIR) { it.remove(); continue; }
            int h = have.getOrDefault(item, 0);
            if (h <= 0) continue;                          // блок жетпейді — өткізіп жібереді
            if (d > 4.5) {
                if (d < nd) { nd = d; nearest = e; }
                continue;
            }

            Direction supportDir = null;
            for (Direction dir : Direction.values()) {
                BlockState ns = mc.world.getBlockState(e.pos.offset(dir));
                if (!ns.isAir() && ns.getFluidState().isEmpty() && !ns.isReplaceable()) { supportDir = dir; break; }
            }
            if (supportDir == null) continue;

            int slot = Util.grab(mc, p, s -> s.isOf(item));
            if (slot < 0) continue;
            Util.select(p, slot);
            Util.place(mc, p, e.pos.offset(supportDir), supportDir.getOpposite());
            have.put(item, h - 1);
            placedAt.put(e.pos.asLong(), tick);
            lastPlaced++;
        }

        if (lastPlaced == 0 && !broke && nearest != null && walk) {
            Util.walkTo(mc, p, Vec3d.ofCenter(nearest.pos), false);
        }
        return entries.isEmpty();
    }

    private void breakAt(MinecraftClient mc, ClientPlayerEntity p, BlockPos pos, BlockState st) {
        int best = Util.selected(p);
        float bm = p.getInventory().getStack(best).getMiningSpeedMultiplier(st);
        for (int i = 0; i < 9; i++) {
            float m = p.getInventory().getStack(i).getMiningSpeedMultiplier(st);
            if (m > bm) { bm = m; best = i; }
        }
        Util.select(p, best);
        Vec3d c = Vec3d.ofCenter(pos);
        Vec3d eye = p.getEyePos();
        Direction side = Direction.getFacing(eye.x - c.x, eye.y - c.y, eye.z - c.z);
        Util.aimAt(p, c);
        mc.interactionManager.updateBlockBreakingProgress(pos, side);
        p.swingHand(Hand.MAIN_HAND);
    }
}
