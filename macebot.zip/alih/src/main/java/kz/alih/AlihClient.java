package kz.alih;

import kz.alih.gui.MenuScreen;
import kz.alih.modules.AntiInvis;
import kz.alih.modules.AutoAim;
import kz.alih.modules.ChatHide;
import kz.alih.modules.EspPlayers;
import kz.alih.modules.AutoAnchor;
import kz.alih.modules.AutoBase;
import kz.alih.modules.AutoBlock;
import kz.alih.modules.AutoBuild;
import kz.alih.modules.AutoMine;
import kz.alih.modules.AutoPearl;
import kz.alih.modules.AutoShablon;
import kz.alih.modules.AutoSpawner;
import kz.alih.modules.XRay;
import kz.alih.modules.AutoBow;
import kz.alih.modules.AutoMark;
import kz.alih.modules.KillAura;
import kz.alih.modules.AutoTotem;
import kz.alih.modules.AutoArmor;
import kz.alih.modules.ChestStealer;
import kz.alih.modules.Scaffold;
import kz.alih.modules.AutoSprint;
import kz.alih.modules.FpsBoost;
import kz.alih.modules.Humanize;
import kz.alih.modules.Fullbright;
import kz.alih.modules.HitBox;
import kz.alih.modules.Esp;
import kz.alih.modules.Zoom;
import kz.alih.modules.Reach;
import kz.alih.modules.Velocity;
import kz.alih.modules.NoFall;
import kz.alih.modules.Step;
import kz.alih.modules.Speed;
import kz.alih.modules.Fly;
import kz.alih.modules.AntiAfk;
import kz.alih.modules.AutoCart;
import kz.alih.modules.AutoCrystal;
import kz.alih.modules.AutoShieldBreak;
import kz.alih.modules.AutoWeb;
import kz.alih.modules.AutoHeadWeb;
import kz.alih.modules.HeadWebPlate;
import kz.alih.modules.AutoDrain;
import kz.alih.modules.StunSlam;
import kz.alih.modules.ElytraMace;
import kz.alih.modules.TriggerBot18;
import kz.alih.modules.TriggerBot19;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class AlihClient implements ClientModInitializer {
    public static final List<Module> MODULES = new ArrayList<>();
    public static int menuKey = GLFW.GLFW_KEY_RIGHT_SHIFT;

    private boolean menuWasDown;
    private final java.util.Set<String> loggedErrors = new java.util.HashSet<>();
    private net.minecraft.client.world.ClientWorld lastWorld;

    @Override
    public void onInitializeClient() {
        MODULES.add(new ElytraMace());
        MODULES.add(new AutoAnchor());
        MODULES.add(new TriggerBot19());
        MODULES.add(new TriggerBot18());
        MODULES.add(new AutoCrystal());
        MODULES.add(new AutoShieldBreak());
        MODULES.add(new AutoCart());
        MODULES.add(new AutoWeb());
        MODULES.add(new AutoHeadWeb());
        MODULES.add(new HeadWebPlate());
        MODULES.add(new AutoDrain());
        MODULES.add(new StunSlam());
        MODULES.add(new AutoAim());
        MODULES.add(new AutoBow());
        MODULES.add(new AutoMark());
        MODULES.add(new AutoBase());
        MODULES.add(new AutoBlock());
        MODULES.add(new AutoBuild());
        MODULES.add(new AutoShablon());
        MODULES.add(new AntiInvis());
        MODULES.add(new XRay());
        MODULES.add(new FpsBoost());
        MODULES.add(new Humanize());
        MODULES.add(new AutoMine());
        MODULES.add(new AutoPearl());
        MODULES.add(new AutoSpawner());
        MODULES.add(new KillAura());
        MODULES.add(new AutoTotem());
        MODULES.add(new AutoArmor());
        MODULES.add(new ChestStealer());
        MODULES.add(new Scaffold());
        MODULES.add(new AutoSprint());
        MODULES.add(new Fullbright());
        MODULES.add(new HitBox());
        MODULES.add(new Esp());
        MODULES.add(new Zoom());
        MODULES.add(new Reach());
        MODULES.add(new Velocity());
        MODULES.add(new NoFall());
        MODULES.add(new Step());
        MODULES.add(new Speed());
        MODULES.add(new Fly());
        MODULES.add(new AntiAfk());
        MODULES.add(new ChatHide());
        MODULES.add(new EspPlayers());
        Config.load();

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback.EVENT.register((ctx, tickCounter) -> { XRay.renderHud(ctx); EspPlayers.renderHud(ctx); });
        ClientSendMessageEvents.ALLOW_CHAT.register(this::onChat);

        // Shift + ПКМ: АвтоЭлитраМейс үшін нысананы белгілеу / алу
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (player != mc.player || hand != Hand.MAIN_HAND) return ActionResult.PASS;
            if (!player.isSneaking() || !Util.validTarget(mc.player, entity, true)) return ActionResult.PASS;
            if (entity.getUuid().equals(ElytraMace.lockedId)) {
                ElytraMace.lockedId = null;
                Util.msg("Нысана алынды. Енді ең жақын моб/игрокты ұрады");
            } else {
                ElytraMace.lockedId = entity.getUuid();
                Util.msg("Нысана белгіленді: " + entity.getName().getString() + " (тек соны ұрады)");
            }
            return ActionResult.SUCCESS;
        });

        // АвтоОтметка үшін: соңғы басқан блок (сундук)
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (player == mc.player) {
                AutoMark.lastUsed = hit.getBlockPos();
                ItemStack held = player.getStackInHand(hand);
                if (hand == Hand.MAIN_HAND && held.getItem() instanceof BlockItem bi && AutoShablon.INSTANCE != null
                        && AutoShablon.INSTANCE.enabled && !Util.placing) {
                    BlockPos pos = hit.getBlockPos();
                    if (!world.getBlockState(pos).isReplaceable()) pos = pos.offset(hit.getSide());
                    AutoShablon.INSTANCE.trigger(bi.getBlock(), pos, player.getHorizontalFacing());
                }
                if (hand == Hand.MAIN_HAND && held.isOf(net.minecraft.item.Items.RESPAWN_ANCHOR)
                        && AutoAnchor.INSTANCE != null && !Util.placing) {
                    BlockPos pos = hit.getBlockPos();
                    net.minecraft.block.BlockState bs = world.getBlockState(pos);
                    if (!bs.isOf(net.minecraft.block.Blocks.RESPAWN_ANCHOR) || player.isSneaking()) {
                        if (!bs.isReplaceable()) pos = pos.offset(hit.getSide());
                        AutoAnchor.INSTANCE.notePlaced(pos);
                    }
                }
            }
            return ActionResult.PASS;
        });

        // АвтоПрицел үшін: соңғы ұрған нысананы есте сақтау
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (player == MinecraftClient.getInstance().player && entity instanceof LivingEntity) {
                AutoAim.lastHit = entity.getUuid();
            }
            return ActionResult.PASS;
        });
    }

    private void tick(MinecraftClient mc) {
        SilentAim.tickEnd();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) {
            // әлемнен шықты / жүктелуде: қосулы функциялар қосулы күйінде қалады, тек ішкі күйі тазаланады
            if (lastWorld != null) {
                lastWorld = null;
                for (Module m : MODULES) m.reset();
            }
            return;
        }
        if (mc.world != lastWorld) {
            if (lastWorld != null) {
                for (Module m : MODULES) m.reset();   // өлшем/сервер ауысты
            }
            lastWorld = mc.world;
        }
        Util.trackVelocities(mc);
        if (HitBox.INSTANCE != null) HitBox.INSTANCE.assist(mc);   // ТБот/КиллАура т.б. үшін

        if (mc.currentScreen == null) {
            boolean md = Util.isDown(menuKey);
            if (md && !menuWasDown) mc.setScreen(new MenuScreen());
            menuWasDown = md;
            for (Module m : MODULES) {
                boolean d = Util.isDown(m.key);
                if (d && !m.wasDown && !m.keyPressed(mc, false)) m.toggle();
                m.wasDown = d;
            }
        } else {
            menuWasDown = Util.isDown(menuKey);
            boolean inv = mc.currentScreen instanceof HandledScreen<?>;
            for (Module m : MODULES) {
                boolean d = Util.isDown(m.key);
                if (inv && d && !m.wasDown) m.keyPressed(mc, true);
                m.wasDown = d;
            }
        }

        for (Module m : MODULES) {
            try {
                m.alwaysTick(mc, p);
            } catch (Exception e) {
                if (loggedErrors.add(m.id)) System.err.println("[AlihClient] alwaysTick қатесі (" + m.id + "): " + e);
            }
        }

        for (Module m : MODULES) {
            if (!m.enabled) continue;
            try {
                m.onTick(mc, p);
            } catch (Exception e) {
                m.setEnabled(false);
                Util.msg(m.name + " қатемен өшірілді: " + e.getClass().getSimpleName());
            }
        }
    }

    private static Module find(String id) {
        for (Module mod : MODULES) {
            if (mod.id.equalsIgnoreCase(id)) return mod;
        }
        return null;
    }

    private boolean onChat(String message) {
        String m = message.trim();
        String[] a = m.split("\\s+");
        if (!a[0].equalsIgnoreCase(".alih")) return true;

        if (a.length >= 2 && (a[1].equalsIgnoreCase("list") || a[1].equalsIgnoreCase("help"))) {
            StringBuilder sb = new StringBuilder();
            for (Module mod : MODULES) sb.append(mod.id).append(mod.enabled ? "(ON) " : " ");
            Util.msg("Функциялар: " + sb);
            Util.msg(".alih on|off|toggle <id> | .alih info <id> | .alih set <id> <№> <мән> | .alih bind <id> <кнопка>");
        } else if (a.length >= 3 && (a[1].equalsIgnoreCase("on") || a[1].equalsIgnoreCase("off") || a[1].equalsIgnoreCase("toggle"))) {
            Module mod = find(a[2]);
            if (mod == null) {
                Util.msg("Мұндай функция жоқ: " + a[2] + " (.alih list)");
            } else {
                final String act = a[1].toLowerCase();
                MinecraftClient.getInstance().execute(() -> {
                    if (act.equals("on")) mod.setEnabled(true);
                    else if (act.equals("off")) mod.setEnabled(false);
                    else mod.toggle();
                });
            }
        } else if (a.length >= 3 && a[1].equalsIgnoreCase("info")) {
            Module mod = find(a[2]);
            if (mod == null) {
                Util.msg("Мұндай функция жоқ: " + a[2]);
            } else {
                Util.msg(mod.name + " [" + mod.id + "] " + (mod.enabled ? "ON" : "OFF") + ", бинд: " + Util.keyName(mod.key));
                for (int i = 0; i < mod.settings.size(); i++) {
                    Setting st = mod.settings.get(i);
                    Util.msg((i + 1) + ") " + st.name + " = " + st.display());
                }
            }
        } else if (a.length >= 5 && a[1].equalsIgnoreCase("set")) {
            Module mod = find(a[2]);
            try {
                int idx = Integer.parseInt(a[3]) - 1;
                if (mod == null || idx < 0 || idx >= mod.settings.size()) {
                    Util.msg("Қате функция немесе нөмір");
                } else {
                    Setting st = mod.settings.get(idx);
                    switch (st.type) {
                        case BOOL -> st.b = a[4].equalsIgnoreCase("true") || a[4].equals("1") || a[4].equalsIgnoreCase("on");
                        case NUM -> st.v = Math.max(st.min, Math.min(st.max, Double.parseDouble(a[4])));
                        case MODE -> st.m = Math.floorMod(Integer.parseInt(a[4]), st.modes.length);
                    }
                    Config.save();
                    Util.msg(st.name + " = " + st.display());
                }
            } catch (NumberFormatException ex) {
                Util.msg(".alih set <id> <№> <мән>");
            }
        } else if (a.length >= 4 && a[1].equalsIgnoreCase("bind")) {
            Module mod = find(a[2]);
            int code = Util.parseKey(a[3]);
            if (mod == null || code == Util.UNSET) {
                Util.msg("Қате функция немесе кнопка (мыс: R, G, F6, MOUSE4)");
            } else {
                mod.key = code;
                Config.save();
                Util.msg(mod.name + " бинд: " + Util.keyName(code));
            }
        } else if (a.length >= 2 && a[1].equalsIgnoreCase("ignore")) {
            String sub = a.length >= 3 ? a[2].toLowerCase() : "list";
            if (sub.equals("add") && a.length >= 4) {
                Util.IGNORED.add(Util.norm(a[3]));
                Config.save();
                Util.msg("Тізімге қосылды: " + a[3]);
            } else if (sub.equals("remove") && a.length >= 4) {
                Util.msg(Util.IGNORED.remove(Util.norm(a[3])) ? "Тізімнен алынды: " + a[3] : "Тізімде жоқ: " + a[3]);
                Config.save();
            } else {
                Util.msg("Ignore тізімі: " + (Util.IGNORED.isEmpty() ? "бос" : String.join(", ", Util.IGNORED))
                        + "  (.alih ignore add/remove <ник>)");
            }
        } else if (a.length >= 2 && a[1].equalsIgnoreCase("xray")) {
            String sub = a.length >= 3 ? a[2].toLowerCase() : "list";
            if (sub.equals("add") && a.length >= 4) {
                Util.msg(XRay.addCustom(a[3]) ? "XRay-ге қосылды: " + a[3] : "Мұндай блок жоқ: " + a[3]);
                Config.save();
                MinecraftClient.getInstance().execute(() -> { for (Module mod : MODULES) if (mod instanceof XRay && mod.enabled) { mod.setEnabled(false); mod.setEnabled(true); } });
            } else if (sub.equals("remove") && a.length >= 4) {
                XRay.CUSTOM.remove(a[3].toLowerCase().replace("minecraft:", ""));
                Config.save();
                Util.msg("XRay-ден алынды: " + a[3]);
                MinecraftClient.getInstance().execute(() -> { for (Module mod : MODULES) if (mod instanceof XRay && mod.enabled) { mod.setEnabled(false); mod.setEnabled(true); } });
            } else {
                Util.msg("XRay қосымша блоктар: " + (XRay.CUSTOM.isEmpty() ? "жоқ" : String.join(", ", XRay.CUSTOM))
                        + "  (.alih xray add/remove <блок_id>)");
            }
        } else if (a.length >= 2 && a[1].equalsIgnoreCase("build")) {
            AutoBuild ab = AutoBuild.INSTANCE;
            String sub = a.length >= 3 ? a[2].toLowerCase() : "status";
            if (ab != null) {
                MinecraftClient.getInstance().execute(() -> {
                    switch (sub) {
                        case "pos1" -> ab.setPos1();
                        case "pos2" -> ab.setPos2();
                        case "copy" -> ab.copy();
                        case "here" -> ab.setHere();
                        case "start" -> ab.start();
                        case "stop" -> ab.stop();
                        case "clear" -> ab.clearAll();
                        default -> ab.status();
                    }
                });
            }
        } else if (a.length >= 2 && a[1].equalsIgnoreCase("base")) {
            String sub = a.length >= 3 ? a[2].toLowerCase() : "list";
            AutoBase ab = AutoBase.INSTANCE;
            if (ab != null) {
                if (sub.equals("go") && a.length >= 4) {
                    try {
                        final int n = Integer.parseInt(a[3]);
                        MinecraftClient.getInstance().execute(() -> ab.goToSaved(n));
                    } catch (NumberFormatException e) {
                        Util.msg(".alih base go <нөмір>");
                    }
                } else if (sub.equals("clear")) {
                    ab.clearBases();
                } else {
                    ab.listBases();
                }
            }
        } else if (a.length >= 2 && a[1].equalsIgnoreCase("mark")) {
            for (Module mod : MODULES) {
                if (mod instanceof AutoMark am) am.clear();
            }
            Util.msg("АвтоОтметка тазаланды");
        } else if (a.length >= 2 && a[1].equalsIgnoreCase("clear")) {
            ElytraMace.lockedId = null;
            Util.msg("Белгіленген нысана тазаланды");
        } else {
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.execute(() -> mc.setScreen(new MenuScreen()));
        }
        return false;
    }
}
