package kz.alih;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.FallingBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;

public final class Util {

    /** Timestamp of the latest client tick, used for ESP interpolation. */
    public static volatile long tickNanos = System.nanoTime();
    public static final int UNSET = Integer.MIN_VALUE;

    /** Осы никтарға модтар еш уақытта жұмыс істемейді (үнсіз). */
    public static final Set<String> IGNORED = new LinkedHashSet<>(Arrays.asList("tylaamshk", "itsalih", "itssoyotezz"));

    private static final Map<UUID, Vec3d> PREV = new HashMap<>();
    private static final Map<UUID, Vec3d> VEL = new HashMap<>();

    private Util() {}

    public static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    public static void msg(String s) {
        MinecraftClient mc = mc();
        if (mc.inGameHud != null) {
            mc.inGameHud.getChatHud().addMessage(Text.literal("[Alih] " + s));
        }
    }

    // ------------------------------------------------------------ input

    public static boolean isDown(int code) {
        if (code == UNSET) return false;
        long w = mc().getWindow().getHandle();
        return code >= 0
                ? GLFW.glfwGetKey(w, code) == GLFW.GLFW_PRESS
                : GLFW.glfwGetMouseButton(w, -code - 1) == GLFW.GLFW_PRESS;
    }

    public static int parseKey(String raw) {
        String s = raw.toUpperCase();
        if (s.length() == 1) {
            char c = s.charAt(0);
            if (c >= 'A' && c <= 'Z') return GLFW.GLFW_KEY_A + (c - 'A');
            if (c >= '0' && c <= '9') return GLFW.GLFW_KEY_0 + (c - '0');
        }
        if (s.matches("F([1-9]|1[0-2])")) return GLFW.GLFW_KEY_F1 + Integer.parseInt(s.substring(1)) - 1;
        return switch (s) {
            case "SPACE" -> GLFW.GLFW_KEY_SPACE;
            case "RSHIFT" -> GLFW.GLFW_KEY_RIGHT_SHIFT;
            case "LSHIFT" -> GLFW.GLFW_KEY_LEFT_SHIFT;
            case "LCTRL" -> GLFW.GLFW_KEY_LEFT_CONTROL;
            case "RCTRL" -> GLFW.GLFW_KEY_RIGHT_CONTROL;
            case "RALT" -> GLFW.GLFW_KEY_RIGHT_ALT;
            case "TAB" -> GLFW.GLFW_KEY_TAB;
            case "DELETE" -> GLFW.GLFW_KEY_DELETE;
            case "HOME" -> GLFW.GLFW_KEY_HOME;
            case "END" -> GLFW.GLFW_KEY_END;
            case "LALT" -> GLFW.GLFW_KEY_LEFT_ALT;
            case "INSERT" -> GLFW.GLFW_KEY_INSERT;
            case "MOUSE3" -> -3;
            case "MOUSE4" -> -4;
            case "MOUSE5" -> -5;
            default -> UNSET;
        };
    }

    public static String keyName(int code) {
        if (code == UNSET) return "—";
        if (code < 0) return "MOUSE" + (-code);
        if (code >= GLFW.GLFW_KEY_F1 && code <= GLFW.GLFW_KEY_F12) return "F" + (code - GLFW.GLFW_KEY_F1 + 1);
        switch (code) {
            case GLFW.GLFW_KEY_SPACE: return "SPACE";
            case GLFW.GLFW_KEY_RIGHT_SHIFT: return "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "LSHIFT";
            case GLFW.GLFW_KEY_LEFT_ALT: return "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT: return "RALT";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCTRL";
            case GLFW.GLFW_KEY_TAB: return "TAB";
            case GLFW.GLFW_KEY_INSERT: return "INSERT";
            case GLFW.GLFW_KEY_DELETE: return "DELETE";
            case GLFW.GLFW_KEY_HOME: return "HOME";
            case GLFW.GLFW_KEY_END: return "END";
            default: break;
        }
        String n = GLFW.glfwGetKeyName(code, 0);
        return n != null ? n.toUpperCase() : "KEY" + code;
    }

    // ------------------------------------------------------------ inventory

    public static int findHotbar(PlayerEntity p, Predicate<ItemStack> f) {
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isEmpty() && f.test(s)) return i;
        }
        return -1;
    }

    public static boolean hasInInventory(PlayerEntity p, Predicate<ItemStack> f) {
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isEmpty() && f.test(s)) return true;
        }
        return false;
    }

    public static void select(PlayerEntity p, int slot) {
        if (slot >= 0 && slot < 9) p.getInventory().setSelectedSlot(slot);
    }

    public static int selected(PlayerEntity p) {
        return p.getInventory().getSelectedSlot();
    }


    // ------------------------------------------------------------ inventory (бүкіл инвентарь)

    /** Хотбарда тұрмаса, негізгі инвентарьдан хотбарға алып келеді. Хотбар слотын қайтарады (-1 — зат жоқ). */
    public static int grab(MinecraftClient mc, ClientPlayerEntity p, Predicate<ItemStack> f) {
        int h = findHotbar(p, f);
        if (h >= 0) return h;
        for (int i = 9; i < 36; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isEmpty() && f.test(s)) {
                int scratch = scratchSlot(p);
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, i, scratch, SlotActionType.SWAP, p);
                return scratch;
            }
        }
        return -1;
    }

    private static boolean essential(ItemStack s) {
        return s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES) || s.isOf(Items.MACE) || s.isOf(Items.BOW)
                || s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE) || s.isOf(Items.ELYTRA)
                || s.isOf(Items.FIREWORK_ROCKET);
    }

    private static int scratchSlot(PlayerEntity p) {
        for (int i = 8; i >= 0; i--) {
            if (p.getInventory().getStack(i).isEmpty()) return i;
        }
        for (int i = 8; i >= 0; i--) {
            if (!essential(p.getInventory().getStack(i))) return i;
        }
        return 8;
    }

    public static boolean isBuildBlock(World w, ItemStack s) {
        if (!(s.getItem() instanceof BlockItem bi)) return false;
        Block b = bi.getBlock();
        if (b instanceof FallingBlock || b == Blocks.TNT || b == Blocks.OBSIDIAN || b == Blocks.CRYING_OBSIDIAN
                || b == Blocks.RESPAWN_ANCHOR || b == Blocks.GLOWSTONE || b == Blocks.COBWEB) return false;
        return b.getDefaultState().isSolidBlock(w, BlockPos.ORIGIN);
    }

    public static boolean hasBuildBlock(MinecraftClient mc, PlayerEntity p) {
        return hasInInventory(p, s -> isBuildBlock(mc.world, s));
    }

    public static Vec3d pos(Entity e) {
        return new Vec3d(e.getX(), e.getY(), e.getZ());
    }

    /** Нүктеге қарай жүгіреді (yaw бұрады, forward басады). */
    public static void walkTo(MinecraftClient mc, ClientPlayerEntity p, Vec3d pt, boolean sprint) {
        double dx = pt.x - p.getX(), dz = pt.z - p.getZ();
        smoothYaw(p, (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90f);
        mc.options.forwardKey.setPressed(true);
        if (sprint) mc.options.sprintKey.setPressed(true);
        if (p.horizontalCollision && p.isOnGround()) mc.options.jumpKey.setPressed(true);
    }

    // ------------------------------------------------------------ geometry / aim

    public static double boxDist(Vec3d from, Box b) {
        double dx = Math.max(Math.max(b.minX - from.x, 0), from.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - from.y, 0), from.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - from.z, 0), from.z - b.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    public static Vec3d center(Entity e) {
        return new Vec3d(e.getX(), e.getY() + e.getHeight() * 0.5, e.getZ());
    }

    private static final java.util.Random RND = new java.util.Random();

    /** Адамша бұру: тегіс (easing) және аздап кездейсоқ ауытқумен. Көп тикке созылады. */
    public static void aimAt(ClientPlayerEntity p, Vec3d pt) {
        Vec3d eye = p.getEyePos();
        double dx = pt.x - eye.x, dy = pt.y - eye.y, dz = pt.z - eye.z;
        float ty = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        float tp = MathHelper.clamp((float) -(MathHelper.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI), -90f, 90f);
        float dyaw = MathHelper.wrapDegrees(ty - p.getYaw());
        float dpit = tp - p.getPitch();
        double dist = Math.hypot(dyaw, dpit);
        if (dist < 0.6) {
            p.setYaw(ty);
            p.setPitch(tp);
            return;
        }
        double step = Math.min(dist, Math.max(3.0, dist * 0.30 + RND.nextDouble() * 2.0));
        step = Math.min(step, 55.0);
        double k = step / dist;
        p.setYaw(p.getYaw() + kz.alih.modules.Humanize.q((float) (dyaw * k + (RND.nextDouble() - 0.5) * 0.4)));
        p.setPitch(MathHelper.clamp(p.getPitch() + kz.alih.modules.Humanize.q((float) (dpit * k + (RND.nextDouble() - 0.5) * 0.3)), -90f, 90f));
    }

    /**
     * Ұрыс үшін: silent rotation қосулы болса, камера бұрылмайды, тек серверге бұрыш барады.
     * Әйтпесе әдеттегі тегіс бұру. Камерадағы кроссхейр керек функцияларда (қазу, ұшу) aimAt қолдан.
     */
    public static void aimSilent(ClientPlayerEntity p, Vec3d pt) {
        if (!kz.alih.modules.Humanize.silentOn()) { aimAt(p, pt); return; }
        float cy = SilentAim.baselineValid() ? SilentAim.curYaw : p.getYaw();
        float cp = SilentAim.baselineValid() ? SilentAim.curPitch : p.getPitch();
        Vec3d eye = p.getEyePos();
        double dx = pt.x - eye.x, dy = pt.y - eye.y, dz = pt.z - eye.z;
        float ty = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        float tp = MathHelper.clamp((float) -(MathHelper.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI), -90f, 90f);
        float dyaw = MathHelper.wrapDegrees(ty - cy);
        float dpit = tp - cp;
        double dist = Math.hypot(dyaw, dpit);
        double step = dist < 0.6 ? dist : Math.min(dist, Math.min(55.0, Math.max(3.0, dist * 0.30 + RND.nextDouble() * 2.0)));
        double k = dist < 0.0001 ? 0 : step / dist;
        float ny = cy + kz.alih.modules.Humanize.q((float) (dyaw * k));
        float np = MathHelper.clamp(cp + kz.alih.modules.Humanize.q((float) (dpit * k)), -90f, 90f);
        SilentAim.set(ny, np);
    }

    /** Бірден дәл бұру (шелек, перл сияқты бағыт дәл керек жерлерде). */
    public static void aimNow(ClientPlayerEntity p, Vec3d pt) {
        Vec3d eye = p.getEyePos();
        double dx = pt.x - eye.x, dy = pt.y - eye.y, dz = pt.z - eye.z;
        float yaw = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        double horiz = Math.sqrt(dx * dx + dz * dz);
        float pitch = (float) -(MathHelper.atan2(dy, horiz) * 180.0 / Math.PI);
        p.setYaw(yaw);
        p.setPitch(MathHelper.clamp(pitch, -90f, 90f));
    }

    public static void aimAt(ClientPlayerEntity p, double x, double y, double z) {
        aimAt(p, new Vec3d(x, y, z));
    }

    public static void aimNow(ClientPlayerEntity p, double x, double y, double z) {
        aimNow(p, new Vec3d(x, y, z));
    }

    /** Yaw-ды нысана бұрышқа қарай тегіс бұрады. */
    public static void smoothYaw(ClientPlayerEntity p, float targetYaw) {
        float d = MathHelper.wrapDegrees(targetYaw - p.getYaw());
        if (Math.abs(d) < 0.8f) { p.setYaw(targetYaw); return; }
        float step = (float) Math.min(Math.abs(d), Math.max(2.5, Math.abs(d) * 0.25 + RND.nextDouble() * 1.5));
        p.setYaw(p.getYaw() + Math.signum(d) * step);
    }

    public static void smoothPitch(ClientPlayerEntity p, float targetPitch) {
        float d = targetPitch - p.getPitch();
        if (Math.abs(d) < 0.8f) { p.setPitch(targetPitch); return; }
        float step = (float) Math.min(Math.abs(d), Math.max(2.0, Math.abs(d) * 0.25 + RND.nextDouble() * 1.0));
        p.setPitch(p.getPitch() + Math.signum(d) * step);
    }

    /** Прицелді тегіс бұрады (maxStep — бір тиктегі максимал градус). */
    public static void smoothAim(ClientPlayerEntity p, Vec3d pt, float maxStep) {
        Vec3d eye = p.getEyePos();
        double dx = pt.x - eye.x, dy = pt.y - eye.y, dz = pt.z - eye.z;
        float ty = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        float tp = (float) -(MathHelper.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);
        float dyaw = MathHelper.clamp(MathHelper.wrapDegrees(ty - p.getYaw()), -maxStep, maxStep);
        float dpit = MathHelper.clamp(tp - p.getPitch(), -maxStep, maxStep);
        p.setYaw(p.getYaw() + dyaw);
        p.setPitch(MathHelper.clamp(p.getPitch() + dpit, -90f, 90f));
    }

    /** Көру бағыты мен нүкте арасындағы бұрыш (градус). */
    public static double angleTo(ClientPlayerEntity p, Vec3d pt) {
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d dir = pt.subtract(p.getEyePos()).normalize();
        double dot = MathHelper.clamp(look.dotProduct(dir), -1.0, 1.0);
        return Math.toDegrees(Math.acos(dot));
    }

    // ------------------------------------------------------------ world interaction

    /** support блогының side бетіне ПКМ басады (блок қою). */
    /** Модульдер блок қойып жатқанда true (UseBlockCallback өз қойғанымызды ажырата алуы үшін). */
    public static boolean placing;

    public static void place(MinecraftClient mc, ClientPlayerEntity p, BlockPos support, Direction side) {
        Vec3d hit = Vec3d.ofCenter(support).add(side.getOffsetX() * 0.5, side.getOffsetY() * 0.5, side.getOffsetZ() * 0.5);
        BlockHitResult r = new BlockHitResult(hit, side, support, false);
        placing = true;
        try {
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, r);
        } finally {
            placing = false;
        }
        p.swingHand(Hand.MAIN_HAND);
    }

    /** base + 0..extra кездейсоқ кідіріс (адамша). */
    public static int jitter(int base, int extra) {
        return base + RND.nextInt(Math.max(1, extra));
    }

    /** pos-қа блок қояды: қолдау болатын көршіні (төменгіні бірінші) өзі табады. true — қойылды. */
    public static boolean placeBlockAt(MinecraftClient mc, ClientPlayerEntity p, BlockPos pos) {
        net.minecraft.block.BlockState cur = mc.world.getBlockState(pos);
        if (!(cur.isAir() || cur.isReplaceable())) return false;
        for (Direction d : Direction.values()) {
            BlockPos n = pos.offset(d);
            net.minecraft.block.BlockState ns = mc.world.getBlockState(n);
            if (ns.isAir() || !ns.getFluidState().isEmpty() || ns.isReplaceable()) continue;
            if (p.getEyePos().distanceTo(Vec3d.ofCenter(n)) > 5.0) continue;
            place(mc, p, n, d.getOpposite());
            return true;
        }
        return false;
    }

    public static void attack(MinecraftClient mc, ClientPlayerEntity p, Entity t) {
        if (isIgnored(t)) return; // ignore тізіміндегі игрокқа ешбір функция ұрмайды
        SilentAim.flush(p);
        mc.interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
    }

    // ------------------------------------------------------------ targets

    /** Никті салыстыруға қолайлы түрге келтіреді (формат кодтары мен бос орындарсыз, кіші әріппен). */
    public static String norm(String s) {
        return s == null ? "" : s.replaceAll("§.", "").trim().toLowerCase();
    }

    public static boolean isIgnored(Entity e) {
        return e instanceof PlayerEntity pl && IGNORED.contains(norm(pl.getName().getString()));
    }

    /** Pos маңында (r блок) ignore тізіміндегі игрок бар ма (жарылыс/лава/паутинадан сақтау үшін). */
    public static boolean ignoredNear(MinecraftClient mc, Vec3d pos, double r) {
        if (mc.world == null) return false;
        double r2 = r * r;
        for (Entity o : mc.world.getEntities()) {
            if (isIgnored(o) && o != mc.player && o.squaredDistanceTo(pos) <= r2) return true;
        }
        return false;
    }

    public static boolean validPlayer(ClientPlayerEntity self, Entity e) {
        if (!(e instanceof PlayerEntity pl) || e == self || !pl.isAlive() || pl.isSpectator()) return false;
        return !isIgnored(pl);
    }

    public static boolean validTarget(ClientPlayerEntity self, Entity e, boolean mobs) {
        if (e == null || e == self || !(e instanceof LivingEntity le) || !le.isAlive()) return false;
        if (e instanceof ArmorStandEntity) return false;
        if (e instanceof PlayerEntity) return validPlayer(self, e);
        if (e instanceof VillagerEntity) return false;
        if (e instanceof TameableEntity te && te.isTamed()) return false;
        return mobs;
    }

    public static PlayerEntity nearestPlayer(MinecraftClient mc, ClientPlayerEntity p, double range) {
        PlayerEntity best = null;
        double bd = range;
        for (Entity o : mc.world.getEntities()) {
            if (!validPlayer(p, o)) continue;
            double d = o.distanceTo(p);
            if (d < bd) { bd = d; best = (PlayerEntity) o; }
        }
        return best;
    }

    /** Ең жақын нысана (игрок, mobs=true болса моб та). */
    public static LivingEntity nearestTarget(MinecraftClient mc, ClientPlayerEntity p, double range, boolean mobs) {
        LivingEntity best = null;
        double bd = range;
        for (Entity o : mc.world.getEntities()) {
            if (!validTarget(p, o, mobs)) continue;
            double d = o.distanceTo(p);
            if (d < bd) { bd = d; best = (LivingEntity) o; }
        }
        return best;
    }

    public static Entity entityById(MinecraftClient mc, UUID id) {
        if (id == null || mc.world == null) return null;
        for (Entity o : mc.world.getEntities()) {
            if (o.getUuid().equals(id)) return o;
        }
        return null;
    }

    // ------------------------------------------------------------ velocity tracker

    public static void trackVelocities(MinecraftClient mc) {
        tickNanos = System.nanoTime();
        if (mc.world == null) { PREV.clear(); VEL.clear(); return; }
        Set<UUID> seen = new java.util.HashSet<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity)) continue;
            seen.add(e.getUuid());
            Vec3d cur = new Vec3d(e.getX(), e.getY(), e.getZ());
            Vec3d old = PREV.put(e.getUuid(), cur);
            if (old != null) VEL.put(e.getUuid(), cur.subtract(old));
        }
        // жоғалған (өлген/алыстап кеткен) энтитилерді тазалау: жад ағып кетпесін
        PREV.keySet().retainAll(seen);
        VEL.keySet().retainAll(seen);
    }

    public static Vec3d vel(Entity e) {
        return VEL.getOrDefault(e.getUuid(), Vec3d.ZERO);
    }
}
