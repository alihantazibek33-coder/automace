package kz.alih.mixin;

import kz.alih.SilentAim;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void alih$silentPre(CallbackInfo ci) {
        SilentAim.apply((ClientPlayerEntity) (Object) this);
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"))
    private void alih$silentPost(CallbackInfo ci) {
        SilentAim.restore((ClientPlayerEntity) (Object) this);
    }
}
