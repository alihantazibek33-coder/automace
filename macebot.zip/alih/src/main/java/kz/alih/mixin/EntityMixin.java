package kz.alih.mixin;

import kz.alih.modules.HitBox;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "getTargetingMargin", at = @At("HEAD"), cancellable = true)
    private void alih$margin(CallbackInfoReturnable<Float> cir) {
        float m = HitBox.marginFor((Entity) (Object) this);
        if (m > 0f) cir.setReturnValue(m);
    }
}
