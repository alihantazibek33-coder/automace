package kz.macebot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import java.util.UUID;
import java.util.function.Predicate;

public class MaceBotClient implements ClientModInitializer {

    private enum Phase { TAKEOFF, CLIMB, APPROACH, STRIKE, RECOVER }

    private static final int UNSET = Integer.MIN_VALUE;
    private static final double REACH = 3.0;          // ұру қашықтығы
    private static final double PREP_DIST = 9.0;      // осы қашықтықта броняға ауысады
    private static final double SEARCH_RADIUS = 96.0; // нысана іздеу радиусы

    private final Path configPath = FabricLoader.getInstance().getConfigDir().resolve("macebot.properties");

    private String keyName = "";
    private int keyCode = UNSET;
    private double climbHeight = 40.0;

    private boolean active = false;
    private boolean wasDown = false;
    private Phase phase = Phase.TAKEOFF;
    private UUID targetId;
    private UUID lockedId; // Shift + ПКМ арқылы белгіленген нысана
    private double startY;
    private int tickCount, fireworkCooldown, phaseTicks, swapCooldown;
    private boolean chestSwapped;

    @Override
    public void onInitializeClient() {
        loadConfig();
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        ClientSendMessageEvents.ALLOW_CHAT.register(this::onChat);

        // Shift + ПКМ -> нысананы белгілеу (қайта басса — алып тастау)
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (player != mc.player || hand != Hand.MAIN_HAND) return ActionResult.PASS;
            if (!player.isSneaking() || !isValidTarget(mc.player, entity)) return ActionResult.PASS;
            if (entity.getUuid().equals(lockedId)) {
                lockedId = null;
                msg("Нысана алынды. Енді ең жақын моб/игрокты ұрады");
            } else {
                lockedId = entity.getUuid();
                msg("Нысана белгіленді: " + entity.getName().getString() + " (тек соны ұрады)");
            }
            return ActionResult.SUCCESS;
        });
    }

    // ---------------------------------------------------------------- команда

    private boolean onChat(String message) {
        String m = message.trim();
        if (!m.toLowerCase().startsWith(".mace")) return true;
        MinecraftClient mc = MinecraftClient.getInstance();
        String[] a = m.split("\\s+");

        if (a.length >= 3 && a[1].equalsIgnoreCase("keybind")) {
            int code = parseKey(a[2]);
            if (code == UNSET) {
                msg("Белгісіз кнопка: " + a[2] + " (мыс: R, G, F6, MOUSE4, LALT)");
            } else {
                keyCode = code;
                keyName = a[2].toUpperCase();
                saveConfig();
                msg("Keybind қойылды: " + keyName);
            }
        } else if (a.length >= 3 && a[1].equalsIgnoreCase("height")) {
            try {
                climbHeight = MathHelper.clamp(Double.parseDouble(a[2]), 10, 200);
                saveConfig();
                msg("Ұшу биіктігі: " + (int) climbHeight);
            } catch (NumberFormatException e) {
                msg("Сан жаз: .mace height 40");
            }
        } else if (a.length >= 2 && a[1].equalsIgnoreCase("clear")) {
            lockedId = null;
            msg("Белгіленген нысана тазаланды");
        } else if (a.length >= 2 && a[1].equalsIgnoreCase("toggle")) {
            mc.execute(() -> toggle(mc));
        } else {
            msg(".mace keybind <кнопка> | .mace toggle | .mace height <сан> | .mace clear");
        }
        return false; // чатқа жіберілмейді
    }

    // ---------------------------------------------------------------- tick

    private void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) {
            active = false;
            return;
        }
        tickCount++;

        if (keyCode != UNSET && mc.currentScreen == null) {
            long w = mc.getWindow().getHandle();
            boolean down = keyCode >= 0
                    ? GLFW.glfwGetKey(w, keyCode) == GLFW.GLFW_PRESS
                    : GLFW.glfwGetMouseButton(w, -keyCode - 1) == GLFW.GLFW_PRESS;
            if (down && !wasDown) toggle(mc);
            wasDown = down;
        }

        if (!active || mc.currentScreen != null) return;
        if (fireworkCooldown > 0) fireworkCooldown--;
        if (swapCooldown > 0) swapCooldown--;
        phaseTicks++;

        LivingEntity t = findTarget(mc);
        if (t == null || !t.isAlive()) {
            if (t != null && t.getUuid().equals(lockedId)) lockedId = null;
            stop(mc, t == null ? "Нысана жоғалды, өшірілді" : "Нысана өлді, өшірілді");
            return;
        }

        switch (phase) {
            case TAKEOFF -> doTakeoff(mc, p);
            case CLIMB -> doClimb(mc, p, t);
            case APPROACH -> doApproach(mc, p, t);
            case STRIKE -> doStrike(mc, p, t);
            case RECOVER -> {
                if (phaseTicks > 6) setPhase(Phase.TAKEOFF);
            }
        }
    }

    private void toggle(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (active) {
            stop(mc, "ӨШІРІЛДІ");
            return;
        }
        Entity best = null;
        if (lockedId != null) {
            best = entityById(mc, lockedId);
            if (best == null || !best.isAlive()) {
                msg("Белгіленген нысана жақын жерде жоқ (.mace clear — тазалау)");
                return;
            }
        } else {
            double bestD = SEARCH_RADIUS;
            for (Entity o : mc.world.getEntities()) {
                if (!isValidTarget(p, o)) continue;
                double d = o.distanceTo(p);
                if (d < bestD) { bestD = d; best = o; }
            }
            if (best == null) { msg("Жақын жерде нысана (моб/игрок) жоқ"); return; }
        }

        boolean elytra = isElytra(p.getEquippedStack(EquipmentSlot.CHEST)) || findHotbar(p, MaceBotClient::isElytra) >= 0;
        if (!elytra) { msg("Хотбарда элитра жоқ"); return; }
        if (findHotbar(p, s -> s.isOf(Items.MACE)) < 0) { msg("Хотбарда мейс жоқ"); return; }
        if (findHotbar(p, s -> s.isOf(Items.FIREWORK_ROCKET)) < 0) { msg("Хотбарда фейерверк жоқ"); return; }

        targetId = best.getUuid();
        active = true;
        chestSwapped = false;
        setPhase(Phase.TAKEOFF);
        msg("ҚОСЫЛДЫ → нысана: " + best.getName().getString());
    }

    private void stop(MinecraftClient mc, String text) {
        active = false;
        mc.options.jumpKey.setPressed(false);
        msg(text);
    }

    private void setPhase(Phase ph) {
        phase = ph;
        phaseTicks = 0;
    }

    // ---------------------------------------------------------------- фазалар

    private void doTakeoff(MinecraftClient mc, ClientPlayerEntity p) {
        if (!isElytra(p.getEquippedStack(EquipmentSlot.CHEST))) {
            if (swapCooldown == 0) {
                int slot = findHotbar(p, MaceBotClient::isElytra);
                if (slot < 0) { stop(mc, "Элитра табылмады, өшірілді"); return; }
                swapChest(mc, p, slot);
            }
            return;
        }
        chestSwapped = false;

        if (p.isGliding()) {
            mc.options.jumpKey.setPressed(false);
            startY = p.getY();
            setPhase(Phase.CLIMB);
            return;
        }
        if (p.isOnGround()) {
            mc.options.jumpKey.setPressed(true);
        } else if (p.getVelocity().y < -0.05) {
            mc.options.jumpKey.setPressed(tickCount % 2 == 0); // басу/босату -> глайд басталады
        } else {
            mc.options.jumpKey.setPressed(false);
        }
    }

    private void doClimb(MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        if (!p.isGliding()) { setPhase(Phase.TAKEOFF); return; }
        aim(p, t.getYaw(), -55f, true, t);

        int fw = findHotbar(p, s -> s.isOf(Items.FIREWORK_ROCKET));
        boolean high = p.getY() - startY >= climbHeight;
        if (high || fw < 0 || phaseTicks > 200) {
            setPhase(Phase.APPROACH);
            return;
        }
        if (fireworkCooldown == 0) {
            useFirework(mc, p, fw);
        }
    }

    private void doApproach(MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        if (!isElytra(p.getEquippedStack(EquipmentSlot.CHEST))) { setPhase(Phase.TAKEOFF); return; }
        if (!p.isGliding()) {
            if (p.isOnGround()) { setPhase(Phase.TAKEOFF); return; }
            mc.options.jumpKey.setPressed(tickCount % 2 == 0);
        } else {
            mc.options.jumpKey.setPressed(false);
        }

        aim(p, 0, 0, false, t);

        double dist = boxDist(p.getEyePos(), t.getBoundingBox());
        double speed = p.getVelocity().length();

        int mace = findHotbar(p, s -> s.isOf(Items.MACE));
        int fw = findHotbar(p, s -> s.isOf(Items.FIREWORK_ROCKET));

        // жылдамдық түсіп кетсе, алыс болса — қосымша фейерверк
        if (dist > 20 && speed < 0.9 && fw >= 0 && fireworkCooldown == 0 && p.isGliding()) {
            useFirework(mc, p, fw);
            return;
        }
        if (mace >= 0) p.getInventory().setSelectedSlot(mace);

        if (dist <= PREP_DIST) {
            if (!chestSwapped) {
                int chest = findHotbar(p, s -> !isElytra(s) && p.getPreferredEquipmentSlot(s) == EquipmentSlot.CHEST);
                if (chest >= 0) {
                    swapChest(mc, p, chest);   // элитра шешіледі, броня киіледі
                }
                chestSwapped = true;
            }
            setPhase(Phase.STRIKE);
        }
    }

    private void doStrike(MinecraftClient mc, ClientPlayerEntity p, LivingEntity t) {
        mc.options.jumpKey.setPressed(false);
        aim(p, 0, 0, false, t);

        int mace = findHotbar(p, s -> s.isOf(Items.MACE));
        if (mace >= 0) p.getInventory().setSelectedSlot(mace);

        double dist = boxDist(p.getEyePos(), t.getBoundingBox());
        if (dist <= REACH + 0.2) {
            if (p.getAttackCooldownProgress(0.5f) >= 0.9f || phaseTicks > 10) {
                mc.interactionManager.attackEntity(p, t);
                p.swingHand(Hand.MAIN_HAND);
                setPhase(Phase.RECOVER);
            }
            return;
        }
        if (dist > 20 || phaseTicks > 60 || p.isOnGround()) {
            setPhase(Phase.TAKEOFF);
        }
    }

    // ---------------------------------------------------------------- көмекші

    private LivingEntity findTarget(MinecraftClient mc) {
        Entity e = entityById(mc, targetId);
        return e instanceof LivingEntity le ? le : null;
    }

    private Entity entityById(MinecraftClient mc, UUID id) {
        if (id == null) return null;
        for (Entity o : mc.world.getEntities()) {
            if (o.getUuid().equals(id)) return o;
        }
        return null;
    }

    private static boolean isValidTarget(ClientPlayerEntity self, Entity e) {
        if (e == null || e == self || !(e instanceof LivingEntity le) || !le.isAlive()) return false;
        if (e instanceof ArmorStandEntity) return false;
        if (e instanceof PlayerEntity pl && pl.isSpectator()) return false;
        return true;
    }

    private void useFirework(MinecraftClient mc, ClientPlayerEntity p, int slot) {
        p.getInventory().setSelectedSlot(slot);
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.swingHand(Hand.MAIN_HAND);
        fireworkCooldown = 14;
    }

    /** Кеудеше слотын (6) хотбар слотымен ауыстырады. */
    private void swapChest(MinecraftClient mc, ClientPlayerEntity p, int hotbarSlot) {
        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, 6, hotbarSlot, SlotActionType.SWAP, p);
        swapCooldown = 3;
    }

    private void aim(ClientPlayerEntity p, float fixedYaw, float fixedPitch, boolean fixed, LivingEntity t) {
        Vec3d eye = p.getEyePos();
        Vec3d to = t.getPos().add(0, t.getHeight() * 0.5, 0).subtract(eye);
        float yaw = (float) (MathHelper.atan2(to.z, to.x) * 180.0 / Math.PI) - 90f;
        double horiz = Math.sqrt(to.x * to.x + to.z * to.z);
        float pitch = (float) -(MathHelper.atan2(to.y, horiz) * 180.0 / Math.PI);
        if (fixed) {
            // көтерілу кезінде нысана жаққа қарап, жоғары қарай ұшады
            Vec3d d = t.getPos().subtract(p.getPos());
            yaw = (float) (MathHelper.atan2(d.z, d.x) * 180.0 / Math.PI) - 90f;
            pitch = fixedPitch;
        }
        p.setYaw(yaw);
        p.setPitch(MathHelper.clamp(pitch, -90f, 90f));
    }

    private static boolean isElytra(ItemStack s) {
        return s.isOf(Items.ELYTRA);
    }

    private static int findHotbar(PlayerEntity p, Predicate<ItemStack> f) {
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isEmpty() && f.test(s)) return i;
        }
        return -1;
    }

    private static double boxDist(Vec3d from, Box b) {
        double dx = Math.max(Math.max(b.minX - from.x, 0), from.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - from.y, 0), from.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - from.z, 0), from.z - b.maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private void msg(String s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.inGameHud != null) {
            mc.inGameHud.getChatHud().addMessage(Text.literal("[Mace] " + s));
        }
    }

    // ---------------------------------------------------------------- кнопка / config

    private static int parseKey(String raw) {
        String s = raw.toUpperCase();
        if (s.length() == 1) {
            char c = s.charAt(0);
            if (c >= 'A' && c <= 'Z') return GLFW.GLFW_KEY_A + (c - 'A');
            if (c >= '0' && c <= '9') return GLFW.GLFW_KEY_0 + (c - '0');
        }
        if (s.matches("F([1-9]|1[0-2])")) return GLFW.GLFW_KEY_F1 + Integer.parseInt(s.substring(1)) - 1;
        return switch (s) {
            case "SPACE" -> GLFW.GLFW_KEY_SPACE;
            case "TAB" -> GLFW.GLFW_KEY_TAB;
            case "LALT" -> GLFW.GLFW_KEY_LEFT_ALT;
            case "LCTRL" -> GLFW.GLFW_KEY_LEFT_CONTROL;
            case "LSHIFT" -> GLFW.GLFW_KEY_LEFT_SHIFT;
            case "CAPS" -> GLFW.GLFW_KEY_CAPS_LOCK;
            case "UP" -> GLFW.GLFW_KEY_UP;
            case "DOWN" -> GLFW.GLFW_KEY_DOWN;
            case "LEFT" -> GLFW.GLFW_KEY_LEFT;
            case "RIGHT" -> GLFW.GLFW_KEY_RIGHT;
            case "INSERT" -> GLFW.GLFW_KEY_INSERT;
            case "DELETE" -> GLFW.GLFW_KEY_DELETE;
            case "HOME" -> GLFW.GLFW_KEY_HOME;
            case "END" -> GLFW.GLFW_KEY_END;
            case "PGUP" -> GLFW.GLFW_KEY_PAGE_UP;
            case "PGDN" -> GLFW.GLFW_KEY_PAGE_DOWN;
            case "MOUSE3" -> -3; // ортаңғы
            case "MOUSE4" -> -4;
            case "MOUSE5" -> -5;
            default -> UNSET;
        };
    }

    private void loadConfig() {
        if (!Files.exists(configPath)) return;
        try (Reader r = Files.newBufferedReader(configPath)) {
            Properties pr = new Properties();
            pr.load(r);
            keyName = pr.getProperty("key", "");
            if (!keyName.isEmpty()) keyCode = parseKey(keyName);
            climbHeight = Double.parseDouble(pr.getProperty("height", "40"));
        } catch (IOException | NumberFormatException ignored) {
        }
    }

    private void saveConfig() {
        Properties pr = new Properties();
        pr.setProperty("key", keyName);
        pr.setProperty("height", String.valueOf(climbHeight));
        try (Writer w = Files.newBufferedWriter(configPath)) {
            pr.store(w, "MaceBot");
        } catch (IOException ignored) {
        }
    }
}
