package kz.alih;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Angerable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.WardenEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Ортақ навигация/аман жүру жүйесі (АвтоБаза мен АвтоСпавнер қолданады):
 *  - жүру: лава, өрт, кактус, шұңқыр (терең құлау) болса айналып өтеді (бірнеше бағытты тексеріп, ең қауіпсізін таңдайды);
 *  - кедергі: 1 блокқа секіреді, қабырғаны қазады (қазу қауіпті болса — айналады), тұрып қалса бағытын өзгертеді;
 *  - су: бетінде жүзеді;  лавага түссе — жағаға шығады;
 *  - құлау: биіктен құласа су шелегін астына құяды да, түскен соң қайта алады (шелек жоқ болса — паутина);
 *  - мобтар: жақындаған дұшпан мобты ұрады;  аз HP кезінде алтын алма жейді.
 */
public final class Nav {
    // ---- баптаулар (модуль әр тикте қояды)
    public boolean dig = true;
    public boolean avoid = true;
    public boolean fallGuard = true;
    public double fallMin = 8;
    public boolean fightMobs = true;
    public boolean avoidWater = false;     // су басып кетпесін/суға түспесін
    public boolean avoidFalling = false;   // құм/қиыршық тастан аулақ (құлап тұншықтырады)
    public double spawnerR = 0;            // спавнерге осы қашықтықта қазбайды (0 — өшірулі)

    private static final int FREE = 0, STEP = 1, WALL = 2, HAZ = 3;

    private final Random rnd = new Random();

    // жүру күйі
    private float commitYaw;
    private int commitT, tick, lastDig, stuckCount;
    private Vec3d lastPos = Vec3d.ZERO;
    private final Map<Long, Integer> badWalls = new HashMap<>();
    private int dyOut;

    // құлаудан қорғау күйі
    private enum Clutch { IDLE, PREP, PLACED, PICKUP }
    private Clutch clutch = Clutch.IDLE;
    private boolean useWater;
    private int prevSlot = -1, clutchT;
    private double peakY;
    private BlockPos groundPos, placedPos;

    private int healT;

    public void reset() {
        commitT = 0;
        stuckCount = 0;
        clutch = Clutch.IDLE;
        prevSlot = -1;
        healT = 0;
        badWalls.clear();
    }

    // ================================================================ блок көмекшілері

    private static BlockState st(MinecraftClient mc, BlockPos p) { return mc.world.getBlockState(p); }

    /** Блоктың соқтығысу биіктігі (0 — өтуге болады, 1 — толық блок, 1.5 — қоршау). */
    private static double top(MinecraftClient mc, BlockPos pos) {
        VoxelShape sh = st(mc, pos).getCollisionShape(mc.world, pos);
        return sh.isEmpty() ? 0.0 : sh.getMax(Direction.Axis.Y);
    }

    private static boolean lavaAt(MinecraftClient mc, BlockPos pos) { return st(mc, pos).getFluidState().isIn(FluidTags.LAVA); }

    private static boolean waterAt(MinecraftClient mc, BlockPos pos) { return st(mc, pos).getFluidState().isIn(FluidTags.WATER); }

    private static boolean badBlock(BlockState s) {
        return s.isOf(Blocks.CACTUS) || s.isOf(Blocks.MAGMA_BLOCK) || s.isOf(Blocks.FIRE) || s.isOf(Blocks.SOUL_FIRE)
                || s.isOf(Blocks.CAMPFIRE) || s.isOf(Blocks.SOUL_CAMPFIRE) || s.isOf(Blocks.SWEET_BERRY_BUSH)
                || s.isOf(Blocks.WITHER_ROSE) || s.isOf(Blocks.POWDER_SNOW);
    }

    private static boolean hazard(MinecraftClient mc, BlockPos pos) {
        return lavaAt(mc, pos) || badBlock(st(mc, pos));
    }

    private boolean dangerAround(MinecraftClient mc, BlockPos pos) {
        return Mine.unsafe(mc, pos, avoidWater, avoidFalling, spawnerR);
    }

    /** Аяқ қойылатын ұяшықты бағалайды. dyOut — биіктік өзгерісі. */
    private int cell(MinecraftClient mc, BlockPos feet) {
        dyOut = 0;
        if (hazard(mc, feet) || hazard(mc, feet.up())) return HAZ;
        if (waterAt(mc, feet)) return avoidWater ? HAZ : FREE;     // жүзу
        double ft = top(mc, feet), ht = top(mc, feet.up());
        if (ft == 0 && ht == 0) {
            for (int k = 1; k <= 3; k++) {
                BlockPos b = feet.down(k);
                if (hazard(mc, b)) return HAZ;
                if (waterAt(mc, b)) { dyOut = -k; return FREE; }
                if (top(mc, b) > 0) { dyOut = -(k - 1); return FREE; }
            }
            return HAZ;                                           // терең шұңқыр
        }
        if (ft > 0 && ft <= 1.0 && ht == 0 && top(mc, feet.up(2)) == 0 && !hazard(mc, feet.up(2))) {
            dyOut = 1;
            return STEP;
        }
        return WALL;
    }

    private static final class Scan {
        int steps, walls, hazAt = -1, wallAt = -1;
    }

    private Scan scan(MinecraftClient mc, ClientPlayerEntity p, float yaw, int maxK) {
        double rad = Math.toRadians(yaw);
        double dx = -Math.sin(rad), dz = Math.cos(rad);
        int fy = MathHelper.floor(p.getY() + 0.01);
        Scan s = new Scan();
        for (int k = 1; k <= maxK; k++) {
            BlockPos pos = BlockPos.ofFloored(p.getX() + dx * k, fy, p.getZ() + dz * k);
            int c = cell(mc, pos);
            if (c == HAZ) { s.hazAt = k; break; }
            if (c == WALL) {
                if (!dig || ++s.walls >= 3) { s.wallAt = k; break; }
                s.steps++;
                continue;
            }
            fy += dyOut;
            s.steps++;
        }
        return s;
    }

    private static final float[] OFFS = { 0, 30, -30, 60, -60, 90, -90, 130, -130, 180 };

    /** Бағыт таңдау: ең қауіпсіз әрі нысанаға жақын бағыт. */
    private float choose(MinecraftClient mc, ClientPlayerEntity p, float want) {
        float bestYaw = want;
        double best = -1e9;
        for (float off : OFFS) {
            float y = want + off;
            Scan s = scan(mc, p, y, 6);
            double score = s.steps * 2.0 - s.walls * 1.5;
            if (s.wallAt > 0) score -= 2.0;
            if (s.hazAt > 0 && s.hazAt <= 2) score -= 100;
            else if (s.hazAt > 0) score -= 3;
            score -= Math.abs(off) / 25.0;
            if (score > best) { best = score; bestYaw = y; }
        }
        return bestYaw;
    }

    // ================================================================ жүру

    public void walk(MinecraftClient mc, ClientPlayerEntity p, double x, double z) {
        tick++;
        if (tick % 400 == 0) badWalls.values().removeIf(v -> v < tick);

        float want = (float) (MathHelper.atan2(z - p.getZ(), x - p.getX()) * 180.0 / Math.PI) - 90f;
        float yaw = want;
        if (commitT > 0) {
            commitT--;
            yaw = commitYaw;
            if (avoid) {
                Scan chk = scan(mc, p, yaw, 3);
                if (chk.hazAt > 0 && chk.hazAt <= 2) commitT = 0;
            }
        }
        if (commitT <= 0 && avoid) {
            Scan direct = scan(mc, p, want, 6);
            if (direct.hazAt < 0 && direct.wallAt < 0 && direct.walls == 0) {
                yaw = want;
            } else {
                yaw = choose(mc, p, want);
                if (Math.abs(MathHelper.wrapDegrees(yaw - want)) > 1f) { commitYaw = yaw; commitT = 14; }
            }
        } else if (commitT <= 0) {
            yaw = want;
        }

        Util.smoothYaw(p, yaw);
        Util.smoothPitch(p, 0f);

        boolean inWater = p.isTouchingWater();
        Scan real = scan(mc, p, p.getYaw(), 3);
        boolean hazAhead = avoid && real.hazAt > 0 && real.hazAt <= 2;
        boolean digging = false;

        if (!hazAhead || inWater) {
            mc.options.forwardKey.setPressed(true);
            mc.options.sprintKey.setPressed(!inWater && real.hazAt < 0);
            double rad = Math.toRadians(p.getYaw());
            BlockPos ahead = BlockPos.ofFloored(p.getX() - Math.sin(rad), MathHelper.floor(p.getY() + 0.01), p.getZ() + Math.cos(rad));
            int c = cell(mc, ahead);
            if (c == STEP) {
                if (p.isOnGround()) mc.options.jumpKey.setPressed(true);
            } else if (c == WALL) {
                if (dig) digging = digAhead(mc, p, ahead, want);
                else { commitYaw = want + (rnd.nextBoolean() ? 90f : -90f); commitT = 20; }
            }
        }
        // су бетінде жүзу (тұншықпау)
        if (inWater || p.isSubmergedInWater()) mc.options.jumpKey.setPressed(true);

        if (digging) lastDig = tick;

        // тұрып қалды ма?
        if (tick % 40 == 0) {
            Vec3d now = Util.pos(p);
            if (tick - lastDig > 40 && now.distanceTo(lastPos) < 0.8) {
                stuckCount++;
                commitYaw = want + (stuckCount % 2 == 0 ? 1 : -1) * (50f + rnd.nextInt(70));
                commitT = 25;
            } else if (now.distanceTo(lastPos) >= 0.8) {
                stuckCount = 0;
            }
            lastPos = now;
        }
    }

    private boolean digAhead(MinecraftClient mc, ClientPlayerEntity p, BlockPos feetAhead, float want) {
        BlockPos target = null;
        for (BlockPos c : new BlockPos[] { feetAhead, feetAhead.up(), feetAhead.up(2) }) {
            if (top(mc, c) > 0) { target = c; break; }
        }
        if (target == null) return false;
        long key = target.asLong();
        Integer until = badWalls.get(key);
        BlockState s = st(mc, target);
        if ((until != null && until > tick) || s.getHardness(mc.world, target) < 0 || dangerAround(mc, target)) {
            badWalls.put(key, tick + 300);
            commitYaw = want + (rnd.nextBoolean() ? 90f : -90f);
            commitT = 25;
            return false;
        }
        mineTool(mc, p, s);
        Util.aimAt(p, Vec3d.ofCenter(target));
        mc.options.attackKey.setPressed(true);
        return true;
    }

    private void mineTool(MinecraftClient mc, ClientPlayerEntity p, BlockState s) {
        Mine.selectTool(mc, p, s);
    }

    // ================================================================ күзет: лава + құлау

    /** true — осы тикті күзет алды (модуль басқа ештеңе істемесін). */
    public boolean guard(MinecraftClient mc, ClientPlayerEntity p, boolean flying) {
        if (p.isInLava()) {
            lavaEscape(mc, p);
            return true;
        }
        return fallStep(mc, p, flying);
    }

    private void lavaEscape(MinecraftClient mc, ClientPlayerEntity p) {
        BlockPos me = p.getBlockPos();
        BlockPos best = null;
        double bd = 1e9;
        for (int dx = -6; dx <= 6; dx++) {
            for (int dz = -6; dz <= 6; dz++) {
                for (int dy = -1; dy <= 2; dy++) {
                    BlockPos b = me.add(dx, dy, dz);
                    if (lavaAt(mc, b) || lavaAt(mc, b.up()) || badBlock(st(mc, b))) continue;
                    if (top(mc, b) != 0 || top(mc, b.up()) != 0) continue;
                    if (top(mc, b.down()) <= 0 || lavaAt(mc, b.down())) continue;
                    double d = dx * dx + dz * dz + dy * dy * 2.0;
                    if (d < bd) { bd = d; best = b; }
                }
            }
        }
        if (best != null) {
            float yaw = (float) (MathHelper.atan2(best.getZ() + 0.5 - p.getZ(), best.getX() + 0.5 - p.getX()) * 180.0 / Math.PI) - 90f;
            p.setYaw(yaw);
            mc.options.forwardKey.setPressed(true);
        }
        mc.options.jumpKey.setPressed(true);
    }

    /** [қашықтық (аяқтан жер бетіне дейін), түрі: 0 қатты, 1 су, 2 лава, 3 бос (void)] */
    private double[] probe(MinecraftClient mc, ClientPlayerEntity p) {
        BlockPos start = BlockPos.ofFloored(p.getX(), p.getY() - 0.05, p.getZ());
        int bottom = mc.world.getBottomY();
        for (int k = 0; k < 200; k++) {
            BlockPos b = start.down(k);
            if (b.getY() < bottom) break;
            BlockState s = st(mc, b);
            if (s.getFluidState().isIn(FluidTags.LAVA)) { groundPos = b; return new double[] { p.getY() - (b.getY() + 1), 2 }; }
            if (s.getFluidState().isIn(FluidTags.WATER)) { groundPos = b; return new double[] { p.getY() - (b.getY() + 1), 1 }; }
            double t = top(mc, b);
            if (t > 0) { groundPos = b; return new double[] { p.getY() - (b.getY() + t), 0 }; }
        }
        return new double[] { 999, 3 };
    }

    private static boolean isFalling(ClientPlayerEntity p) {
        return !p.isOnGround() && p.getVelocity().y < -0.35 && !p.isTouchingWater() && !p.isGliding()
                && !p.isClimbing() && !p.isCreative() && !p.isSpectator();
    }

    private boolean fallStep(MinecraftClient mc, ClientPlayerEntity p, boolean flying) {
        if (!fallGuard) {
            if (clutch != Clutch.IDLE) finish(mc, p);
            return false;
        }
        if (p.isOnGround() || p.isTouchingWater() || p.isGliding()) peakY = p.getY();
        else peakY = Math.max(peakY, p.getY());

        if (clutch == Clutch.IDLE) {
            if (flying || !isFalling(p)) return false;
            double[] g = probe(mc, p);
            if (g[1] == 1 || g[1] == 3) return false;                       // су бар немесе түбі жоқ
            double drop = peakY - (p.getY() - g[0]);
            double dmg = drop - 3.0;
            if (drop < fallMin && dmg < p.getHealth() - 1) return false;    // қауіпсіз биіктік
            boolean nether = mc.world.getRegistryKey() == World.NETHER;
            if (!nether && Util.hasInInventory(p, s -> s.isOf(Items.WATER_BUCKET))) useWater = true;
            else if (Util.hasInInventory(p, s -> s.isOf(Items.COBWEB))) useWater = false;
            else return false;                                              // құтқаратын зат жоқ
            prevSlot = Util.selected(p);
            clutchT = 0;
            clutch = Clutch.PREP;
        }
        if (clutch == Clutch.PREP) return prep(mc, p);
        if (clutch == Clutch.PLACED) return placed(mc, p);
        if (clutch == Clutch.PICKUP) return pickup(mc, p);
        return false;
    }

    private boolean prep(MinecraftClient mc, ClientPlayerEntity p) {
        clutchT++;
        if (!isFalling(p) && (p.isOnGround() || p.isTouchingWater()) || clutchT > 160) { finish(mc, p); return false; }
        int slot = Util.grab(mc, p, s -> useWater ? s.isOf(Items.WATER_BUCKET) : s.isOf(Items.COBWEB));
        if (slot < 0) { finish(mc, p); return false; }
        Util.select(p, slot);
        p.setPitch(90f);
        double[] g = probe(mc, p);
        if (g[1] == 1 || g[1] == 3) { finish(mc, p); return false; }
        if (g[0] <= 2.7) {                                                   // қол жететін қашықтық
            if (useWater) mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            else Util.place(mc, p, groundPos, Direction.UP);
            placedPos = g[1] == 2 ? groundPos : groundPos.up();
            clutch = Clutch.PLACED;
            clutchT = 0;
        }
        return true;
    }

    private boolean placed(MinecraftClient mc, ClientPlayerEntity p) {
        clutchT++;
        p.setPitch(90f);
        boolean landed = p.isOnGround() || p.isTouchingWater();
        if (!landed) {
            if (clutchT > 60) { finish(mc, p); return false; }
            if (clutchT <= 6 && placedPos != null && !(useWater ? waterAt(mc, placedPos) : st(mc, placedPos).isOf(Blocks.COBWEB))) {
                if (useWater) mc.interactionManager.interactItem(p, Hand.MAIN_HAND);   // қайта әрекет
            }
            return true;
        }
        clutch = Clutch.PICKUP;
        clutchT = 0;
        return pickup(mc, p);
    }

    private boolean pickup(MinecraftClient mc, ClientPlayerEntity p) {
        clutchT++;
        p.setPitch(90f);
        if (useWater) {
            int b = Util.grab(mc, p, s -> s.isOf(Items.BUCKET));
            boolean gone = placedPos == null || !waterAt(mc, placedPos);
            if (b < 0 || clutchT > 40 || (clutchT > 2 && gone)) { finish(mc, p); return false; }
            Util.select(p, b);
            if (clutchT % 2 == 0) mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            return true;
        }
        // паутинаны бұзу
        boolean gone = placedPos == null || !st(mc, placedPos).isOf(Blocks.COBWEB);
        if (gone || clutchT > 80) { finish(mc, p); return false; }
        int sw = Util.grab(mc, p, s -> s.isOf(Items.SHEARS) || s.isIn(ItemTags.SWORDS));
        if (sw >= 0) Util.select(p, sw);
        Util.aimAt(p, Vec3d.ofCenter(placedPos));
        mc.options.attackKey.setPressed(true);
        return true;
    }

    private void finish(MinecraftClient mc, ClientPlayerEntity p) {
        clutch = Clutch.IDLE;
        if (prevSlot >= 0) Util.select(p, prevSlot);
        prevSlot = -1;
        mc.options.useKey.setPressed(false);
        mc.options.attackKey.setPressed(false);
    }

    // ================================================================ мобтар + емделу

    public boolean fightMobs(MinecraftClient mc, ClientPlayerEntity p) {
        if (!fightMobs || p.isGliding() || p.isUsingItem()) return false;
        Entity best = null;
        double bd = 3.5 * 3.5;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof Monster) || !e.isAlive() || e instanceof WardenEntity) continue;
            if (e instanceof Angerable a && !a.hasAngerTime()) continue;       // бейбіт (эндермен, пиглин...) — тимейді
            double d = e.squaredDistanceTo(p);
            if (d < bd) { bd = d; best = e; }
        }
        if (best == null) return false;
        int sw = Util.grab(mc, p, s -> s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES));
        if (sw >= 0) Util.select(p, sw);
        Util.aimAt(p, Util.center(best));
        if (p.getAttackCooldownProgress(0.5f) >= 0.92f && Util.boxDist(p.getEyePos(), best.getBoundingBox()) <= 3.0) {
            Util.attack(mc, p, best);
        }
        return true;
    }

    /** HP аз болса алтын алма жейді. true — осы тик жеумен өтті. */
    public boolean heal(MinecraftClient mc, ClientPlayerEntity p, double hpBelow) {
        if (healT == 0 && p.getHealth() > hpBelow) return false;
        int slot = Util.grab(mc, p, s -> s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE));
        if (slot < 0) { healT = 0; return false; }
        Util.select(p, slot);
        mc.options.useKey.setPressed(true);
        healT++;
        if (healT > 45 || (healT > 4 && !p.isUsingItem())) {
            healT = 0;
            mc.options.useKey.setPressed(false);
        }
        return true;
    }
}
