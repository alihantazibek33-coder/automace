package kz.alih.gui;

import kz.alih.AlihClient;
import kz.alih.Config;
import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class MenuScreen extends Screen {
    private static final int W = 440, H = 276;
    private static final int ROW = 22;

    private static final int ACCENT = 0xFFFFC857;
    private static final int PANEL = 0xF0141418;
    private static final int HEAD = 0xFF1E1E26;
    private static final int BTN = 0xFF262630;
    private static final int BTN_HOVER = 0xFF343442;
    private static final int GREEN = 0xFF4CD964;
    private static final int RED = 0xFFFF5C5C;
    private static final int TEXT = 0xFFEDEDED;
    private static final int DIM = 0xFF9A9AA8;

    private Module selected = AlihClient.MODULES.get(0);
    private Module binding;
    private boolean bindingMenuKey;
    private boolean wasLeft, wasRight, first = true;
    private final boolean[] prevKey = new boolean[GLFW.GLFW_KEY_LAST + 1];

    public MenuScreen() {
        super(Text.literal("AlihClient"));
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public boolean shouldCloseOnEsc() { return binding == null && !bindingMenuKey; }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        long win = mc.getWindow().getHandle();

        boolean left = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean right = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean clickL = left && !wasLeft && !first;
        boolean clickR = right && !wasRight && !first;
        wasLeft = left;
        wasRight = right;

        // ---- кнопка тағайындау / меню кнопкасын жабу
        boolean menuEdge = false;
        for (int k = 32; k <= GLFW.GLFW_KEY_LAST; k++) {
            boolean down = GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
            if (down && !prevKey[k] && !first) {
                if (binding != null) {
                    binding.key = (k == GLFW.GLFW_KEY_ESCAPE) ? Util.UNSET : k;
                    binding = null;
                    Config.save();
                } else if (bindingMenuKey) {
                    if (k != GLFW.GLFW_KEY_ESCAPE) AlihClient.menuKey = k;
                    bindingMenuKey = false;
                    Config.save();
                } else if (k == AlihClient.menuKey) {
                    menuEdge = true;
                }
            }
            prevKey[k] = down;
        }
        first = false;
        if (menuEdge) { mc.setScreen(null); return; }

        // ---- фон
        c.fill(0, 0, width, height, 0x90000000);
        int x0 = (width - W) / 2, y0 = (height - H) / 2;
        c.fill(x0, y0, x0 + W, y0 + H, PANEL);
        c.fill(x0, y0, x0 + W, y0 + 28, HEAD);
        c.fill(x0, y0 + 28, x0 + W, y0 + 29, ACCENT);

        String title = "AlihClient";
        c.drawTextWithShadow(tr, title, x0 + (W - tr.getWidth(title)) / 2, y0 + 10, ACCENT);
        String mk = "Меню: " + (bindingMenuKey ? "..." : Util.keyName(AlihClient.menuKey));
        int mkx = x0 + W - tr.getWidth(mk) - 10;
        boolean hMk = in(mx, my, mkx - 3, y0 + 6, x0 + W - 6, y0 + 22);
        c.drawTextWithShadow(tr, mk, mkx, y0 + 10, hMk ? ACCENT : DIM);
        if (hMk && clickL) bindingMenuKey = true;

        // ---- сол жақ: функциялар тізімі
        int lx = x0 + 8, ly = y0 + 36, lw = 200;
        for (int i = 0; i < AlihClient.MODULES.size(); i++) {
            Module m = AlihClient.MODULES.get(i);
            int ry = ly + i * ROW;
            boolean hover = in(mx, my, lx, ry, lx + lw, ry + ROW - 2);
            boolean sel = m == selected;
            c.fill(lx, ry, lx + lw, ry + ROW - 2, sel ? 0xFF30303E : (hover ? BTN_HOVER : BTN));
            if (sel) c.fill(lx, ry, lx + 2, ry + ROW - 2, ACCENT);
            c.drawTextWithShadow(tr, m.name, lx + 8, ry + 6, TEXT);
            String st = m.enabled ? "ON" : "OFF";
            c.drawTextWithShadow(tr, st, lx + lw - tr.getWidth(st) - 26, ry + 6, m.enabled ? GREEN : RED);
            c.drawTextWithShadow(tr, "≡", lx + lw - 14, ry + 6, hover ? ACCENT : DIM);

            if (hover && clickL) {
                if (mx >= lx + lw - 24) selected = m; else m.toggle();
            }
            if (hover && clickR) selected = m;
        }

        // ---- оң жақ: баптаулар
        int rx = x0 + 218, rw = W - 226, ry = y0 + 36;
        Module m = selected;
        c.fill(rx, ry, rx + rw, ry + H - 44, 0xFF1A1A22);
        c.drawTextWithShadow(tr, m.name, rx + 8, ry + 8, ACCENT);
        c.drawTextWithShadow(tr, tr.trimToWidth(m.desc, rw - 16), rx + 8, ry + 22, DIM);

        int sy = ry + 42;
        for (Setting s : m.settings) {
            boolean hover = in(mx, my, rx + 6, sy, rx + rw - 6, sy + ROW - 2);
            c.fill(rx + 6, sy, rx + rw - 6, sy + ROW - 2, hover ? BTN_HOVER : BTN);
            c.drawTextWithShadow(tr, tr.trimToWidth(s.name, rw - 90), rx + 12, sy + 6, TEXT);

            int vx = rx + rw - 12;
            if (s.type == Setting.Type.NUM) {
                String v = s.display();
                int bm = rx + rw - 12 - 14;     // "+"
                int bn = bm - 52;               // "-"
                c.drawTextWithShadow(tr, "-", bn + 3, sy + 6, hover ? ACCENT : DIM);
                c.drawTextWithShadow(tr, v, bn + 12 + (40 - tr.getWidth(v)) / 2, sy + 6, TEXT);
                c.drawTextWithShadow(tr, "+", bm + 3, sy + 6, hover ? ACCENT : DIM);
                if (clickL && in(mx, my, bn - 2, sy, bn + 10, sy + ROW - 2)) { s.dec(); Config.save(); }
                if (clickL && in(mx, my, bm - 2, sy, bm + 12, sy + ROW - 2)) { s.inc(); Config.save(); }
            } else {
                String v = s.display();
                int col = s.type == Setting.Type.BOOL ? (s.b ? GREEN : RED) : TEXT;
                c.drawTextWithShadow(tr, v, vx - tr.getWidth(v), sy + 6, col);
                if (clickL && hover) {
                    if (s.type == Setting.Type.BOOL) s.flip(); else s.cycle();
                    Config.save();
                }
            }
            sy += ROW;
        }

        // ---- бинд
        boolean hb = in(mx, my, rx + 6, sy, rx + rw - 6, sy + ROW - 2);
        c.fill(rx + 6, sy, rx + rw - 6, sy + ROW - 2, hb ? BTN_HOVER : BTN);
        c.drawTextWithShadow(tr, "Бинд", rx + 12, sy + 6, TEXT);
        String bn = binding == m ? "кнопка бас..." : Util.keyName(m.key);
        c.drawTextWithShadow(tr, bn, rx + rw - 12 - tr.getWidth(bn), sy + 6, binding == m ? ACCENT : TEXT);
        if (hb && clickL) binding = m;
        if (hb && clickR) { m.key = Util.UNSET; Config.save(); }

        c.drawTextWithShadow(tr, "ЛКМ: қосу/өшіру • ≡ немесе ПКМ: баптау • Бинд: ПКМ — тазалау",
                x0 + 8, y0 + H - 12, DIM);
    }

    private static boolean in(int mx, int my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx <= x2 && my >= y1 && my <= y2;
    }
}
