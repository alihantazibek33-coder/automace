package kz.alih.gui;

import kz.alih.AlihClient;
import kz.alih.Config;
import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class MenuScreen extends Screen {
    private static final int W = 400;
    private static final int ROW = 17;       // функция қатары
    private static final int SROW = 16;      // баптау қатары

    private static final String[] TABS = { "Бой", "PvP+", "Қозғалыс", "Визуал", "Утилита", "UHC" };

    private static final int ACCENT = 0xFFFFC857;
    private static final int BG = 0xF00D0D12;
    private static final int PANEL2 = 0xFF15151C;
    private static final int BTN = 0xFF20202A;
    private static final int BTN_HOVER = 0xFF2C2C3A;
    private static final int GREEN = 0xFF4CD964;
    private static final int RED = 0xFFFF5C5C;
    private static final int TEXT = 0xFFEDEDED;
    private static final int DIM = 0xFF8D8D9C;
    private static final int OFF_PILL = 0xFF3A3A48;

    private int tab;
    private Module selected;
    private Module binding;
    private boolean bindingMenuKey;
    private int setPage, listPage;
    private boolean wasLeft, wasRight, first = true;
    private final boolean[] prevKey = new boolean[GLFW.GLFW_KEY_LAST + 1];

    public MenuScreen() {
        super(Text.literal("AlihClient"));
        selected = modulesOf(0).isEmpty() ? AlihClient.MODULES.get(0) : modulesOf(0).get(0);
    }

    private static int tabOf(Module m) {
        return switch (m.id) {
            case "autocrystal", "autoanchor", "autocart", "shieldbreak", "autototem", "autoarmor", "autopearl" -> 1;
            case "scaffold", "autosprint", "step", "speed", "fly", "ghostteleport", "nofall", "antiafk", "autoblock", "jesus", "spider", "noslow", "elytraboost" -> 2;
            case "fullbright", "esp", "zoom", "antiinvis", "xray", "chathide", "espplayers", "freecam", "waypoints", "deathmarker" -> 3;
            case "cheststealer", "automark", "autobase", "autobuild", "autoshablon", "fpsboost", "automine", "humanize", "autospawner", "autofish", "fastplace", "fastbreak", "invsorter", "autoalmazka" -> 4;
            case "autoweb", "autoheadweb", "headwebplate", "autodrain", "stunslam" -> 5;
            default -> 0;
        };
    }

    private static List<Module> modulesOf(int t) {
        List<Module> list = new ArrayList<>();
        for (Module m : AlihClient.MODULES) {
            if (tabOf(m) == t) list.add(m);
        }
        return list;
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public boolean shouldCloseOnEsc() { return binding == null && !bindingMenuKey; }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        long win = mc.getWindow().getHandle();

        boolean left = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean right = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean clickL = left && !wasLeft && !first;
        boolean clickR = right && !wasRight && !first;
        wasLeft = left;
        wasRight = right;

        // ---- кнопка тағайындау / меню кнопкасын жабу
        boolean menuEdge = false;
        for (int k = 32; k <= GLFW.GLFW_KEY_LAST; k++) {
            boolean down = GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
            if (down && !prevKey[k] && !first) {
                if (binding != null) {
                    binding.key = (k == GLFW.GLFW_KEY_ESCAPE) ? Util.UNSET : k;
                    binding = null;
                    Config.save();
                }
            }
            prevKey[k] = down;
        }
        first = false;
        if (menuEdge) { mc.setScreen(null); return; }

        // ---- өлшем
        int H = Math.min(236, height - 8);
        int x0 = (width - W) / 2, y0 = (height - H) / 2;
        c.fill(0, 0, width, height, 0x80000000);
        c.fill(x0 - 1, y0 - 1, x0 + W + 1, y0 + H + 1, 0xFF2A2A36);   // жиек
        c.fill(x0, y0, x0 + W, y0 + H, BG);

        // ---- тақырып
        c.fillGradient(x0, y0, x0 + W, y0 + 22, 0xFF272734, 0xFF16161E);
        c.fill(x0, y0 + 22, x0 + W, y0 + 23, ACCENT);
        c.fill(x0 + 8, y0 + 7, x0 + 11, y0 + 16, ACCENT);
        c.drawTextWithShadow(tr, "AlihClient", x0 + 16, y0 + 7, TEXT);
        String hint = ".alih  •  ESC — жабу";
        c.drawTextWithShadow(tr, hint, x0 + W - tr.getWidth(hint) - 10, y0 + 7, DIM);

        // ---- табтар
        int ty = y0 + 26, tw = W / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            int tx = x0 + i * tw;
            boolean hv = in(mx, my, tx, ty, tx + tw, ty + 16);
            boolean on = i == tab;
            c.fill(tx, ty, tx + tw, ty + 16, on ? 0xFF1C1C26 : (hv ? 0xFF171720 : BG));
            c.drawTextWithShadow(tr, TABS[i], tx + (tw - tr.getWidth(TABS[i])) / 2, ty + 4, on ? ACCENT : DIM);
            if (on) c.fill(tx + 6, ty + 15, tx + tw - 6, ty + 16, ACCENT);
            if (hv && clickL && !on) {
                tab = i;
                List<Module> l = modulesOf(i);
                listPage = 0;
                if (!l.isEmpty()) { selected = l.get(0); setPage = 0; }
            }
        }

        // ---- сол жақ: функциялар
        List<Module> list = modulesOf(tab);
        int lx = x0 + 6, ly = y0 + 46, lw = 168;
        int rowsFit = Math.max(1, (H - 46 - 16 - 16) / ROW);
        int pages = Math.max(1, (list.size() + rowsFit - 1) / rowsFit);
        if (listPage >= pages) listPage = pages - 1;
        for (int i = 0; i < rowsFit; i++) {
            int mi = listPage * rowsFit + i;
            if (mi >= list.size()) break;
            Module m = list.get(mi);
            int ry = ly + i * ROW;
            boolean hover = in(mx, my, lx, ry, lx + lw, ry + ROW - 2);
            boolean sel = m == selected;
            c.fill(lx, ry, lx + lw, ry + ROW - 2, sel ? 0xFF2A2A38 : (hover ? BTN_HOVER : BTN));
            if (m.enabled) c.fill(lx, ry, lx + 2, ry + ROW - 2, GREEN);
            c.drawTextWithShadow(tr, tr.trimToWidth(m.name, lw - 44), lx + 8, ry + 4, sel ? ACCENT : TEXT);

            // қосу/өшіру "pill"
            int px = lx + lw - 28, py = ry + 3;
            boolean hp = in(mx, my, px - 2, ry, lx + lw, ry + ROW - 2);
            c.fill(px, py, px + 22, py + 9, m.enabled ? GREEN : OFF_PILL);
            int kx = m.enabled ? px + 13 : px + 1;
            c.fill(kx, py + 1, kx + 8, py + 8, 0xFFFFFFFF);

            if (clickL && hover) {
                if (hp) m.toggle(); else { selected = m; setPage = 0; }
            }
            if (clickR && hover) m.toggle();
        }

        if (pages > 1) {
            int ny = ly + rowsFit * ROW + 1;
            boolean hl = in(mx, my, lx, ny, lx + 34, ny + 13), hr = in(mx, my, lx + lw - 34, ny, lx + lw, ny + 13);
            c.fill(lx, ny, lx + 34, ny + 13, hl ? BTN_HOVER : BTN);
            c.fill(lx + lw - 34, ny, lx + lw, ny + 13, hr ? BTN_HOVER : BTN);
            c.drawTextWithShadow(tr, "<", lx + 15, ny + 3, TEXT);
            c.drawTextWithShadow(tr, ">", lx + lw - 19, ny + 3, TEXT);
            String pg = (listPage + 1) + "/" + pages;
            c.drawTextWithShadow(tr, pg, lx + (lw - tr.getWidth(pg)) / 2, ny + 3, DIM);
            if (clickL && hl) listPage = Math.max(0, listPage - 1);
            if (clickL && hr) listPage = Math.min(pages - 1, listPage + 1);
        }

        // ---- оң жақ: баптаулар
        int rx = x0 + 180, rw = W - 186, ry0 = y0 + 46, innerH = H - 46 - 16;
        Module m = selected;
        c.fill(rx, ry0, rx + rw, ry0 + innerH, PANEL2);
        c.fill(rx, ry0, rx + 2, ry0 + innerH, m.enabled ? GREEN : OFF_PILL);
        c.drawTextWithShadow(tr, tr.trimToWidth(m.name, rw - 16), rx + 8, ry0 + 5, ACCENT);
        c.drawTextWithShadow(tr, tr.trimToWidth(m.desc, rw - 16), rx + 8, ry0 + 17, DIM);

        int bottomY = ry0 + innerH - 19;
        int sy0 = ry0 + 31;
        int perPage = Math.max(1, (bottomY - 2 - sy0) / SROW);
        int sPages = Math.max(1, (m.settings.size() + perPage - 1) / perPage);
        if (setPage >= sPages) setPage = sPages - 1;

        for (int i = 0; i < perPage; i++) {
            int idx = setPage * perPage + i;
            if (idx >= m.settings.size()) break;
            Setting s = m.settings.get(idx);
            int sy = sy0 + i * SROW;
            boolean hover = in(mx, my, rx + 6, sy, rx + rw - 6, sy + SROW - 2);
            c.fill(rx + 6, sy, rx + rw - 6, sy + SROW - 2, hover ? BTN_HOVER : BTN);
            c.drawTextWithShadow(tr, tr.trimToWidth(s.name, rw - 100), rx + 12, sy + 4, TEXT);

            String v = s.display();
            if (s.type == Setting.Type.NUM) {
                int bp = rx + rw - 12 - 12;     // "+"
                int bm = bp - 52;               // "-"
                c.drawTextWithShadow(tr, "-", bm + 2, sy + 4, hover ? ACCENT : DIM);
                c.drawTextWithShadow(tr, v, bm + 12 + (40 - tr.getWidth(v)) / 2, sy + 4, TEXT);
                c.drawTextWithShadow(tr, "+", bp + 2, sy + 4, hover ? ACCENT : DIM);
                if (clickL && in(mx, my, bm - 2, sy, bm + 10, sy + SROW - 2)) { s.dec(); Config.save(); }
                if (clickL && in(mx, my, bp - 2, sy, bp + 10, sy + SROW - 2)) { s.inc(); Config.save(); }
            } else if (s.type == Setting.Type.BOOL) {
                int px = rx + rw - 12 - 22, py = sy + 3;
                c.fill(px, py, px + 22, py + 9, s.b ? GREEN : OFF_PILL);
                int kx = s.b ? px + 13 : px + 1;
                c.fill(kx, py + 1, kx + 8, py + 8, 0xFFFFFFFF);
                if (clickL && hover) { s.flip(); Config.save(); }
            } else {
                c.drawTextWithShadow(tr, v, rx + rw - 12 - tr.getWidth(v), sy + 4, TEXT);
                if (clickL && hover) { s.cycle(); Config.save(); }
            }
        }

        // ---- төменгі қатар: бинд + баптау беттері
        int bindW = sPages > 1 ? rw - 12 - 70 : rw - 12;
        boolean hb = in(mx, my, rx + 6, bottomY, rx + 6 + bindW, bottomY + SROW);
        c.fill(rx + 6, bottomY, rx + 6 + bindW, bottomY + SROW, hb ? BTN_HOVER : BTN);
        c.drawTextWithShadow(tr, "Бинд", rx + 12, bottomY + 4, TEXT);
        String bn = binding == m ? "кнопка бас..." : Util.keyName(m.key);
        c.drawTextWithShadow(tr, bn, rx + 6 + bindW - 6 - tr.getWidth(bn), bottomY + 4, binding == m ? ACCENT : DIM);
        if (hb && clickL) binding = m;
        if (hb && clickR) { m.key = Util.UNSET; Config.save(); }

        if (sPages > 1) {
            int px = rx + rw - 6 - 64;
            boolean hp = in(mx, my, px, bottomY, px + 20, bottomY + SROW);
            boolean hn = in(mx, my, px + 44, bottomY, px + 64, bottomY + SROW);
            c.fill(px, bottomY, px + 20, bottomY + SROW, hp ? BTN_HOVER : BTN);
            c.fill(px + 44, bottomY, px + 64, bottomY + SROW, hn ? BTN_HOVER : BTN);
            c.drawTextWithShadow(tr, "<", px + 7, bottomY + 4, TEXT);
            c.drawTextWithShadow(tr, ">", px + 51, bottomY + 4, TEXT);
            String sp = (setPage + 1) + "/" + sPages;
            c.drawTextWithShadow(tr, sp, px + 20 + (24 - tr.getWidth(sp)) / 2, bottomY + 4, DIM);
            if (clickL && hp && setPage > 0) setPage--;
            if (clickL && hn && setPage < sPages - 1) setPage++;
        }

        c.drawTextWithShadow(tr, "Ауыстырғыш: қосу/өшіру • Қатар: баптау • Бинд: ПКМ — тазалау",
                x0 + 6, y0 + H - 11, 0xFF5E5E6C);
    }

    private static boolean in(int mx, int my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx <= x2 && my >= y1 && my <= y2;
    }
}
