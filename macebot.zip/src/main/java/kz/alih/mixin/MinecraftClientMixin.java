package kz.alih.mixin;

import kz.alih.modules.HitBox;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    /**
     * Ванилла прицелді жаңартқаннан кейін, ЛКМ/ПКМ өңделер алдында ХитБокс нысанасын қояды.
     * (Тик басындағы шақыру жұмыс істемейді: updateCrosshairTarget оны қайта жазып жібереді.)
     */
    @Inject(method = "handleInputEvents", at = @At("HEAD"), require = 0)
    private void alih$hitboxAssist(CallbackInfo ci) {
        HitBox h = HitBox.INSTANCE;
        if (h != null) h.assist((MinecraftClient) (Object) this);
    }
}
