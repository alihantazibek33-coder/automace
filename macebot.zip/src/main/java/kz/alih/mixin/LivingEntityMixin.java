package kz.alih.mixin;

import kz.alih.modules.NoSlow;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    /** NoSlow: ClientPlayerEntity.tickMovement ішінде isUsingItem() false қайтарады (баяулау есептелмейді). */
    @Inject(method = "isUsingItem", at = @At("HEAD"), cancellable = true, require = 0)
    private void alih$noSlow(CallbackInfoReturnable<Boolean> cir) {
        if (NoSlow.inMove && (Object) this instanceof ClientPlayerEntity) cir.setReturnValue(false);
    }
}
