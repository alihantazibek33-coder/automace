package kz.alih.mixin;

import kz.alih.SilentAim;
import kz.alih.modules.Fly;
import kz.alih.modules.Freecam;
import kz.alih.modules.NoSlow;
import kz.alih.modules.GhostTeleport;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    // GhostTeleport қосулы кезде қозғалыс пакеттері серверге жіберілмейді (сервер сені бастапқы орнында деп санайды)
    @Inject(method = "sendMovementPackets", at = @At("HEAD"), cancellable = true)
    private void alih$ghost(CallbackInfo ci) {
        if (GhostTeleport.active()) {
            SilentAim.restore((ClientPlayerEntity) (Object) this);
            ci.cancel();
        }
    }

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void alih$silentPre(CallbackInfo ci) {
        SilentAim.apply((ClientPlayerEntity) (Object) this);
    }

    // Freecam қосулы кезде дененің физикасы/қозғалысы тоқтайды (камера ғана қозғалады)
    @Inject(method = "tickMovement", at = @At("HEAD"), cancellable = true, require = 0)
    private void alih$freecam(CallbackInfo ci) {
        if (Freecam.active()) {
            NoSlow.inMove = false;
            ci.cancel();
        }
    }

    // NoSlow: қозғалыс есептелгенде "зат қолданып жатыр" күйі көрінбейді
    @Inject(method = "tickMovement", at = @At("HEAD"), require = 0)
    private void alih$noSlowPre(CallbackInfo ci) {
        NoSlow.inMove = NoSlow.active();
    }

    @Inject(method = "tickMovement", at = @At("RETURN"), require = 0)
    private void alih$noSlowPost(CallbackInfo ci) {
        NoSlow.inMove = false;
    }

    // PlayerEntity.tick noClip-ті әр тикте қайта жазады, сондықтан қозғалыстың алдында қоямыз
    @Inject(method = "tickMovement", at = @At("HEAD"), require = 0)
    private void alih$noClip(CallbackInfo ci) {
        if (Fly.noClipActive() || GhostTeleport.noClipActive()) ((ClientPlayerEntity) (Object) this).noClip = true;
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"))
    private void alih$silentPost(CallbackInfo ci) {
        SilentAim.restore((ClientPlayerEntity) (Object) this);
    }
}
