package kz.alih;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class Config {
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("alihclient.properties");

    private Config() {}

    public static void load() {
        if (!Files.exists(PATH)) { loadLegacyIgnore(); return; }
        Properties pr = new Properties();
        try (Reader r = Files.newBufferedReader(PATH)) {
            pr.load(r);
        } catch (IOException e) {
            return;
        }
        try {
            AlihClient.menuKey = Integer.parseInt(pr.getProperty("menukey", String.valueOf(AlihClient.menuKey)));
        } catch (NumberFormatException ignored) {}

        String ig = pr.getProperty("ignore");
        if (ig != null) {
            Util.IGNORED.clear();
            for (String n : ig.split(",")) {
                if (!n.isBlank()) Util.IGNORED.add(Util.norm(n));
            }
        }
        loadLegacyIgnore();
        for (Module m : AlihClient.MODULES) {
            try {
                m.key = Integer.parseInt(pr.getProperty(m.id + ".key", String.valueOf(m.key)));
            } catch (NumberFormatException ignored) {}
            for (int i = 0; i < m.settings.size(); i++) {
                String raw = pr.getProperty(m.id + ".s" + i);
                if (raw == null) continue;
                Setting s = m.settings.get(i);
                try {
                    switch (s.type) {
                        case BOOL -> s.b = Boolean.parseBoolean(raw);
                        case NUM -> s.v = Math.max(s.min, Math.min(s.max, Double.parseDouble(raw)));
                        case MODE -> s.m = Math.floorMod(Integer.parseInt(raw), s.modes.length);
                    }
                } catch (NumberFormatException ignored) {}
            }
        }
    }

    /** Ескі MaceBot конфигіндегі (macebot.properties) ignore никтерін де қосады. */
    private static void loadLegacyIgnore() {
        Path old = FabricLoader.getInstance().getConfigDir().resolve("macebot.properties");
        if (!Files.exists(old)) return;
        Properties pr = new Properties();
        try (Reader r = Files.newBufferedReader(old)) {
            pr.load(r);
        } catch (IOException e) {
            return;
        }
        String ig = pr.getProperty("ignore");
        if (ig == null) return;
        for (String n : ig.split(",")) {
            if (!n.isBlank()) Util.IGNORED.add(Util.norm(n));
        }
    }

    public static void save() {
        Properties pr = new Properties();
        pr.setProperty("menukey", String.valueOf(AlihClient.menuKey));
        pr.setProperty("ignore", String.join(",", Util.IGNORED));
        for (Module m : AlihClient.MODULES) {
            pr.setProperty(m.id + ".key", String.valueOf(m.key));
            for (int i = 0; i < m.settings.size(); i++) {
                Setting s = m.settings.get(i);
                String val = switch (s.type) {
                    case BOOL -> String.valueOf(s.b);
                    case NUM -> String.valueOf(s.v);
                    case MODE -> String.valueOf(s.m);
                };
                pr.setProperty(m.id + ".s" + i, val);
            }
        }
        try (Writer w = Files.newBufferedWriter(PATH)) {
            pr.store(w, "AlihClient");
        } catch (IOException ignored) {}
    }
}
