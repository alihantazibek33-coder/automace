package kz.alih;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Properties;

public final class Config {
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("alihclient.properties");

    public static boolean loading;

    private Config() {}

    /** Баптау кілті атауы бойынша (реті өзгерсе де бұзылмайды). Ескі индекс кілті (id.sN) қосымша оқылады. */
    private static String nameKey(Module m, Setting s) {
        return m.id + ".n." + s.name.replaceAll("\\s+", "_");
    }

    public static void load() {
        Properties pr = new Properties();
        if (Files.exists(PATH)) {
            try (Reader r = Files.newBufferedReader(PATH)) {
                pr.load(r);
            } catch (IOException e) {
                return;
            }
        }
        try {
            AlihClient.menuKey = Integer.parseInt(pr.getProperty("menukey", String.valueOf(AlihClient.menuKey)));
        } catch (NumberFormatException ignored) {}

        String xr = pr.getProperty("xray.custom");
        if (xr != null) {
            kz.alih.modules.XRay.CUSTOM.clear();
            for (String n : xr.split(",")) {
                if (!n.isBlank()) kz.alih.modules.XRay.CUSTOM.add(n.trim().toLowerCase());
            }
        }

        String ig = pr.getProperty("ignore");
        if (ig != null) {
            Util.IGNORED.clear();
            for (String n : ig.split(",")) {
                if (!n.isBlank()) Util.IGNORED.add(Util.norm(n));
            }
        }
        loadLegacyIgnore();
        loading = true;
        try {
            for (Module m : AlihClient.MODULES) {
                try {
                    m.key = Integer.parseInt(pr.getProperty(m.id + ".key", String.valueOf(m.key)));
                } catch (NumberFormatException ignored) {}
                for (int i = 0; i < m.settings.size(); i++) {
                    Setting s = m.settings.get(i);
                    String raw = pr.getProperty(nameKey(m, s));
                    if (raw == null) raw = pr.getProperty(m.id + ".s" + i);
                    if (raw == null) continue;
                    try {
                        switch (s.type) {
                            case BOOL -> s.b = Boolean.parseBoolean(raw);
                            case NUM -> s.v = Math.max(s.min, Math.min(s.max, Double.parseDouble(raw)));
                            case MODE -> s.m = Math.floorMod(Integer.parseInt(raw), s.modes.length);
                        }
                    } catch (NumberFormatException ignored) {}
                }
                // баптаулар жүктелгеннен кейін ғана қосамыз (onEnable дұрыс мәнмен жұмыс істеу үшін)
                if (m.persistEnabled() && Boolean.parseBoolean(pr.getProperty(m.id + ".on", String.valueOf(m.defaultEnabled())))) {
                    m.enabled = true;
                    try {
                        m.onEnable();
                    } catch (RuntimeException e) {
                        System.err.println("[AlihClient] onEnable қатесі (" + m.id + "): " + e);
                    }
                }
            }
        } finally {
            loading = false;
        }
    }

    /** Ескі MaceBot конфигіндегі (macebot.properties) ignore никтерін де қосады. */
    private static void loadLegacyIgnore() {
        Path old = FabricLoader.getInstance().getConfigDir().resolve("macebot.properties");
        if (!Files.exists(old)) return;
        Properties pr = new Properties();
        try (Reader r = Files.newBufferedReader(old)) {
            pr.load(r);
        } catch (IOException e) {
            return;
        }
        String ig = pr.getProperty("ignore");
        if (ig == null) return;
        for (String n : ig.split(",")) {
            if (!n.isBlank()) Util.IGNORED.add(Util.norm(n));
        }
    }

    public static void save() {
        Properties pr = new Properties();
        pr.setProperty("menukey", String.valueOf(AlihClient.menuKey));
        pr.setProperty("ignore", String.join(",", Util.IGNORED));
        pr.setProperty("xray.custom", String.join(",", kz.alih.modules.XRay.CUSTOM));
        for (Module m : AlihClient.MODULES) {
            pr.setProperty(m.id + ".key", String.valueOf(m.key));
            pr.setProperty(m.id + ".on", String.valueOf(m.persistEnabled() && m.enabled));
            for (Setting s : m.settings) {
                String val = switch (s.type) {
                    case BOOL -> String.valueOf(s.b);
                    case NUM -> String.valueOf(s.v);
                    case MODE -> String.valueOf(s.m);
                };
                pr.setProperty(nameKey(m, s), val);
            }
        }
        // уақытша файлға жазып, кейін ауыстырады: ойын құласа да конфиг бүлінбейді
        Path tmp = PATH.resolveSibling(PATH.getFileName() + ".tmp");
        try {
            try (Writer w = Files.newBufferedWriter(tmp)) {
                pr.store(w, "AlihClient");
            }
            try {
                Files.move(tmp, PATH, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, PATH, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            System.err.println("[AlihClient] Конфигті сақтау қатесі: " + e);
        }
    }
}
