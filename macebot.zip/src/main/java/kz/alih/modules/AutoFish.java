package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/**
 * AutoFish: қармақ ұстап тұрғанда балық шағуын (поплавок су астына кетуін) көріп, автоматты тартады да қайта лақтырады.
 * Қолыңда (немесе хотбарда) қармақ болуы керек. Су бетіне қарап тұр.
 */
public class AutoFish extends Module {
    private final Setting reelDelay = num("Тарту кідірісі (тик)", 2, 0, 15, 1);
    private final Setting recast = num("Қайта лақтыру (тик)", 25, 10, 100, 5);

    private boolean hadHook;
    private int castT, reelT, waterTicks;
    private double lastY;

    public AutoFish() {
        super("autofish", "AutoFish", "Балық шаққанда қармақты өзі тартып, қайта лақтырады");
    }

    @Override
    public boolean persistEnabled() { return false; }

    @Override
    protected void onEnable() {
        hadHook = false;
        castT = 10;
        reelT = 0;
        waterTicks = 0;
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null) return;
        if (!p.getMainHandStack().isOf(Items.FISHING_ROD)) {
            int s = Util.findHotbar(p, st -> st.isOf(Items.FISHING_ROD));
            if (s >= 0) Util.select(p, s);
            return;
        }

        FishingBobberEntity hook = p.fishHook;
        if (hook == null) {
            if (hadHook) {                       // тартылды: біраз күтіп қайта лақтырады
                hadHook = false;
                castT = (int) recast.num();
                waterTicks = 0;
            }
            if (castT > 0 && --castT == 0) use(mc, p);
            return;
        }
        hadHook = true;

        if (reelT > 0) {
            if (--reelT == 0) use(mc, p);        // тарту
            return;
        }

        if (hook.isTouchingWater()) waterTicks++; else waterTicks = 0;
        double y = hook.getY();
        // шағу: поплавок су астына күрт батады
        if (waterTicks > 40 && (lastY - y > 0.12 || hook.getVelocity().y < -0.18)) {
            reelT = (int) reelDelay.num() + 1;
        }
        lastY = y;
    }

    private static void use(MinecraftClient mc, ClientPlayerEntity p) {
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        p.swingHand(Hand.MAIN_HAND);
    }
}
