package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/**
 * Флай: сурвайвалда ұшуға мүмкіндік береді. Көп серверде "flying is not enabled" деп кик береді.
 * NoClip қосулы болса, қабырғалар мен блоктар арқылы өтіп ұшады (ЖОЛ: Space — жоғары, Shift — төмен).
 * Ванилла серверде NoClip блок ішінде тұншықтыру зақымын береді және кері тартылуы мүмкін.
 */
public class Fly extends Module {
    public static Fly INSTANCE;

    private final Setting speed = num("Жылдамдық", 0.05, 0.02, 0.3, 0.01);
    private final Setting noclip = bool("NoClip (қабырға арқылы)", true);

    public Fly() {
        super("fly", "Флай", "Ұшады; NoClip қосулы болса қабырға арқылы өтеді (көп серверде кик беруі мүмкін)");
        INSTANCE = this;
    }

    @Override
    public boolean persistEnabled() { return false; }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p != null) {
            boolean keep = p.isCreative() || p.isSpectator();
            p.getAbilities().allowFlying = keep;
            if (!keep) p.getAbilities().flying = false;
            p.getAbilities().setFlySpeed(0.05f);
        }
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        p.getAbilities().allowFlying = true;
        p.getAbilities().setFlySpeed((float) speed.num());
        // NoClip кезінде жерге құламас үшін ұшу режимін қатты ұстап тұрамыз
        if (noclip.on()) p.getAbilities().flying = true;
    }

    /** ClientPlayerEntityMixin шақырады: true болса, ойыншы блоктар арқылы өтеді. */
    public static boolean noClipActive() {
        Fly f = INSTANCE;
        return f != null && f.enabled && f.noclip.on();
    }
}
