package kz.alih.modules;

import kz.alih.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.ClientPlayerEntity;

/** ЧатЖасыру: қосулы болса, чат хабарламалары экранда көрінбейді; тек чатты ашқанда ғана көрінеді. */
public class ChatHide extends Module {
    public static ChatHide INSTANCE;

    public ChatHide() {
        super("chathide", "ЧатЖасыру", "Чат хабарламалары экранда көрінбейді, тек чатты ашқанда ғана көрінеді");
        INSTANCE = this;
    }

    /** ChatHudMixin шақырады: true болса, чатты салуды өткізіп жібереді. */
    public static boolean shouldHide() {
        ChatHide h = INSTANCE;
        if (h == null || !h.enabled) return false;
        return !(MinecraftClient.getInstance().currentScreen instanceof ChatScreen);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        // әрекет ChatHudMixin ішінде
    }
}
