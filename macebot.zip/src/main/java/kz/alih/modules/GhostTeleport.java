package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * GhostTeleport: Флай сияқты (қабырға арқылы да) ұшасың, бірақ қозғалыс пакеттері серверге жіберілмейді:
 * сервер сені бастапқы орнында тұр деп санайды. Өшіргенде ойын жаңа орныңды серверге бір рет жібереді,
 * сонда сен сол жерде /tp жасағандай пайда боласың.
 *
 * Шектеулер:
 *  - сервер чанктарды бастапқы орның айналасында ғана жібереді: одан алысқа барсаң, жер жүктелмей қалады;
 *  - ванилла сервер үлкен секірісті ("moved too quickly") қабылдамай, кері тартады; лениент серверде ғана жұмыс істейді.
 */
public class GhostTeleport extends Module {
    public static GhostTeleport INSTANCE;

    private final Setting speed = num("Жылдамдық", 0.08, 0.02, 0.5, 0.01);
    private final Setting noclip = bool("NoClip (қабырға арқылы)", true);
    private final Setting maxDist = num("Макс. қашықтық (блок)", 100, 10, 1000, 10);

    private Vec3d origin = Vec3d.ZERO;

    public GhostTeleport() {
        super("ghostteleport", "GhostTeleport", "Серверге көрінбей ұшасың; өшіргенде сол жерге /tp сияқты пайда боласың");
        INSTANCE = this;
    }

    @Override
    public boolean persistEnabled() { return false; }

    /** Мixin-дер сұрайды: true болса, қозғалыс пакеттері жіберілмейді. */
    public static boolean active() {
        GhostTeleport g = INSTANCE;
        return g != null && g.enabled;
    }

    public static boolean noClipActive() {
        GhostTeleport g = INSTANCE;
        return g != null && g.enabled && g.noclip.on();
    }

    @Override
    protected void onEnable() {
        MinecraftClient mc = Util.mc();
        if (mc.player == null) { setEnabled(false); return; }
        origin = Util.pos(mc.player);
        Util.msg("GhostTeleport: сервер сені мында деп санайды: " + (int) origin.x + " " + (int) origin.y + " " + (int) origin.z
                + ". Өшіргенде ұшқан жеріңе барасың");
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = Util.mc();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;

        // блоктың ішінде қалып қоймас үшін бос жерге дейін жоғары көтереді
        BlockPos b = p.getBlockPos();
        for (int k = 0; k < 20; k++) {
            boolean solidFeet = !mc.world.getBlockState(b).getCollisionShape(mc.world, b).isEmpty();
            boolean solidHead = !mc.world.getBlockState(b.up()).getCollisionShape(mc.world, b.up()).isEmpty();
            if (!solidFeet && !solidHead) break;
            b = b.up();
            p.setPosition(p.getX(), b.getY(), p.getZ());
        }

        boolean keep = p.isCreative() || p.isSpectator();
        p.getAbilities().allowFlying = keep;
        if (!keep) p.getAbilities().flying = false;
        p.getAbilities().setFlySpeed(0.05f);
        p.setVelocity(Vec3d.ZERO);

        // келесі sendMovementPackets жаңа позицияны серверге өзі жібереді
        Util.msg("GhostTeleport: " + (int) p.getX() + " " + (int) p.getY() + " " + (int) p.getZ()
                + " (" + (int) Util.pos(p).distanceTo(origin) + " блок) орнына өтті");
    }

    @Override
    public void reset() {
        if (enabled) setEnabled(false);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        p.getAbilities().allowFlying = true;
        p.getAbilities().flying = true;
        p.getAbilities().setFlySpeed((float) speed.num());

        // бастапқы орыннан тым алыстамау
        Vec3d now = Util.pos(p);
        double d = now.distanceTo(origin);
        if (d > maxDist.num()) {
            Vec3d clamped = origin.add(now.subtract(origin).normalize().multiply(maxDist.num()));
            p.setPosition(clamped.x, clamped.y, clamped.z);
            p.setVelocity(Vec3d.ZERO);
        }
    }
}
