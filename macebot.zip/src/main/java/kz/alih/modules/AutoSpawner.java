package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.function.Predicate;

/**
 * АвтоСпавнер: спавнер іздейді, оған барады (шұңқыр, лава, су қауіптерін айналып; элитра болса ұшып, абайлап түсіп),
 * спавнерге қарай қазады да, жеткенде өзі өшеді. Нақты pathfinding жоқ: түзу барады, қауіпті айналады.
 */
public class AutoSpawner extends Module {
    private enum State { SEARCH, GOTO, DIG }
    private enum Fly { NONE, TAKEOFF, CRUISE, LAND }

    private final Setting useElytra = bool("Элитрамен ұшу", true);
    private final Setting cruiseY = num("Ұшу биіктігі (Y)", 110, 70, 300, 10);
    private final Setting fwLimit = num("Фейерверк лимиті", 30, 5, 200, 5);
    private final Setting reach = num("Жету қашықтығы (блок)", 3.5, 2.0, 4.5, 0.5);
    private final Setting radius = num("Іздеу радиусы (блок)", 2000, 200, 5000, 100);
    private final Setting lane = num("Жолақ аралығы (блок)", 160, 64, 600, 16);
    private final Setting baseScore = num("Базаны сақтау ұпайы", 8, 2, 60, 1);
    private final Setting saveBases = bool("Жолда базаны сақтау (.alih base)", true);
    private final Setting digS = bool("Қабырғаны қазып өту", true);
    private final Setting avoidHaz = bool("Лава/қауіптен айналып өту", true);
    private final Setting fallGuardS = bool("Құлаудан қорғау (су шелегі)", true);
    private final Setting fallMinS = num("Құлау биіктігі (≥ блок)", 8, 4, 40, 1);
    private final Setting mobsS = bool("Мобтарды ұру", true);
    private final Setting healS = num("Алтын алма жеу HP (≤)", 8, 2, 16, 1);
    private final Setting eatAt = num("Тамақ жеу (аштық ≤)", 14, 4, 19, 1);
    private final Setting fightPlayers = bool("Адамдармен ұрыс", true);
    private final kz.alih.Nav nav = new kz.alih.Nav();
    private final kz.alih.BaseFinder finder = new kz.alih.BaseFinder();
    private final AutoUhc fight = new AutoUhc();
    private boolean fighting;
    private int fightTicks, eatTicks;
    private final Set<Long> reportedBases = new HashSet<>();
    private static final java.nio.file.Path SPAWNERS_FILE =
            net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("alihclient-spawners.txt");
    private final kz.alih.SearchPath path = new kz.alih.SearchPath();

    private final Random rnd = new Random();
    private final Set<Long> visited = new HashSet<>();

    private State state = State.SEARCH;
    private Fly fly = Fly.NONE;
    private BlockPos target;
    private float heading, avoidYaw;
    private int ticks, fwCd, fwUsed, swapCd, avoidT;
    private Vec3d lastPos = Vec3d.ZERO;

    public AutoSpawner() {
        super("autospawner", "АвтоСпавнер", "Спавнер іздеп, барып, қазып жетеді де өзі өшеді");
    }

    @Override
    public boolean persistEnabled() { return false; }

    @Override
    protected void onEnable() {
        MinecraftClient mc = Util.mc();
        if (mc.player == null) { setEnabled(false); return; }
        state = State.SEARCH;
        fly = Fly.NONE;
        target = null;
        heading = mc.player.getYaw();
        path.reset(mc.player.getX(), mc.player.getZ());
        fwUsed = 0;
        nav.reset();
        finder.reset();
        fighting = false;
        fightTicks = 0;
        eatTicks = 0;
        loadVisited();
        Util.msg("АвтоСпавнер: спавнер іздеп жатыр (барған спавнерлер: " + visited.size() + ")");
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = Util.mc();
        if (fighting) fight.onDisable();
        fighting = false;
        if (mc.options != null) release(mc);
    }

    @Override
    public void reset() {
        nav.reset();
        finder.reset();
        state = State.SEARCH;
        fly = Fly.NONE;
        target = null;
        if (enabled) setEnabled(false);
    }

    private void release(MinecraftClient mc) {
        mc.options.forwardKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
        mc.options.attackKey.setPressed(false);
    }

    // ================================================================ негізгі цикл

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ticks++;
        if (fwCd > 0) fwCd--;
        if (swapCd > 0) swapCd--;

        // өлсе: координатты айтады, қайта тірілтеді, өшеді
        if (p.getHealth() <= 0 || !p.isAlive()) {
            Util.msg("Өлді! Орны: " + p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ());
            p.requestRespawn();
            setEnabled(false);
            return;
        }
        if (mc.currentScreen != null) return;

        nav.dig = digS.on();
        nav.avoid = avoidHaz.on();
        nav.fallGuard = fallGuardS.on();
        nav.fallMin = fallMinS.num();
        nav.fightMobs = mobsS.on();

        // құлау / лава: бәрінен бұрын
        if (nav.guard(mc, p, fly != Fly.NONE || p.isGliding())) return;

        // жақын жерде адам болса — ұрыс (ұшып жүргенде емес)
        if (fightPlayers.on() && fly == Fly.NONE && !p.isGliding()) {
            net.minecraft.entity.player.PlayerEntity enemy = Util.nearestPlayer(mc, p, 24);
            if (enemy != null) fightTicks = 80;
        }
        if (fightTicks > 0) {
            fightTicks--;
            if (!fighting) { fight.onEnable(); fighting = true; }
            fight.onTick(mc, p);
            if (fightTicks == 0) { fight.onDisable(); fighting = false; }
            return;
        }
        release(mc);

        if (fly == Fly.NONE && !p.isGliding()) {
            if (nav.heal(mc, p, healS.num())) return;
            if (nav.fightMobs(mc, p)) return;
            if (handleEat(mc, p)) return;
        }

        if (ticks % 20 == 0) scan(mc, p);
        if (ticks % 100 == 0 && saveBases.on()) reportBases(mc, p);

        // нысана жоғалса (жарылып/қазылып кетсе) — қайта іздейді
        if (target != null && state != State.SEARCH && !(mc.world.getBlockEntity(target) instanceof MobSpawnerBlockEntity)) {
            target = null;
            state = State.SEARCH;
        }

        switch (state) {
            case SEARCH -> search(mc, p);
            case GOTO -> goTo(mc, p);
            case DIG -> dig(mc, p);
        }
    }

    // ================================================================ спавнер іздеу

    private void scan(MinecraftClient mc, ClientPlayerEntity p) {
        if (state == State.DIG) return;
        int vd = mc.options.getViewDistance().getValue();
        int pcx = p.getBlockPos().getX() >> 4, pcz = p.getBlockPos().getZ() >> 4;
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int cx = pcx - vd; cx <= pcx + vd; cx++) {
            for (int cz = pcz - vd; cz <= pcz + vd; cz++) {
                Chunk ch = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
                if (!(ch instanceof WorldChunk wc)) continue;
                for (BlockEntity be : wc.getBlockEntities().values()) {
                    if (!(be instanceof MobSpawnerBlockEntity)) continue;
                    BlockPos bp = be.getPos();
                    if (visited.contains(bp.asLong())) continue;
                    double d = Util.pos(p).squaredDistanceTo(Vec3d.ofCenter(bp));
                    if (d < bd) { bd = d; best = bp; }
                }
            }
        }
        if (best != null && (target == null || !best.equals(target))) {
            target = best;
            state = State.GOTO;
            Util.msg("Спавнер табылды: " + best.getX() + " " + best.getY() + " " + best.getZ());
        }
    }

    private void search(MinecraftClient mc, ClientPlayerEntity p) {
        Vec3d wp = path.waypoint(p.getX(), p.getZ(), lane.num(), radius.num(), fly != Fly.NONE ? 40 : 8);
        if (wp == null) {
            Util.msg("Іздеу радиусы бітті (" + (int) radius.num() + " блок): ештеңе табылмады");
            setEnabled(false);
            return;
        }
        heading = kz.alih.SearchPath.yawTo(p.getX(), p.getZ(), wp.x, wp.z);
        if (fly == Fly.NONE && p.isOnGround() && canFly(p)) fly = Fly.TAKEOFF;
        if (fly != Fly.NONE) { flyStep(mc, p, null); return; }
        walkToward(mc, p, wp.x, wp.z);
    }

    private void goTo(MinecraftClient mc, ClientPlayerEntity p) {
        if (target == null) { state = State.SEARCH; return; }
        double hd = Math.hypot(target.getX() + 0.5 - p.getX(), target.getZ() + 0.5 - p.getZ());
        if (fly == Fly.NONE && hd > 80 && p.isOnGround() && canFly(p)) fly = Fly.TAKEOFF;
        if (fly != Fly.NONE) { flyStep(mc, p, Vec3d.ofCenter(target)); return; }
        if (hd > 6) { walkToward(mc, p, target.getX() + 0.5, target.getZ() + 0.5); return; }
        state = State.DIG;
    }

    // ================================================================ қазу

    private void dig(MinecraftClient mc, ClientPlayerEntity p) {
        Vec3d c = Vec3d.ofCenter(target);
        if (p.getEyePos().distanceTo(c) <= reach.num()) {
            visited.add(target.asLong());
            saveVisited(target);
            Util.msg("Спавнерге жетті: " + target.getX() + " " + target.getY() + " " + target.getZ() + ". АвтоСпавнер өшірілді");
            setEnabled(false);
            return;
        }

        double hd = Math.hypot(c.x - p.getX(), c.z - p.getZ());
        double dy = c.y - p.getY();
        BlockPos feet = p.getBlockPos();

        // төмен қазу: нысана төмен болса, үстіне келіп тік қазады
        if (dy < -2.0) {
            if (hd > 1.5) { walkToward(mc, p, c.x, c.z); return; }
            if (danger(mc, feet.down()) || danger(mc, feet.down(2)) || danger(mc, feet.down(3))) {
                Util.msg("Астында лава бар. АвтоСпавнер тоқтатылды");
                setEnabled(false);
                return;
            }
            mineTool(mc, p, mc.world.getBlockState(feet.down()));
            Util.smoothPitch(p, 90f);
            mc.options.attackKey.setPressed(true);
            return;
        }

        // көлденең тоннель: спавнерге қарап, алдындағы блокты қазады
        Util.aimAt(p, c);
        HitResult hr = mc.crosshairTarget;
        if (hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
            BlockPos hit = bhr.getBlockPos();
            if (dangerAround(mc, hit)) {
                Util.msg("Қазатын жерде лава бар. АвтоСпавнер тоқтатылды");
                setEnabled(false);
                return;
            }
            if (Vec3d.ofCenter(hit).distanceTo(p.getEyePos()) <= 4.5) {
                mineTool(mc, p, mc.world.getBlockState(hit));
                mc.options.attackKey.setPressed(true);
                return;
            }
        }
        // алды ашық болса — жақындайды
        if (hd > 1.0) {
            walkToward(mc, p, c.x, c.z);
        }
    }

    private boolean danger(MinecraftClient mc, BlockPos pos) {
        return mc.world.getBlockState(pos).getFluidState().isIn(FluidTags.LAVA);
    }

    private boolean dangerAround(MinecraftClient mc, BlockPos pos) {
        if (danger(mc, pos)) return true;
        for (net.minecraft.util.math.Direction d : net.minecraft.util.math.Direction.values()) {
            if (danger(mc, pos.offset(d))) return true;
        }
        return false;
    }

    private void mineTool(MinecraftClient mc, ClientPlayerEntity p, BlockState st) {
        int pick = Util.grab(mc, p, s -> s.isIn(ItemTags.PICKAXES));
        if (pick >= 0) Util.select(p, pick);
        else {
            int best = Util.selected(p);
            float bm = p.getInventory().getStack(best).getMiningSpeedMultiplier(st);
            for (int i = 0; i < 9; i++) {
                float m = p.getInventory().getStack(i).getMiningSpeedMultiplier(st);
                if (m > bm) { bm = m; best = i; }
            }
            Util.select(p, best);
        }
    }

    // ================================================================ жүру

    private boolean solid(MinecraftClient mc, BlockPos pos) {
        return mc.world.getBlockState(pos).isSolidBlock(mc.world, pos);
    }

    private void walkToward(MinecraftClient mc, ClientPlayerEntity p, double x, double z) {
        nav.walk(mc, p, x, z);
    }

    // ================================================================ тамақ

    private static boolean isFood(ItemStack s) {
        if (s.isEmpty() || s.get(net.minecraft.component.DataComponentTypes.FOOD) == null) return false;
        return !s.isOf(Items.GOLDEN_APPLE) && !s.isOf(Items.ENCHANTED_GOLDEN_APPLE) && !s.isOf(Items.ROTTEN_FLESH)
                && !s.isOf(Items.SPIDER_EYE) && !s.isOf(Items.POISONOUS_POTATO) && !s.isOf(Items.PUFFERFISH)
                && !s.isOf(Items.CHORUS_FRUIT) && !s.isOf(Items.SUSPICIOUS_STEW);
    }

    private boolean handleEat(MinecraftClient mc, ClientPlayerEntity p) {
        if (eatTicks == 0 && p.getHungerManager().getFoodLevel() > eatAt.num()) return false;
        int slot = Util.grab(mc, p, SpawnerFood.PRED);
        if (slot < 0) { eatTicks = 0; return false; }
        Util.select(p, slot);
        mc.options.useKey.setPressed(true);
        eatTicks++;
        if (eatTicks > 50 || (eatTicks > 4 && !p.isUsingItem())) {
            eatTicks = 0;
            mc.options.useKey.setPressed(false);
        }
        return true;
    }

    /** isFood-ты Predicate ретінде беру (статик ішкі класс). */
    private static final class SpawnerFood {
        static final java.util.function.Predicate<ItemStack> PRED = AutoSpawner::isFood;
    }

    // ================================================================ база белгісі + сақтау

    private void reportBases(MinecraftClient mc, ClientPlayerEntity p) {
        for (kz.alih.BaseFinder.Cluster c : finder.find(mc, p, true, true)) {
            if (c.score < baseScore.num()) continue;
            BlockPos cp = BlockPos.ofFloored(c.center());
            boolean dup = false;
            for (long k : reportedBases) {
                if (BlockPos.fromLong(k).getSquaredDistance(cp) < 60 * 60) { dup = true; break; }
            }
            if (dup) continue;
            reportedBases.add(cp.asLong());
            boolean fresh = kz.alih.BaseFinder.appendSaved(cp);
            Util.msg("База белгісі (ұпай " + Math.round(c.score) + ": " + c.summary() + "): " + cp.getX() + " " + cp.getY() + " " + cp.getZ()
                    + (fresh ? " — сақталды (.alih base)" : ""));
        }
    }

    private void loadVisited() {
        try {
            if (!java.nio.file.Files.exists(SPAWNERS_FILE)) return;
            for (String line : java.nio.file.Files.readAllLines(SPAWNERS_FILE)) {
                String[] a = line.trim().split("\\s+");
                if (a.length < 3) continue;
                visited.add(new BlockPos(Integer.parseInt(a[0]), Integer.parseInt(a[1]), Integer.parseInt(a[2])).asLong());
            }
        } catch (java.io.IOException | NumberFormatException ignored) {
        }
    }

    private void saveVisited(BlockPos pos) {
        try {
            java.nio.file.Files.writeString(SPAWNERS_FILE, pos.getX() + " " + pos.getY() + " " + pos.getZ() + System.lineSeparator(),
                    java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
        } catch (java.io.IOException ignored) {
        }
    }

    // ================================================================ элитра

    private boolean canFly(ClientPlayerEntity p) {
        boolean elytra = p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)
                || Util.hasInInventory(p, s -> s.isOf(Items.ELYTRA));
        return useElytra.on() && elytra && fwUsed < fwLimit.num()
                && Util.hasInInventory(p, s -> s.isOf(Items.FIREWORK_ROCKET));
    }

    private static int screenSlot(int invIndex) { return invIndex < 9 ? 36 + invIndex : invIndex; }

    private void equipFromInventory(MinecraftClient mc, ClientPlayerEntity p, Predicate<ItemStack> f) {
        if (swapCd > 0) return;
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isEmpty() && f.test(s)) {
                int from = screenSlot(i);
                int sid = p.playerScreenHandler.syncId;
                mc.interactionManager.clickSlot(sid, from, 0, SlotActionType.PICKUP, p);
                mc.interactionManager.clickSlot(sid, 6, 0, SlotActionType.PICKUP, p);
                mc.interactionManager.clickSlot(sid, from, 0, SlotActionType.PICKUP, p);
                swapCd = 4;
                return;
            }
        }
    }

    private void equipChestplate(MinecraftClient mc, ClientPlayerEntity p) {
        equipFromInventory(mc, p, s -> !s.isOf(Items.ELYTRA) && p.getPreferredEquipmentSlot(s) == EquipmentSlot.CHEST);
    }

    private double groundDist(MinecraftClient mc, ClientPlayerEntity p) {
        BlockPos b = p.getBlockPos();
        for (int k = 0; k < 90; k++) {
            if (solid(mc, b.down(k)) || mc.world.getBlockState(b.down(k)).getFluidState().isIn(FluidTags.WATER)) {
                return k - 1 + (p.getY() - b.getY());
            }
        }
        return 90;
    }

    private void flyStep(MinecraftClient mc, ClientPlayerEntity p, Vec3d tgt) {
        if (fly == Fly.TAKEOFF) {
            if (!p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) {
                equipFromInventory(mc, p, s -> s.isOf(Items.ELYTRA));
                return;
            }
            if (p.isGliding()) { fly = Fly.CRUISE; return; }
            if (p.isOnGround()) mc.options.jumpKey.setPressed(true);
            else if (p.getVelocity().y < -0.05) mc.options.jumpKey.setPressed(ticks % 2 == 0);
            return;
        }
        if (!p.isGliding()) {
            if (p.isOnGround() || fly == Fly.LAND) { fly = Fly.NONE; return; }
            mc.options.jumpKey.setPressed(ticks % 2 == 0);
            return;
        }

        double hd = tgt == null ? 9999 : Math.hypot(tgt.x - p.getX(), tgt.z - p.getZ());
        boolean fwLeft = fwUsed < fwLimit.num() && Util.hasInInventory(p, s -> s.isOf(Items.FIREWORK_ROCKET));
        if (fly == Fly.CRUISE && ((tgt != null && hd < 70) || !fwLeft)) fly = Fly.LAND;

        float yaw = tgt != null
                ? (float) (MathHelper.atan2(tgt.z - p.getZ(), tgt.x - p.getX()) * 180.0 / Math.PI) - 90f
                : heading;
        Util.smoothYaw(p, yaw);

        double gd = groundDist(mc, p);
        double speed = Math.hypot(p.getVelocity().x, p.getVelocity().z);
        float pitch;
        if (fly == Fly.LAND) {
            pitch = gd > 25 ? 28f : (gd > 8 ? 14f : 6f);
            if (gd <= 2.5) {                           // жерге жақын: элитраны алып, абайлап түседі
                fly = Fly.NONE;
                equipChestplate(mc, p);
                return;
            }
        } else {
            double err = cruiseY.num() - p.getY();
            pitch = (float) (err > 0 ? -Math.min(45, err * 0.6) : Math.min(15, -err * 0.3));
        }

        double rad = Math.toRadians(yaw);
        for (int k = 3; k <= 12; k += 3) {            // алда тау/ағаш болса көтеріледі
            BlockPos ahead = BlockPos.ofFloored(p.getX() - Math.sin(rad) * k, p.getY(), p.getZ() + Math.cos(rad) * k);
            if (solid(mc, ahead) || solid(mc, ahead.up())) { pitch = -45f; break; }
        }
        Util.smoothPitch(p, pitch);

        if (fly == Fly.CRUISE && fwCd == 0 && (speed < 0.9 || (cruiseY.num() - p.getY()) > 12)) {
            int fw = Util.grab(mc, p, s -> s.isOf(Items.FIREWORK_ROCKET));
            if (fw >= 0) {
                Util.select(p, fw);
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                fwCd = 30;
                fwUsed++;
            }
        }
    }
}
