package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;

import java.util.UUID;

/** АвтоПрицел: өзің ұрған нысананы прицелге алып, прицелді соған апарады. */
public class AutoAim extends Module {
    /** Соңғы соққы берілген нысана (AttackEntityCallback арқылы жаңарады). */
    public static UUID lastHit;

    private final Setting range = num("Қашықтық", 8, 3, 20, 1);
    private final Setting smooth = num("Бұру жылдамдығы (°/тик)", 30, 5, 180, 5);
    private final Setting mobs = bool("Мобқа да", true);

    public AutoAim() {
        super("autoaim", "АвтоПрицел", "Өзің ұрған нысананы прицелге алады (бинд арқылы қосып-өшір)");
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null || lastHit == null) return;
        Entity t = Util.entityById(mc, lastHit);
        if (!Util.validTarget(p, t, mobs.on())) return;
        if (Util.boxDist(p.getEyePos(), t.getBoundingBox()) > range.num()) return;
        Util.smoothAim(p, Util.center(t), (float) smooth.num());
    }
}
