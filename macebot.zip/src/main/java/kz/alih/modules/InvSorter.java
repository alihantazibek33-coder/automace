package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * InvSorter: негізгі инвентарьды (хотбарсыз, 27 слот) бір басумен сұрыптайды: алдымен бірдей заттарды біріктіреді,
 * содан кейін топ бойынша тізеді (құрал/қару, тамақ, блок, қалғаны). Бітген соң өзі өшеді.
 * Қосу үшін мәзірден қос немесе бинд тағайында.
 */
public class InvSorter extends Module {
    private static final int FIRST = 9, COUNT = 27;      // playerScreenHandler: 9..35 — негізгі инвентарь
    private static final int PER_TICK = 3;

    private final ArrayDeque<Integer> ops = new ArrayDeque<>();

    public InvSorter() {
        super("invsorter", "InvSorter", "Инвентарьды сұрыптайды: бірдей заттарды біріктіріп, топтап тізеді");
    }

    @Override
    public boolean persistEnabled() { return false; }

    private static int group(ItemStack s) {
        if (s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES) || s.isIn(ItemTags.PICKAXES)
                || s.isIn(ItemTags.SHOVELS) || s.isIn(ItemTags.HOES)) return 0;
        if (s.get(DataComponentTypes.FOOD) != null) return 1;
        if (s.getItem() instanceof BlockItem) return 2;
        return 3;
    }

    @Override
    protected void onEnable() {
        MinecraftClient mc = Util.mc();
        ClientPlayerEntity p = mc.player;
        if (p == null) { setEnabled(false); return; }
        if (!p.playerScreenHandler.getCursorStack().isEmpty()) {
            Util.msg("InvSorter: курсорда зат бар, алдымен қойып жібер");
            setEnabled(false);
            return;
        }
        ops.clear();

        // инвентарь моделі
        ItemStack[] m = new ItemStack[COUNT];
        for (int i = 0; i < COUNT; i++) m[i] = p.playerScreenHandler.getSlot(FIRST + i).getStack().copy();

        // 1) біріктіру
        for (int i = 0; i < COUNT; i++) {
            ItemStack a = m[i];
            if (a.isEmpty() || a.getMaxCount() <= 1 || a.getCount() >= a.getMaxCount()) continue;
            for (int j = i + 1; j < COUNT && a.getCount() < a.getMaxCount(); j++) {
                ItemStack b = m[j];
                if (b.isEmpty() || !ItemStack.areItemsAndComponentsEqual(a, b)) continue;
                int move = Math.min(a.getMaxCount() - a.getCount(), b.getCount());
                ops.add(FIRST + j);
                ops.add(FIRST + i);
                if (b.getCount() > move) ops.add(FIRST + j);        // қалғанын орнына қайтару
                a.increment(move);
                b.decrement(move);
                if (b.isEmpty()) m[j] = ItemStack.EMPTY;
            }
        }

        // 2) сұрыптау
        List<ItemStack> sorted = new ArrayList<>();
        for (ItemStack s : m) if (!s.isEmpty()) sorted.add(s);
        sorted.sort(Comparator
                .comparingInt(InvSorter::group)
                .thenComparing(s -> Registries.ITEM.getId(s.getItem()).toString())
                .thenComparing((ItemStack s) -> -s.getCount()));

        for (int i = 0; i < sorted.size(); i++) {
            ItemStack want = sorted.get(i);
            int j = -1;
            for (int k = i; k < COUNT; k++) {
                if (m[k] == want) { j = k; break; }                  // дәл сол объект
            }
            if (j < 0 || j == i) continue;
            ops.add(FIRST + i);
            ops.add(FIRST + j);
            ops.add(FIRST + i);
            ItemStack t = m[i];
            m[i] = m[j];
            m[j] = t;
        }

        if (ops.isEmpty()) {
            Util.msg("InvSorter: инвентарь әлдеқашан реттелген");
            setEnabled(false);
        }
    }

    @Override
    protected void onDisable() {
        ops.clear();
    }

    @Override
    public void reset() {
        if (enabled) setEnabled(false);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (mc.currentScreen != null && !(mc.currentScreen instanceof InventoryScreen)) return;
        for (int i = 0; i < PER_TICK && !ops.isEmpty(); i++) {
            int slot = ops.poll();
            mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 0, SlotActionType.PICKUP, p);
        }
        if (ops.isEmpty()) {
            Util.msg("InvSorter: дайын");
            setEnabled(false);
        }
    }
}
