package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * XRay: таңдалған блоктардан басқасын көрінбейтін етіп, руда/сундук/обсидиан т.б. таңдаған блоктарды
 * қабырғалар арқылы көрсетеді (BlockMixin арқылы). Қашықтық — ойынның render distance-і (чанктар).
 * Қосымша блок: .alih xray add <блок_id>. Су мен лава әдеттегідей көрінеді.
 */
public class XRay extends Module {
    public static volatile boolean active;
    private static volatile Set<Block> targets = new HashSet<>();
    /** Қолмен қосылған блоктар (id path, мысалы diamond_block). */
    public static final Set<String> CUSTOM = new LinkedHashSet<>();

    private final Setting ores = bool("Руда (бәрі)", true);
    private final Setting storage = bool("Сақтау блоктары (сундук, бочка, шалкер)", true);
    private final Setting obsidian = bool("Обсидиан / якорь", true);
    private final Setting spawner = bool("Спавнер", true);
    private final Setting light = bool("Жарық (night vision)", true);

    private String lastSig = "";
    private int ticks;

    public XRay() {
        super("xray", "XRay", "Таңдаған блоктарды (руда, сундук, обсидиан...) қабырға арқылы көрсетеді");
    }

    public static boolean isTarget(Block b) {
        return targets.contains(b);
    }

    public static boolean addCustom(String raw) {
        String id = raw.toLowerCase().replace("minecraft:", "").trim();
        if (!Registries.BLOCK.containsId(Identifier.ofVanilla(id))) return false;
        CUSTOM.add(id);
        return true;
    }

    private String signature() {
        return ores.on() + "|" + storage.on() + "|" + obsidian.on() + "|" + spawner.on() + "|" + CUSTOM;
    }

    private void rebuild() {
        Set<Block> out = new HashSet<>();
        for (Block b : Registries.BLOCK) {
            String id = Registries.BLOCK.getId(b).getPath();
            boolean take = false;
            if (ores.on() && (id.endsWith("_ore") || id.equals("ancient_debris"))) take = true;
            if (storage.on() && (id.equals("chest") || id.equals("trapped_chest") || id.equals("barrel")
                    || id.equals("ender_chest") || id.endsWith("shulker_box"))) take = true;
            if (obsidian.on() && (id.equals("obsidian") || id.equals("crying_obsidian") || id.equals("respawn_anchor"))) take = true;
            if (spawner.on() && (id.equals("spawner") || id.equals("trial_spawner"))) take = true;
            if (CUSTOM.contains(id)) take = true;
            if (take) out.add(b);
        }
        targets = out;
        lastSig = signature();
    }

    private void reloadWorld() {
        MinecraftClient mc = Util.mc();
        if (mc.worldRenderer != null && mc.world != null) mc.worldRenderer.reload();
    }

    @Override
    protected void onEnable() {
        rebuild();
        active = true;
        reloadWorld();
    }

    @Override
    protected void onDisable() {
        active = false;
        reloadWorld();
        MinecraftClient mc = Util.mc();
        if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ticks++;
        if (!signature().equals(lastSig)) {
            rebuild();
            reloadWorld();
        }
        if (light.on() && (ticks % 100 == 1 || !p.hasStatusEffect(StatusEffects.NIGHT_VISION))) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
        }
    }
}
