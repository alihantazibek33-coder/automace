package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import kz.alih.mixin.HandledScreenAccessor;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.math.BlockPos;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * АвтоОтметка: инвентарьда затқа мышканы апарып бинд бассаң — сол зат бар (бұрын ашқан) сундуктар жанып тұрады.
 * Сыртта бинд басу — қосу/өшіру.
 */
public class AutoMark extends Module {
    /** Сундукты соңғы басқан блок (UseBlockCallback арқылы жаңарады). */
    public static BlockPos lastUsed;

    private final Setting radius = num("Қашықтық", 48, 8, 96, 8);

    private final Map<BlockPos, Set<Item>> chests = new HashMap<>();
    private final Random rnd = new Random();
    private Item marked;
    private int ticks;

    public AutoMark() {
        super("automark", "АвтоОтметка", "Инвентарьда затқа мышка апарып бинд бас: сол зат бар сундуктар жанады");
    }

    public void clear() {
        marked = null;
        chests.clear();
    }

    @Override
    public boolean keyPressed(MinecraftClient mc, boolean inScreen) {
        if (!inScreen) return false;
        if (!(mc.currentScreen instanceof HandledScreen<?> hs)) return true;
        Slot s = ((HandledScreenAccessor) hs).alih$getFocusedSlot();
        if (s == null || !s.hasStack()) return true;
        ItemStack st = s.getStack();
        marked = st.getItem();
        setEnabled(true);
        Util.msg("Белгіленді: " + st.getName().getString() + " — осы зат бар сундуктар жанады");
        return true;
    }

    /** Ашық сундуктың ішін есте сақтайды (қосулы болсын-болмасын). */
    @Override
    public void alwaysTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (!(mc.currentScreen instanceof GenericContainerScreen gs) || lastUsed == null) return;
        Inventory inv = gs.getScreenHandler().getInventory();
        Set<Item> set = new HashSet<>();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isEmpty()) set.add(s.getItem());
        }
        chests.put(lastUsed, set);
        BlockState st = mc.world.getBlockState(lastUsed);
        if (st.getBlock() instanceof ChestBlock && st.contains(ChestBlock.CHEST_TYPE)
                && st.get(ChestBlock.CHEST_TYPE) != ChestType.SINGLE) {
            chests.put(lastUsed.offset(ChestBlock.getFacing(st)), set);
        }
    }

    private static boolean isContainer(BlockState st) {
        return st.isOf(Blocks.CHEST) || st.isOf(Blocks.TRAPPED_CHEST) || st.isOf(Blocks.BARREL) || st.isOf(Blocks.ENDER_CHEST);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ticks++;
        if (marked == null || ticks % 2 != 0) return;
        double r2 = radius.num() * radius.num();

        Iterator<Map.Entry<BlockPos, Set<Item>>> it = chests.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<BlockPos, Set<Item>> e = it.next();
            BlockPos pos = e.getKey();
            if (p.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > r2) continue;
            if (!isContainer(mc.world.getBlockState(pos))) {
                it.remove();
                continue;
            }
            if (!e.getValue().contains(marked)) continue;

            for (int i = 0; i < 3; i++) {
                mc.particleManager.addParticle(ParticleTypes.FLAME,
                        pos.getX() + rnd.nextDouble(), pos.getY() + 1.0, pos.getZ() + rnd.nextDouble(), 0, 0.01, 0);
            }
            if (ticks % 4 == 0) {
                for (int h = 1; h <= 3; h++) {
                    mc.particleManager.addParticle(ParticleTypes.END_ROD,
                            pos.getX() + 0.5, pos.getY() + 1.0 + h * 0.6, pos.getZ() + 0.5, 0, 0, 0);
                }
            }
        }
    }
}
