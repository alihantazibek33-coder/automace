package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Util;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * АвтоЯкор: якорьға қарап тұрсаң — светокаменьмен 1 рет зарядтайды да, тұрған жеріңнен
 * якорьға (немесе басқа затқа) ауысып ПКМ-мен жарады. Прицелді өзі якорьға бағыттайды.
 * Якорь Overworld/End-те жарылады (Незерде жарылмайды).
 */
public class AutoAnchor extends Module {
    private BlockPos anchor;
    private int stage, timeout;

    public AutoAnchor() {
        super("autoanchor", "АвтоЯкор", "Якорьды светокаменьмен зарядтап, тұрған жеріңнен бірден жарады");
    }

    @Override
    protected void onDisable() {
        anchor = null;
        stage = 0;
        timeout = 0;
    }

    private void reset() {
        anchor = null;
        stage = 0;
        timeout = 0;
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (anchor == null) {
            HitResult hr = mc.crosshairTarget;
            if (hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK
                    && mc.world.getBlockState(bhr.getBlockPos()).isOf(Blocks.RESPAWN_ANCHOR)) {
                anchor = bhr.getBlockPos();
                stage = 0;
                timeout = 0;
            } else {
                return;
            }
        }

        if (!mc.world.getBlockState(anchor).isOf(Blocks.RESPAWN_ANCHOR)) {
            reset(); // жарылып кетті (немесе жоғалды)
            return;
        }
        timeout++;

        Vec3d c = Vec3d.ofCenter(anchor);
        Util.aimAt(p, c);
        double dist = p.getEyePos().distanceTo(c);
        if (dist > 4.6) { reset(); return; }
        int charges = mc.world.getBlockState(anchor).get(RespawnAnchorBlock.CHARGES);

        if (stage == 0) { // светокаменьмен зарядтау
            if (charges > 0) { stage = 1; timeout = 0; return; }
            int glow = Util.grab(mc, p, s -> s.isOf(Items.GLOWSTONE));
            if (glow < 0) { Util.msg("Светокамень жоқ"); reset(); return; }
            if (timeout > 30) { reset(); return; }
            Util.select(p, glow);
            click(mc, p, c);
        } else { // жару: якорьға ауысып ПКМ
            int slot = Util.findHotbar(p, s -> s.isOf(Items.RESPAWN_ANCHOR));
            if (slot < 0) {
                int cur = Util.selected(p);
                if (p.getInventory().getStack(cur).isOf(Items.GLOWSTONE)) {
                    slot = Util.findHotbar(p, s -> !s.isOf(Items.GLOWSTONE));
                } else {
                    slot = cur;
                }
            }
            if (slot >= 0) Util.select(p, slot);
            click(mc, p, c);
            if (timeout > 12) reset();
        }
    }

    private void click(MinecraftClient mc, ClientPlayerEntity p, Vec3d c) {
        Vec3d eye = p.getEyePos();
        Direction side = Direction.getFacing(eye.x - c.x, eye.y - c.y, eye.z - c.z);
        Vec3d hit = c.add(side.getOffsetX() * 0.5, side.getOffsetY() * 0.5, side.getOffsetZ() * 0.5);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hit, side, anchor, false));
        p.swingHand(Hand.MAIN_HAND);
    }
}
