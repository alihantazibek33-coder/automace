package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * АвтоБаза (ЭКСПЕРИМЕНТАЛДЫ): база іздейді (жермен не элитрамен), сундуктары көп жерді тауып барады,
 * құнды заттарды алады, шалкерді қазып алады, тамақ жейді, адам көрсе сұрыпқа түседі, артық затты тастайды.
 * Нақты pathfinding жоқ: нысанаға түзу барады, кедергіні қазады.
 */
public class AutoBase extends Module {
    public static AutoBase INSTANCE;

    private enum State { SEARCH, GOTO, LOOT }
    private enum Fly { NONE, TAKEOFF, CRUISE, LAND }

    private final Setting useElytra = bool("Элитрамен ұшу", true);
    private final Setting minStorage = num("Мин. сундук саны", 6, 2, 30, 1);
    private final Setting maxPeople = num("Макс. адам (база)", 2, 0, 10, 1);
    private final Setting eatAt = num("Тамақ жеу (аштық ≤)", 14, 4, 19, 1);
    private final Setting minValue = num("Мин. құндылық", 30, 1, 100, 5);
    private final Setting dig = bool("Қазу (кірке)", true);
    private final Setting dropJunk = bool("Артықты тастау", true);
    private final Setting cruiseY = num("Ұшу биіктігі (Y)", 110, 70, 300, 10);
    private final Setting fwLimit = num("Фейерверк лимиті", 30, 5, 200, 5);
    private final Setting radius = num("Іздеу радиусы (блок)", 2000, 200, 5000, 100);
    private final Setting lane = num("Жолақ аралығы (блок)", 160, 64, 600, 16);
    private final Setting minScore = num("Мин. база ұпайы", 8, 2, 60, 1);
    private final Setting extraSignals = bool("Белгілер: маяк/төсек/пеш/плакат/рамка", true);
    private final Setting blockSignals = bool("Белгілер: құрылыс блоктары", true);
    private final Setting avoidHaz = bool("Лава/қауіптен айналып өту", true);
    private final Setting fallGuardS = bool("Құлаудан қорғау (су шелегі)", true);
    private final Setting fallMinS = num("Құлау биіктігі (≥ блок)", 8, 4, 40, 1);
    private final Setting mobsS = bool("Мобтарды ұру", true);
    private final Setting healS = num("Алтын алма жеу HP (≤)", 8, 2, 16, 1);
    private final kz.alih.Nav nav = new kz.alih.Nav();
    private final kz.alih.BaseFinder finder = new kz.alih.BaseFinder();
    private final kz.alih.SearchPath path = new kz.alih.SearchPath();

    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("alihclient-bases.txt");

    private final Random rnd = new Random();
    private final AutoUhc fight = new AutoUhc();
    private final List<BlockPos> saved = new ArrayList<>();
    private final List<BlockPos> blacklist = new ArrayList<>();
    private final List<BlockPos> todo = new ArrayList<>();
    private final Set<Long> triedOpen = new HashSet<>();

    private State state = State.SEARCH;
    private Fly fly = Fly.NONE;
    private Vec3d targetCenter;
    private float heading;
    private int ticks, fwCd, fwUsed, fightTicks, eatTicks, swapCd, dropCd, openWait, stuckT, avoidT, collectT;
    private boolean fighting;
    private float avoidYaw;
    private Vec3d lastPos = Vec3d.ZERO;
    private BlockPos current;       // қазір ашылып жатқан сақтау блогы
    private BlockPos dumpPos;       // шалкер қойылған орын
    private int dumpStage;

    public AutoBase() {
        super("autobase", "АвтоБаза", "База іздейді, сундуктарынан құнды зат алады (эксперименттік)");
        INSTANCE = this;
    }

    @Override
    public boolean persistEnabled() { return false; }

    // ================================================================ командалар (AlihClient шақырады)

    public void listBases() {
        loadBases();
        if (saved.isEmpty()) { Util.msg("Сақталған база жоқ"); return; }
        for (int i = 0; i < saved.size(); i++) {
            BlockPos b = saved.get(i);
            Util.msg((i + 1) + ") " + b.getX() + " " + b.getY() + " " + b.getZ());
        }
    }

    public void goToSaved(int n) {
        loadBases();
        if (n < 1 || n > saved.size()) { Util.msg("Мұндай база жоқ"); return; }
        BlockPos b = saved.get(n - 1);
        targetCenter = Vec3d.ofCenter(b);
        todo.clear();
        triedOpen.clear();
        blacklist.removeIf(x -> x.getSquaredDistance(b) < 40 * 40);
        state = State.GOTO;
        setEnabled(true);
        Util.msg("Базаға барады: " + b.getX() + " " + b.getY() + " " + b.getZ());
    }

    public void clearBases() {
        saved.clear();
        saveBases();
        Util.msg("Сақталған базалар тазаланды");
    }

    private void loadBases() {
        saved.clear();
        try {
            if (!Files.exists(FILE)) return;
            for (String line : Files.readAllLines(FILE)) {
                String[] a = line.trim().split("\\s+");
                if (a.length >= 3) saved.add(new BlockPos(Integer.parseInt(a[0]), Integer.parseInt(a[1]), Integer.parseInt(a[2])));
            }
        } catch (IOException | NumberFormatException ignored) {
        }
    }

    private void saveBases() {
        List<String> lines = new ArrayList<>();
        for (BlockPos b : saved) lines.add(b.getX() + " " + b.getY() + " " + b.getZ());
        try {
            Files.write(FILE, lines);
        } catch (IOException ignored) {
        }
    }

    // ================================================================ өмір циклі

    @Override
    protected void onEnable() {
        MinecraftClient mc = Util.mc();
        if (mc.player == null) { setEnabled(false); return; }
        loadBases();
        for (BlockPos b : saved) blacklist.add(b);
        fly = Fly.NONE;
        state = targetCenter != null ? State.GOTO : State.SEARCH;
        heading = mc.player.getYaw();
        path.reset(mc.player.getX(), mc.player.getZ());
        fwUsed = 0; fightTicks = 0; eatTicks = 0; dumpStage = 0; dumpPos = null; current = null;
        fight.onEnable();
        fighting = false;
        nav.reset();
        finder.reset();
        Util.msg("АвтоБаза қосылды");
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = Util.mc();
        if (fighting) fight.onDisable();
        fighting = false;
        releaseKeys(mc);
    }

    @Override
    public void reset() {
        nav.reset();
        finder.reset();
        state = State.SEARCH;
        fly = Fly.NONE;
        todo.clear();
        triedOpen.clear();
        targetCenter = null;
        current = null;
        dumpStage = 0;
        dumpPos = null;
        if (enabled) setEnabled(false);
    }

    private void releaseKeys(MinecraftClient mc) {
        if (mc.options == null) return;
        mc.options.forwardKey.setPressed(false);
        mc.options.backKey.setPressed(false);
        mc.options.leftKey.setPressed(false);
        mc.options.rightKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
        mc.options.useKey.setPressed(false);
        mc.options.attackKey.setPressed(false);
    }

    // ================================================================ негізгі тик

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        ticks++;
        if (fwCd > 0) fwCd--;
        if (swapCd > 0) swapCd--;
        if (dropCd > 0) dropCd--;

        // өлсе: координатты айтады, қайта тірілтеді, өшеді
        if (p.getHealth() <= 0 || !p.isAlive()) {
            Util.msg("Өлді! Орны: " + p.getBlockX() + " " + p.getBlockY() + " " + p.getBlockZ());
            p.requestRespawn();
            setEnabled(false);
            return;
        }

        if (mc.currentScreen instanceof HandledScreen<?> hs) {
            handleContainer(mc, p, hs.getScreenHandler());
            return;
        }
        if (mc.currentScreen != null) return;

        nav.dig = dig.on();
        nav.avoid = avoidHaz.on();
        nav.fallGuard = fallGuardS.on();
        nav.fallMin = fallMinS.num();
        nav.fightMobs = mobsS.on();

        // 0) құлау / лава: бәрінен бұрын
        if (nav.guard(mc, p, fly != Fly.NONE || p.isGliding())) return;

        // 1) адам көрінсе — сұрыпқа түседі (ұшып жүргенде емес)
        if (!p.isGliding() && fly == Fly.NONE) {
            PlayerEntity enemy = Util.nearestPlayer(mc, p, 26);
            if (enemy != null) fightTicks = 80;
        }
        if (fightTicks > 0) {
            fightTicks--;
            if (!fighting) { fight.onEnable(); fighting = true; }
            fight.onTick(mc, p);
            if (fightTicks == 0) { fight.onDisable(); fighting = false; }
            return;
        }
        releaseKeys(mc);

        // 1.5) HP аз болса алтын алма, жақын дұшпан моб болса ұру
        if (fly == Fly.NONE && !p.isGliding()) {
            if (nav.heal(mc, p, healS.num())) return;
            if (nav.fightMobs(mc, p)) return;
        }

        // 2) тамақ
        if (handleEat(mc, p)) return;

        // 3) инвентарь (артық зат, шалкерге салу)
        if (fly == Fly.NONE && !p.isGliding() && manageInventory(mc, p)) return;

        // 4) жақын жердегі база іздеу
        if (ticks % 20 == 0) scan(mc, p);

        switch (state) {
            case SEARCH -> search(mc, p);
            case GOTO -> goTo(mc, p);
            case LOOT -> loot(mc, p);
        }
    }

    // ================================================================ тамақ

    private static boolean isFood(ItemStack s) {
        if (s.get(DataComponentTypes.FOOD) == null) return false;
        return !(s.isOf(Items.ENCHANTED_GOLDEN_APPLE) || s.isOf(Items.ROTTEN_FLESH) || s.isOf(Items.SPIDER_EYE)
                || s.isOf(Items.PUFFERFISH) || s.isOf(Items.POISONOUS_POTATO) || s.isOf(Items.CHORUS_FRUIT)
                || s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.SUSPICIOUS_STEW));
    }

    private boolean handleEat(MinecraftClient mc, ClientPlayerEntity p) {
        if (p.isGliding()) return false;
        int food = p.getHungerManager().getFoodLevel();
        if (eatTicks == 0 && food > eatAt.num()) return false;
        int slot = Util.grab(mc, p, AutoBase::isFood);
        if (slot < 0) { eatTicks = 0; return false; }
        Util.select(p, slot);
        mc.options.useKey.setPressed(true);
        eatTicks++;
        if (eatTicks > 45 || (eatTicks > 4 && !p.isUsingItem())) eatTicks = 0;
        return true;
    }

    // ================================================================ құндылық / артық зат

    private static int value(ItemStack s) {
        if (s.isEmpty()) return 0;
        String id = Registries.ITEM.getId(s.getItem()).getPath();
        if (id.startsWith("netherite") || id.equals("ancient_debris")) return 100;
        if (id.equals("elytra") || id.equals("totem_of_undying") || id.equals("enchanted_golden_apple")
                || id.equals("nether_star") || id.equals("beacon") || id.equals("dragon_egg")
                || id.equals("trident") || id.equals("mace") || id.equals("heavy_core")) return 90;
        if (id.endsWith("shulker_box")) return 80;
        if (id.startsWith("diamond")) return 60;
        if (id.equals("end_crystal") || id.equals("enchanted_book")) return 50;
        if (id.equals("ender_pearl") || id.equals("respawn_anchor") || id.equals("experience_bottle")) return 40;
        if (id.equals("emerald_block") || id.equals("gold_block") || id.equals("golden_apple")) return 30;
        if (id.equals("firework_rocket") || id.equals("obsidian") || id.equals("emerald")) return 20;
        return 0;
    }

    private static boolean essential(ClientPlayerEntity p, ItemStack s) {
        return s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES) || s.isIn(ItemTags.PICKAXES)
                || s.get(DataComponentTypes.FOOD) != null
                || p.getPreferredEquipmentSlot(s) != EquipmentSlot.MAINHAND
                || s.isOf(Items.FIREWORK_ROCKET) || s.isOf(Items.WATER_BUCKET) || s.isOf(Items.LAVA_BUCKET)
                || s.isOf(Items.BUCKET) || s.isOf(Items.BOW) || s.isOf(Items.ARROW) || s.isOf(Items.SHIELD)
                || s.isOf(Items.ENDER_PEARL) || s.isOf(Items.COBWEB) || s.isOf(Items.FISHING_ROD)
                || s.isOf(Items.ELYTRA) || s.isOf(Items.TOTEM_OF_UNDYING);
    }

    private static int freeSlots(ClientPlayerEntity p) {
        int n = 0;
        for (int i = 0; i < 36; i++) if (p.getInventory().getStack(i).isEmpty()) n++;
        return n;
    }

    private static int screenSlot(int invIndex) {
        return invIndex < 9 ? 36 + invIndex : invIndex;
    }

    private static boolean isShulker(ItemStack s) {
        return Registries.ITEM.getId(s.getItem()).getPath().endsWith("shulker_box");
    }

    /** true — осы тик инвентарьмен жұмыс істелді. */
    private boolean manageInventory(MinecraftClient mc, ClientPlayerEntity p) {
        if (dumpStage > 0) return runDump(mc, p);

        int free = freeSlots(p);
        if (dropJunk.on() && free <= 6 && dropCd == 0) {
            for (int i = 0; i < 36; i++) {
                ItemStack s = p.getInventory().getStack(i);
                if (s.isEmpty() || value(s) > 0 || essential(p, s)) continue;
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, screenSlot(i), 1, SlotActionType.THROW, p);
                dropCd = 3;
                return true;
            }
        }
        if (free <= 1 && state == State.LOOT && Util.hasInInventory(p, AutoBase::isShulker)) {
            dumpStage = 1;
            return true;
        }
        return false;
    }

    // ================================================================ шалкерге салу

    private boolean runDump(MinecraftClient mc, ClientPlayerEntity p) {
        switch (dumpStage) {
            case 1 -> { // шалкерді қою
                int sh = Util.grab(mc, p, AutoBase::isShulker);
                if (sh < 0) { dumpStage = 0; return false; }
                BlockPos feet = p.getBlockPos();
                for (Direction d : new Direction[] { Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST }) {
                    BlockPos pos = feet.offset(d);
                    boolean free = mc.world.getBlockState(pos).isAir() && mc.world.getBlockState(pos.up()).isAir();
                    if (free && solid(mc, pos.down())) {
                        Util.select(p, sh);
                        Util.aimAt(p, Vec3d.ofCenter(pos.down()).add(0, 0.5, 0));
                        Util.place(mc, p, pos.down(), Direction.UP);
                        dumpPos = pos;
                        dumpStage = 2;
                        openWait = 0;
                        return true;
                    }
                }
                dumpStage = 0;
                return false;
            }
            case 2 -> { // ашу
                if (!mc.world.getBlockState(dumpPos).isIn(BlockTags.SHULKER_BOXES)) {
                    if (++openWait > 10) { dumpStage = 0; dumpPos = null; }
                    return true;
                }
                openBlock(mc, p, dumpPos);
                if (++openWait > 15) { dumpStage = 4; }
                return true;
            }
            case 4 -> { // қазып алу
                if (!mc.world.getBlockState(dumpPos).isIn(BlockTags.SHULKER_BOXES)) {
                    dumpStage = 0;
                    dumpPos = null;
                    collectT = 80;
                    return true;
                }
                mineBlock(mc, p, dumpPos);
                return true;
            }
            default -> { return true; } // 3 — контейнерде (handleContainer)
        }
    }

    // ================================================================ контейнер ішінде

    private void handleContainer(MinecraftClient mc, ClientPlayerEntity p, ScreenHandler h) {
        int contSize = h.slots.size() - 36;
        if (contSize <= 0) return;

        // шалкерге салу
        if (dumpStage >= 2 && dumpStage < 4 && h instanceof ShulkerBoxScreenHandler) {
            dumpStage = 3;
            for (int i = contSize; i < contSize + 27; i++) {      // негізгі инвентарь (хотбарсыз)
                ItemStack s = h.slots.get(i).getStack();
                if (s.isEmpty() || isShulker(s) || (essential(p, s) && value(s) == 0)) continue;
                mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, p);
                return;
            }
            p.closeHandledScreen();
            dumpStage = 4;
            return;
        }

        if (state != State.LOOT || current == null) return;

        // ең құнды затты алу
        if (freeSlots(p) > 0) {
            int best = -1, bv = 0;
            for (int i = 0; i < contSize; i++) {
                int v = value(h.slots.get(i).getStack());
                if (v >= minValue.num() && v > bv) { bv = v; best = i; }
            }
            if (best >= 0) {
                mc.interactionManager.clickSlot(h.syncId, best, 0, SlotActionType.QUICK_MOVE, p);
                return;
            }
        }
        // бітті
        p.closeHandledScreen();
        todo.remove(current);
        current = null;
    }

    // ================================================================ база іздеу (скан)

    private static boolean isStorage(BlockEntity be) {
        return be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof ShulkerBoxBlockEntity;
    }

    private void scan(MinecraftClient mc, ClientPlayerEntity p) {
        List<kz.alih.BaseFinder.Cluster> clusters = finder.find(mc, p, extraSignals.on(), blockSignals.on());

        if (state == State.LOOT && targetCenter != null) {
            // жаңа сақтау блоктарын тізімге қосу (бастапқы тізім толмай қалса)
            for (kz.alih.BaseFinder.Cluster c : clusters) {
                if (c.center().distanceTo(targetCenter) < 25) {
                    for (BlockPos b : c.storage) {
                        if (!todo.contains(b) && !triedOpen.contains(b.asLong())) todo.add(b);
                    }
                }
            }
            return;
        }
        if (state != State.SEARCH && !(state == State.GOTO && targetCenter == null)) return;

        kz.alih.BaseFinder.Cluster best = null;
        double bs = 0;
        for (kz.alih.BaseFinder.Cluster c : clusters) {
            boolean enough = c.storage.size() >= minStorage.num() || c.score >= minScore.num();
            if (!enough) continue;
            Vec3d ce = c.center();
            boolean bad = false;
            for (BlockPos b : blacklist) {
                if (Vec3d.ofCenter(b).distanceTo(ce) < 40) { bad = true; break; }
            }
            if (bad) continue;
            double score = c.score + c.shulkers * 2 - Util.pos(p).distanceTo(ce) * 0.02;
            if (best == null || score > bs) { bs = score; best = c; }
        }
        if (best == null) return;

        Vec3d ce = best.center();
        int people = 0;
        for (Entity o : mc.world.getEntities()) {
            if (o instanceof PlayerEntity pl && o != p && !pl.isSpectator() && o.squaredDistanceTo(ce) < 48 * 48) people++;
        }
        BlockPos cp = BlockPos.ofFloored(ce);
        String info = "ұпай " + Math.round(best.score) + ": " + best.summary();
        if (people > maxPeople.num()) {
            saved.add(cp);
            saveBases();
            blacklist.add(cp);
            Util.msg("База табылды, бірақ адам көп (" + people + "): координат сақталды " + cp.getX() + " " + cp.getY() + " " + cp.getZ() + " (" + info + ")");
            return;
        }
        if (best.storage.isEmpty()) {
            // сақтау блогы жоқ: тек белгі. Барып тонайтын ештеңе жоқ — координатты сақтап, іздеуді жалғастырады
            saved.add(cp);
            saveBases();
            blacklist.add(cp);
            Util.msg("База белгісі табылды (сундук жоқ), координат сақталды " + cp.getX() + " " + cp.getY() + " " + cp.getZ() + " (" + info + ")");
            return;
        }
        targetCenter = ce;
        todo.clear();
        triedOpen.clear();
        todo.addAll(best.storage);
        state = State.GOTO;
        Util.msg("База табылды (" + info + "): " + cp.getX() + " " + cp.getY() + " " + cp.getZ());
    }

    // ================================================================ іздеу / бару

    private boolean canFly(ClientPlayerEntity p) {
        boolean elytra = p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)
                || Util.hasInInventory(p, s -> s.isOf(Items.ELYTRA));
        return useElytra.on() && elytra && fwUsed < fwLimit.num()
                && Util.hasInInventory(p, s -> s.isOf(Items.FIREWORK_ROCKET));
    }

    private void search(MinecraftClient mc, ClientPlayerEntity p) {
        Vec3d wp = path.waypoint(p.getX(), p.getZ(), lane.num(), radius.num(), fly != Fly.NONE ? 40 : 8);
        if (wp == null) {
            Util.msg("Іздеу радиусы бітті (" + (int) radius.num() + " блок): ештеңе табылмады");
            setEnabled(false);
            return;
        }
        heading = kz.alih.SearchPath.yawTo(p.getX(), p.getZ(), wp.x, wp.z);
        if (fly == Fly.NONE && p.isOnGround() && canFly(p)) fly = Fly.TAKEOFF;
        if (fly != Fly.NONE) { flyStep(mc, p, null); return; }
        walkToward(mc, p, wp.x, wp.z);
    }

    private void goTo(MinecraftClient mc, ClientPlayerEntity p) {
        if (targetCenter == null) { state = State.SEARCH; return; }
        double hd = Math.hypot(targetCenter.x - p.getX(), targetCenter.z - p.getZ());
        if (fly == Fly.NONE && hd > 80 && p.isOnGround() && canFly(p)) fly = Fly.TAKEOFF;
        if (fly != Fly.NONE) { flyStep(mc, p, targetCenter); return; }
        if (hd > 6) { walkToward(mc, p, targetCenter.x, targetCenter.z); return; }
        state = State.LOOT;
        current = null;
        if (todo.isEmpty()) {
            todo.addAll(storagesNear(mc, targetCenter, 28));
        }
    }

    private List<BlockPos> storagesNear(MinecraftClient mc, Vec3d c, double r) {
        List<BlockPos> out = new ArrayList<>();
        int cx0 = ((int) c.x) >> 4, cz0 = ((int) c.z) >> 4;
        for (int cx = cx0 - 2; cx <= cx0 + 2; cx++) {
            for (int cz = cz0 - 2; cz <= cz0 + 2; cz++) {
                Chunk ch = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
                if (!(ch instanceof WorldChunk wc)) continue;
                for (BlockEntity be : wc.getBlockEntities().values()) {
                    if (isStorage(be) && Vec3d.ofCenter(be.getPos()).distanceTo(c) <= r) out.add(be.getPos());
                }
            }
        }
        return out;
    }

    // ================================================================ тонау

    private void loot(MinecraftClient mc, ClientPlayerEntity p) {
        if (collectT > 0) {
            collectT--;
            ItemEntity item = nearestValuableItem(mc, p, 10);
            if (item != null && freeSlots(p) > 0) {
                walkToward(mc, p, item.getX(), item.getZ());
                return;
            }
        }
        if (todo.isEmpty()) {
            Util.msg("База тазаланды. Жаңасын іздейді");
            if (targetCenter != null) blacklist.add(BlockPos.ofFloored(targetCenter));
            targetCenter = null;
            state = State.SEARCH;
            if (p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) equipChestplate(mc, p);
            return;
        }
        if (freeSlots(p) == 0 && !Util.hasInInventory(p, AutoBase::isShulker)) {
            Util.msg("Инвентарь толды. Тоқтатылды");
            setEnabled(false);
            return;
        }

        if (current == null || !todo.contains(current)) {
            BlockPos best = null;
            double bd = Double.MAX_VALUE;
            for (BlockPos b : todo) {
                double d = Util.pos(p).squaredDistanceTo(Vec3d.ofCenter(b));
                if (d < bd) { bd = d; best = b; }
            }
            current = best;
            openWait = 0;
        }
        if (current == null) return;

        BlockState st = mc.world.getBlockState(current);
        if (!(st.isIn(BlockTags.SHULKER_BOXES) || st.getBlock() instanceof net.minecraft.block.ChestBlock
                || st.isOf(net.minecraft.block.Blocks.BARREL))) {
            todo.remove(current);            // жоқ болып кетті
            current = null;
            return;
        }

        Vec3d c = Vec3d.ofCenter(current);
        double d = p.getEyePos().distanceTo(c);
        if (d > 4.3) { approach(mc, p, current); return; }

        if (st.isIn(BlockTags.SHULKER_BOXES)) { // шалкерді қазып алады
            mineBlock(mc, p, current);
            if (++openWait > 400) { todo.remove(current); current = null; }
            collectT = 80;
            return;
        }
        // сундук/бочка — ашу
        openBlock(mc, p, current);
        if (++openWait > 20) {
            triedOpen.add(current.asLong());
            todo.remove(current);
            current = null;
        }
    }

    private ItemEntity nearestValuableItem(MinecraftClient mc, ClientPlayerEntity p, double r) {
        ItemEntity best = null;
        double bd = r * r;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof ItemEntity ie) || value(ie.getStack()) <= 0) continue;
            double d = e.squaredDistanceTo(p);
            if (d < bd) { bd = d; best = ie; }
        }
        return best;
    }

    private void openBlock(MinecraftClient mc, ClientPlayerEntity p, BlockPos pos) {
        Vec3d c = Vec3d.ofCenter(pos);
        Vec3d eye = p.getEyePos();
        Direction side = Direction.getFacing(eye.x - c.x, eye.y - c.y, eye.z - c.z);
        Vec3d hit = c.add(side.getOffsetX() * 0.5, side.getOffsetY() * 0.5, side.getOffsetZ() * 0.5);
        Util.aimAt(p, c);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hit, side, pos, false));
        p.swingHand(Hand.MAIN_HAND);
    }

    /** Блокты кіркамен қазады (қара-тұра көрінетін болса). */
    private void mineBlock(MinecraftClient mc, ClientPlayerEntity p, BlockPos pos) {
        int pick = Util.grab(mc, p, s -> s.isIn(ItemTags.PICKAXES));
        if (pick >= 0) Util.select(p, pick);
        Util.aimAt(p, Vec3d.ofCenter(pos));
        mc.options.attackKey.setPressed(true);
    }

    // ================================================================ қозғалыс

    private boolean solid(MinecraftClient mc, BlockPos pos) {
        return mc.world.getBlockState(pos).isSolidBlock(mc.world, pos);
    }

    private boolean lava(MinecraftClient mc, BlockPos pos) {
        return mc.world.getBlockState(pos).getFluidState().isIn(FluidTags.LAVA);
    }

    /** Сақтау блогына жақындау: көлденең жүреді, төмен болса қазады. */
    private void approach(MinecraftClient mc, ClientPlayerEntity p, BlockPos target) {
        double hd = Math.hypot(target.getX() + 0.5 - p.getX(), target.getZ() + 0.5 - p.getZ());
        double dy = target.getY() - p.getY();
        if (hd > 2.5 || dy > -2.5) {
            walkToward(mc, p, target.getX() + 0.5, target.getZ() + 0.5);
            return;
        }
        if (!dig.on()) { todo.remove(target); current = null; return; }
        // төмен қазу: астында лава болса — тоқтайды
        BlockPos feet = p.getBlockPos();
        if (lava(mc, feet.down()) || lava(mc, feet.down(2)) || lava(mc, feet.down(3))) {
            Util.msg("Астында лава бар, қазбайды");
            todo.remove(target);
            current = null;
            return;
        }
        int pick = Util.grab(mc, p, s -> s.isIn(ItemTags.PICKAXES));
        if (pick < 0) { todo.remove(target); current = null; return; }
        Util.select(p, pick);
        p.setPitch(90f);
        mc.options.attackKey.setPressed(true);
    }

    private void walkToward(MinecraftClient mc, ClientPlayerEntity p, double x, double z) {
        nav.walk(mc, p, x, z);
    }

    // ================================================================ элитрамен ұшу

    private double groundDist(MinecraftClient mc, ClientPlayerEntity p) {
        BlockPos b = p.getBlockPos();
        for (int k = 0; k < 90; k++) {
            if (solid(mc, b.down(k))) return k - 1 + (p.getY() - b.getY());
        }
        return 90;
    }

    private void equipFromInventory(MinecraftClient mc, ClientPlayerEntity p, java.util.function.Predicate<ItemStack> f) {
        if (swapCd > 0) return;
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isEmpty() && f.test(s)) {
                int from = screenSlot(i);
                int sid = p.playerScreenHandler.syncId;
                mc.interactionManager.clickSlot(sid, from, 0, SlotActionType.PICKUP, p);
                mc.interactionManager.clickSlot(sid, 6, 0, SlotActionType.PICKUP, p);
                mc.interactionManager.clickSlot(sid, from, 0, SlotActionType.PICKUP, p);
                swapCd = 4;
                return;
            }
        }
    }

    private void equipChestplate(MinecraftClient mc, ClientPlayerEntity p) {
        equipFromInventory(mc, p, s -> !s.isOf(Items.ELYTRA) && p.getPreferredEquipmentSlot(s) == EquipmentSlot.CHEST);
    }

    private void flyStep(MinecraftClient mc, ClientPlayerEntity p, Vec3d target) {
        mc.options.jumpKey.setPressed(false);

        if (fly == Fly.TAKEOFF) {
            if (!p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) {
                equipFromInventory(mc, p, s -> s.isOf(Items.ELYTRA));
                return;
            }
            if (p.isGliding()) { fly = Fly.CRUISE; return; }
            if (p.isOnGround()) mc.options.jumpKey.setPressed(true);
            else if (p.getVelocity().y < -0.05) mc.options.jumpKey.setPressed(ticks % 2 == 0);
            return;
        }
        if (!p.isGliding()) {
            if (p.isOnGround() || fly == Fly.LAND) { fly = Fly.NONE; return; }
            mc.options.jumpKey.setPressed(ticks % 2 == 0);
            return;
        }

        double hd = target == null ? 9999 : Math.hypot(target.x - p.getX(), target.z - p.getZ());
        if (fly == Fly.CRUISE && ((target != null && hd < 70) || !canFlyMore(p))) fly = Fly.LAND;

        // бағыт
        float yaw;
        if (target != null) {
            yaw = (float) (MathHelper.atan2(target.z - p.getZ(), target.x - p.getX()) * 180.0 / Math.PI) - 90f;
        } else {
            yaw = heading;
        }
        Util.smoothYaw(p, yaw);

        double gd = groundDist(mc, p);
        double speed = Math.hypot(p.getVelocity().x, p.getVelocity().z);
        float pitch;
        if (fly == Fly.LAND) {
            pitch = gd > 25 ? 28f : (gd > 8 ? 14f : 6f);
            if (gd <= 2.5) {                       // жерге жақын: элитраны алып, жерге түседі
                fly = Fly.NONE;
                equipChestplate(mc, p);
                return;
            }
        } else {
            double err = cruiseY.num() - p.getY();
            pitch = (float) (err > 0 ? -Math.min(45, err * 0.6) : Math.min(15, -err * 0.3));
        }

        // алда тау/қабырға болса — көтеріледі
        double rad = Math.toRadians(yaw);
        for (int k = 3; k <= 12; k += 3) {
            BlockPos ahead = BlockPos.ofFloored(p.getX() - Math.sin(rad) * k, p.getY(), p.getZ() + Math.cos(rad) * k);
            if (solid(mc, ahead) || solid(mc, ahead.up())) { pitch = -45f; break; }
        }
        p.setPitch(pitch);

        // фейерверк: жылдамдық түссе немесе көтерілу керек болса
        if (fly == Fly.CRUISE && fwCd == 0 && (speed < 0.9 || (cruiseY.num() - p.getY()) > 12)) {
            int fw = Util.grab(mc, p, s -> s.isOf(Items.FIREWORK_ROCKET));
            if (fw >= 0) {
                Util.select(p, fw);
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                fwCd = 30;
                fwUsed++;
            }
        }
    }

    private boolean canFlyMore(ClientPlayerEntity p) {
        return fwUsed < fwLimit.num() && Util.hasInInventory(p, s -> s.isOf(Items.FIREWORK_ROCKET));
    }
}
