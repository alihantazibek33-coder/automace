package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.HashSet;
import java.util.Set;

/** ЕСП: игрок/моб/заттарды қабырға арқылы жарқыратып көрсетеді (glow контуры). */
public class Esp extends Module {
    private final Setting players = bool("Игрок", true);
    private final Setting mobs = bool("Моб", false);
    private final Setting items = bool("Түскен заттар", false);
    private final Setting range = num("Қашықтық", 64, 16, 128, 16);

    private final Set<Integer> glowed = new HashSet<>();

    public Esp() {
        super("esp", "ЕСП", "Игрок/моб/заттарды қабырға арқылы жарқыратып көрсетеді");
    }

    private boolean wants(ClientPlayerEntity p, Entity e) {
        if (e == p) return false;
        if (e instanceof PlayerEntity pl) return players.on() && !pl.isSpectator() && !Util.isIgnored(pl);
        if (e instanceof LivingEntity) return mobs.on();
        if (e instanceof ItemEntity) return items.on();
        return false;
    }

    @Override
    public void reset() { glowed.clear(); }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null) {
            for (Entity e : mc.world.getEntities()) {
                if (glowed.contains(e.getId())) e.setGlowing(false);
            }
        }
        glowed.clear();
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        double r2 = range.num() * range.num();
        for (Entity e : mc.world.getEntities()) {
            boolean want = wants(p, e) && e.squaredDistanceTo(p) <= r2;
            if (want) {
                e.setGlowing(true);
                glowed.add(e.getId());
            } else if (glowed.remove(e.getId())) {
                e.setGlowing(false);
            }
        }
    }
}
