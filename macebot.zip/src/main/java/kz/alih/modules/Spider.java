package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Spider: қабырғаға тіреліп тұрғанда жоғары өрмелейді. Shift — тоқтайды. */
public class Spider extends Module {
    private final Setting climb = num("Өрмелеу жылдамдығы", 0.2, 0.05, 0.6, 0.05);

    public Spider() {
        super("spider", "Spider", "Қабырғаға өрмелейді (қабырғаға қарай жүрсең болды)");
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (p.isSneaking() || p.isGliding() || p.getAbilities().flying || p.isTouchingWater() || p.isInLava()) return;
        if (!p.horizontalCollision) return;
        Vec3d v = p.getVelocity();
        p.setVelocity(v.x, climb.num(), v.z);
    }
}
