package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import kz.alih.Util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * ХитБокс: нысананың хитбоксын үлкейтеді (прицел бағыттау үшін). EntityMixin арқылы жұмыс істейді.
 * Ескерту: сервер ұруды өзі тексереді, әдетте ~1 блокқа дейін ғана кешіреді.
 */
public class HitBox extends Module {
    public static HitBox INSTANCE;

    private final Setting size = num("Үлкейту (блок)", 0.3, 0.1, 1.0, 0.1);
    private final Setting playersOnly = bool("Тек игрок", true);

    public HitBox() {
        super("hitbox", "ХитБокс", "Нысананың хитбоксын үлкейтеді (прицелге оңай түседі)");
        INSTANCE = this;
    }

    /** EntityMixin шақырады: энтитиге қосымша хитбокс өрісі (блок). 0 — өзгеріссіз. */
    public static float marginFor(Entity e) {
        HitBox h = INSTANCE;
        if (h == null || !h.enabled) return 0f;
        if (!(e instanceof LivingEntity) || e == MinecraftClient.getInstance().player) return 0f;
        if (h.playersOnly.on() && !(e instanceof PlayerEntity)) return 0f;
        if (Util.isIgnored(e)) return 0f;
        return (float) h.size.num();
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        // әрекет EntityMixin ішінде
    }
}
