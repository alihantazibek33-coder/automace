package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * Jesus: су мен лава бетімен жүреді. Суға түссең, бетіне көтеріледі. Shift — батады.
 * Көп серверде "flying" ретінде кик беруі мүмкін.
 */
public class Jesus extends Module {
    private final Setting water = bool("Су бетімен", true);
    private final Setting lava = bool("Лава бетімен", true);

    public Jesus() {
        super("jesus", "Jesus", "Су мен лава бетімен жүреді (Shift — батады)");
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        if (p.isSneaking() || p.isGliding() || p.getAbilities().flying || p.hasVehicle()) return;
        Vec3d v = p.getVelocity();

        // сұйықтың ішінде: бетіне көтеріледі
        boolean inFluid = (water.on() && p.isTouchingWater()) || (lava.on() && p.isInLava());
        if (inFluid) {
            p.setVelocity(v.x, Math.max(v.y, 0.14), v.z);
            return;
        }

        // сұйықтың дәл үстінде: тұрады
        BlockPos below = BlockPos.ofFloored(p.getX(), p.getY() - 0.02, p.getZ());
        FluidState fs = mc.world.getFluidState(below);
        if (fs.isEmpty()) return;
        boolean isLava = fs.isIn(net.minecraft.registry.tag.FluidTags.LAVA);
        if (isLava ? !lava.on() : !water.on()) return;
        if (!mc.world.getFluidState(below.up()).isEmpty()) return;      // әлі ішіндемін

        double surface = below.getY() + fs.getHeight(mc.world, below);
        if (v.y <= 0.0 && p.getY() <= surface + 0.2) {
            p.setPosition(p.getX(), surface + 0.001, p.getZ());
            p.setVelocity(v.x, 0.0, v.z);
            p.setOnGround(true);
        }
    }
}
