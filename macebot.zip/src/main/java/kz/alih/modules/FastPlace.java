package kz.alih.modules;

import kz.alih.Module;
import kz.alih.Setting;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

/**
 * FastPlace: ПКМ басып ұстағанда блокты әр тикте (немесе таңдалған кідіріспен) қояды.
 * Тек толық блокқа (сундук, верстак, есік сияқты қолданылатын емес) қарап қойғанда жұмыс істейді.
 */
public class FastPlace extends Module {
    private final Setting delay = num("Кідіріс (тик)", 1, 1, 4, 1);
    private int cd;

    public FastPlace() {
        super("fastplace", "FastPlace", "ПКМ ұстағанда блокты жылдам қояды");
    }

    private static boolean useable(BlockState s) {
        return s.isOf(Blocks.CRAFTING_TABLE) || s.isOf(Blocks.NOTE_BLOCK) || s.isOf(Blocks.CARTOGRAPHY_TABLE)
                || s.isOf(Blocks.SMITHING_TABLE) || s.isOf(Blocks.FLETCHING_TABLE) || s.isOf(Blocks.LOOM)
                || s.isOf(Blocks.RESPAWN_ANCHOR) || s.isOf(Blocks.TNT);
    }

    @Override
    public void onTick(MinecraftClient mc, ClientPlayerEntity p) {
        cd++;
        if (mc.currentScreen != null || !mc.options.useKey.isPressed() || p.isUsingItem()) return;
        if (cd < delay.num()) return;
        if (!(p.getMainHandStack().getItem() instanceof BlockItem)) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;

        BlockPos pos = hit.getBlockPos();
        BlockState target = mc.world.getBlockState(pos);
        if (mc.world.getBlockEntity(pos) != null || !target.isFullCube(mc.world, pos) || useable(target)) return;

        cd = 0;
        ActionResult r = mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
        if (r.isAccepted()) p.swingHand(Hand.MAIN_HAND);
    }
}
