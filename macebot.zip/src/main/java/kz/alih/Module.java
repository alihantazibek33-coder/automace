package kz.alih;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String id, name, desc;
    public boolean enabled;
    public int key = Util.UNSET;
    public boolean wasDown;
    public final List<Setting> settings = new ArrayList<>();

    protected Module(String id, String name, String desc) {
        this.id = id;
        this.name = name;
        this.desc = desc;
    }

    protected Setting bool(String n, boolean d) {
        Setting s = Setting.bool(n, d);
        settings.add(s);
        return s;
    }

    protected Setting num(String n, double d, double min, double max, double step) {
        Setting s = Setting.num(n, d, min, max, step);
        settings.add(s);
        return s;
    }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean e) {
        if (enabled == e) return;
        enabled = e;
        if (e) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}

    /** Бинд басылғанда шақырылады. inScreen=true — инвентарь ашық. true қайтарса, қосу/өшіру жасалмайды. */
    public boolean keyPressed(MinecraftClient mc, boolean inScreen) { return false; }

    /** Қосулы болсын-болмасын, әр тик шақырылады. */
    public void alwaysTick(MinecraftClient mc, ClientPlayerEntity p) {}

    public abstract void onTick(MinecraftClient mc, ClientPlayerEntity p);
}
