package kz.alih;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BeaconBlockEntity;
import net.minecraft.block.entity.BedBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BrewingStandBlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.EnchantingTableBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.vehicle.ChestMinecartEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;

/**
 * База табу жүйесі: бірнеше белгі бойынша ұпай санайды (тек сундук емес).
 *  - сақтау: сундук, бочка, шалкер, эндер сундук;
 *  - база жабдығы: маяк, төсек, пеш, воронка, раздатчик, құйғыш, зельеварка, чарлау үстелі, плакат;
 *  - энтитилер: рамка, броня стенді, сундугы бар вагонетка (ауыл тұрғыны — минус: ауылды базадан ажырату үшін);
 *  - құрылыс блоктары: бетон, түсті шыны, глазурлі терракота, темір/алтын/алмаз/изумруд блогы, ТНТ, поршень, обсервер т.б.
 * Белгілер 22 блок радиуста кластерге біріктіріледі.
 */
public final class BaseFinder {
    public static final Path BASES_FILE = FabricLoader.getInstance().getConfigDir().resolve("alihclient-bases.txt");
    private static final double CLUSTER_R = 22.0;

    public static final class Cluster {
        public final List<BlockPos> storage = new ArrayList<>();
        public int shulkers;
        public double score;
        private double base, ent;
        private int artCount, n;
        private double sx, sy, sz;
        private final Map<String, Integer> parts = new LinkedHashMap<>();

        private void add(BlockPos b, double w, String label) {
            base += w;
            n++;
            sx += b.getX(); sy += b.getY(); sz += b.getZ();
            parts.merge(label, 1, Integer::sum);
        }

        private void addArt(BlockPos b) {
            artCount++;
            n++;
            sx += b.getX(); sy += b.getY(); sz += b.getZ();
            parts.merge("құрылыс блогы", 1, Integer::sum);
        }

        private void finish() {
            score = base + Math.min(6.0, artCount * 0.12) + Math.max(-8.0, Math.min(4.0, ent));
        }

        public Vec3d center() { return n == 0 ? Vec3d.ZERO : new Vec3d(sx / n, sy / n, sz / n); }

        public String summary() {
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, Integer> e : parts.entrySet()) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(e.getKey()).append("×").append(e.getValue());
            }
            return sb.toString();
        }
    }

    // ================================================================ салмақтар

    public static boolean isStorage(BlockEntity be) {
        return be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof ShulkerBoxBlockEntity;
    }

    private static double weight(BlockEntity be, boolean extras) {
        if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity) return 1.0;
        if (be instanceof ShulkerBoxBlockEntity) return 2.0;
        if (!extras) return 0;
        if (be instanceof BeaconBlockEntity) return 6.0;
        if (be instanceof EnderChestBlockEntity) return 0.6;
        if (be instanceof EnchantingTableBlockEntity) return 1.5;
        if (be instanceof SignBlockEntity) return 0.5;
        if (be instanceof HopperBlockEntity) return 0.8;
        if (be instanceof DispenserBlockEntity) return 0.4;
        if (be instanceof BrewingStandBlockEntity) return 0.4;
        if (be instanceof BedBlockEntity) return 0.35;               // ауылда да көп: аз салмақ
        if (be instanceof AbstractFurnaceBlockEntity) return 0.25;
        return 0;
    }

    private static String label(BlockEntity be) {
        if (be instanceof ShulkerBoxBlockEntity) return "шалкер";
        if (be instanceof ChestBlockEntity) return "сундук";
        if (be instanceof BarrelBlockEntity) return "бочка";
        if (be instanceof BeaconBlockEntity) return "маяк";
        if (be instanceof EnderChestBlockEntity) return "эндер сундук";
        if (be instanceof EnchantingTableBlockEntity) return "чарлау үстелі";
        if (be instanceof SignBlockEntity) return "плакат";
        if (be instanceof HopperBlockEntity) return "воронка";
        if (be instanceof DispenserBlockEntity) return "раздатчик";
        if (be instanceof BrewingStandBlockEntity) return "зельеварка";
        if (be instanceof BedBlockEntity) return "төсек";
        if (be instanceof AbstractFurnaceBlockEntity) return "пеш";
        return "басқа";
    }

    private static double entityWeight(Entity e) {
        if (e instanceof ItemFrameEntity) return 0.5;
        if (e instanceof ArmorStandEntity) return 0.6;
        if (e instanceof ChestMinecartEntity) return 1.0;
        if (e instanceof VillagerEntity) return -0.7;               // ауыл белгісі
        return 0;
    }

    // ================================================================ адам жасаған блоктар (жеңіл скан)

    private static Set<Block> art;

    private static Set<Block> art() {
        if (art == null) {
            art = new HashSet<>();
            for (Block b : Registries.BLOCK) {
                String id = Registries.BLOCK.getId(b).getPath();
                if (id.endsWith("_concrete") || id.endsWith("glazed_terracotta") || id.endsWith("_stained_glass")
                        || id.equals("iron_block") || id.equals("gold_block") || id.equals("diamond_block")
                        || id.equals("emerald_block") || id.equals("lapis_block") || id.equals("redstone_block")
                        || id.equals("netherite_block") || id.equals("tnt") || id.equals("observer")
                        || id.equals("piston") || id.equals("sticky_piston") || id.equals("slime_block")
                        || id.equals("honey_block") || id.equals("sea_lantern") || id.equals("end_rod")
                        || id.equals("lodestone") || id.equals("respawn_anchor") || id.equals("note_block")
                        || id.equals("jukebox")) {
                    art.add(b);
                }
            }
        }
        return art;
    }

    private final Map<Long, List<BlockPos>> artCache = new HashMap<>();
    private final Map<Long, Integer> artAt = new HashMap<>();
    private int ticks;

    public void reset() {
        artCache.clear();
        artAt.clear();
    }

    private void scanArt(MinecraftClient mc, int pcx, int pcz, int vd) {
        ticks++;
        int budget = 24;
        for (int ring = 0; ring <= vd && budget > 0; ring++) {
            for (int cx = pcx - ring; cx <= pcx + ring && budget > 0; cx++) {
                for (int cz = pcz - ring; cz <= pcz + ring && budget > 0; cz++) {
                    if (Math.max(Math.abs(cx - pcx), Math.abs(cz - pcz)) != ring) continue;
                    long key = net.minecraft.util.math.ChunkPos.toLong(cx, cz);
                    Integer last = artAt.get(key);
                    if (last != null && ticks - last < 30) continue;       // әр чанк ~30 сканда бір
                    artAt.put(key, ticks);
                    budget--;
                    Chunk ch = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
                    if (!(ch instanceof WorldChunk wc)) { artCache.remove(key); continue; }
                    List<BlockPos> out = new ArrayList<>();
                    ChunkSection[] secs = wc.getSectionArray();
                    int bottom = wc.getBottomY();
                    for (int i = 0; i < secs.length && out.size() < 200; i++) {
                        ChunkSection s = secs[i];
                        if (s == null || s.isEmpty() || !s.hasAny(st -> art().contains(st.getBlock()))) continue;
                        int y0 = bottom + i * 16;
                        for (int x = 0; x < 16; x++) {
                            for (int y = 0; y < 16; y++) {
                                for (int z = 0; z < 16; z++) {
                                    if (art().contains(s.getBlockState(x, y, z).getBlock())) {
                                        out.add(new BlockPos(cx * 16 + x, y0 + y, cz * 16 + z));
                                    }
                                }
                            }
                        }
                    }
                    if (out.isEmpty()) artCache.remove(key); else artCache.put(key, out);
                }
            }
        }
        if (ticks % 20 == 0) {
            artCache.keySet().removeIf(k -> {
                int cx = (int) (k & 0xFFFFFFFFL), cz = (int) (k >>> 32);
                return Math.max(Math.abs(cx - pcx), Math.abs(cz - pcz)) > vd + 2;
            });
            artAt.keySet().removeIf(k -> !artCache.containsKey(k) && ticks - artAt.get(k) > 200);
        }
    }

    // ================================================================ кластерлеу

    private static Cluster home(List<Cluster> list, BlockPos b, boolean create) {
        Vec3d c = Vec3d.ofCenter(b);
        for (Cluster cl : list) {
            if (cl.n > 0 && cl.center().squaredDistanceTo(c) < CLUSTER_R * CLUSTER_R) return cl;
        }
        if (!create) return null;
        Cluster cl = new Cluster();
        list.add(cl);
        return cl;
    }

    /**
     * Жүктелген чанктардан база кластерлерін табады.
     * extras — маяк/төсек/пеш/плакат/рамка т.б. белгілер; blocks — құрылыс блоктары.
     */
    public List<Cluster> find(MinecraftClient mc, ClientPlayerEntity p, boolean extras, boolean blocks) {
        List<Cluster> out = new ArrayList<>();
        int vd = mc.options.getViewDistance().getValue();
        int pcx = p.getBlockPos().getX() >> 4, pcz = p.getBlockPos().getZ() >> 4;
        if (blocks) scanArt(mc, pcx, pcz, vd);

        for (int cx = pcx - vd; cx <= pcx + vd; cx++) {
            for (int cz = pcz - vd; cz <= pcz + vd; cz++) {
                Chunk ch = mc.world.getChunkManager().getChunk(cx, cz, ChunkStatus.FULL, false);
                if (!(ch instanceof WorldChunk wc)) continue;
                for (BlockEntity be : wc.getBlockEntities().values()) {
                    double w = weight(be, extras);
                    if (w <= 0) continue;
                    BlockPos bp = be.getPos();
                    Cluster cl = home(out, bp, true);
                    cl.add(bp, w, label(be));
                    if (isStorage(be)) {
                        cl.storage.add(bp);
                        if (be instanceof ShulkerBoxBlockEntity) cl.shulkers++;
                    }
                }
                if (blocks) {
                    List<BlockPos> list = artCache.getOrDefault(net.minecraft.util.math.ChunkPos.toLong(cx, cz), Collections.emptyList());
                    for (BlockPos b : list) home(out, b, true).addArt(b);
                }
            }
        }
        if (extras) {
            for (Entity e : mc.world.getEntities()) {
                double w = entityWeight(e);
                if (w == 0) continue;
                Cluster cl = home(out, e.getBlockPos(), false);
                if (cl == null) continue;
                cl.ent += w;
                if (w > 0) cl.parts.merge(e instanceof ItemFrameEntity ? "рамка" : e instanceof ArmorStandEntity ? "броня стенді" : "вагонетка", 1, Integer::sum);
            }
        }
        for (Cluster c : out) c.finish();
        return out;
    }

    // ================================================================ сақтау (AutoBase файлымен ортақ)

    /** База координатын файлға қосады (жақын жерде бар болса — қоспайды). true — жаңа жазылды. */
    public static boolean appendSaved(BlockPos pos) {
        try {
            List<String> lines = Files.exists(BASES_FILE) ? new ArrayList<>(Files.readAllLines(BASES_FILE)) : new ArrayList<>();
            for (String line : lines) {
                String[] a = line.trim().split("\\s+");
                if (a.length < 3) continue;
                BlockPos o = new BlockPos(Integer.parseInt(a[0]), Integer.parseInt(a[1]), Integer.parseInt(a[2]));
                if (o.getSquaredDistance(pos) < 40 * 40) return false;
            }
            lines.add(pos.getX() + " " + pos.getY() + " " + pos.getZ());
            Files.write(BASES_FILE, lines);
            return true;
        } catch (IOException | NumberFormatException e) {
            return false;
        }
    }
}
