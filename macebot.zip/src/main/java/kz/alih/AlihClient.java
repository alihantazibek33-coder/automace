package kz.alih;

import kz.alih.gui.MenuScreen;
import kz.alih.modules.AutoAim;
import kz.alih.modules.AutoAnchor;
import kz.alih.modules.AutoBow;
import kz.alih.modules.AutoMark;
import kz.alih.modules.AutoCart;
import kz.alih.modules.AutoCrystal;
import kz.alih.modules.AutoShieldBreak;
import kz.alih.modules.AutoUhc;
import kz.alih.modules.ElytraMace;
import kz.alih.modules.TriggerBot18;
import kz.alih.modules.TriggerBot19;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class AlihClient implements ClientModInitializer {
    public static final List<Module> MODULES = new ArrayList<>();
    public static int menuKey = GLFW.GLFW_KEY_RIGHT_SHIFT;

    private boolean menuWasDown;

    @Override
    public void onInitializeClient() {
        MODULES.add(new ElytraMace());
        MODULES.add(new AutoAnchor());
        MODULES.add(new TriggerBot19());
        MODULES.add(new TriggerBot18());
        MODULES.add(new AutoCrystal());
        MODULES.add(new AutoShieldBreak());
        MODULES.add(new AutoCart());
        MODULES.add(new AutoUhc());
        MODULES.add(new AutoAim());
        MODULES.add(new AutoBow());
        MODULES.add(new AutoMark());
        Config.load();

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        ClientSendMessageEvents.ALLOW_CHAT.register(this::onChat);

        // Shift + ПКМ: АвтоЭлитраМейс үшін нысананы белгілеу / алу
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (player != mc.player || hand != Hand.MAIN_HAND) return ActionResult.PASS;
            if (!player.isSneaking() || !Util.validTarget(mc.player, entity, true)) return ActionResult.PASS;
            if (entity.getUuid().equals(ElytraMace.lockedId)) {
                ElytraMace.lockedId = null;
                Util.msg("Нысана алынды. Енді ең жақын моб/игрокты ұрады");
            } else {
                ElytraMace.lockedId = entity.getUuid();
                Util.msg("Нысана белгіленді: " + entity.getName().getString() + " (тек соны ұрады)");
            }
            return ActionResult.SUCCESS;
        });

        // АвтоОтметка үшін: соңғы басқан блок (сундук)
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (player == MinecraftClient.getInstance().player) AutoMark.lastUsed = hit.getBlockPos();
            return ActionResult.PASS;
        });

        // АвтоПрицел үшін: соңғы ұрған нысананы есте сақтау
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (player == MinecraftClient.getInstance().player && entity instanceof LivingEntity) {
                AutoAim.lastHit = entity.getUuid();
            }
            return ActionResult.PASS;
        });
    }

    private void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) {
            for (Module m : MODULES) m.enabled = false;
            return;
        }
        Util.trackVelocities(mc);

        if (mc.currentScreen == null) {
            boolean md = Util.isDown(menuKey);
            if (md && !menuWasDown) mc.setScreen(new MenuScreen());
            menuWasDown = md;
            for (Module m : MODULES) {
                boolean d = Util.isDown(m.key);
                if (d && !m.wasDown && !m.keyPressed(mc, false)) m.toggle();
                m.wasDown = d;
            }
        } else {
            menuWasDown = true;
            boolean inv = mc.currentScreen instanceof HandledScreen<?>;
            for (Module m : MODULES) {
                boolean d = Util.isDown(m.key);
                if (inv && d && !m.wasDown) m.keyPressed(mc, true);
                m.wasDown = d;
            }
        }

        for (Module m : MODULES) {
            try {
                m.alwaysTick(mc, p);
            } catch (Exception ignored) {
            }
        }

        for (Module m : MODULES) {
            if (!m.enabled) continue;
            try {
                m.onTick(mc, p);
            } catch (Exception e) {
                m.setEnabled(false);
                Util.msg(m.name + " қатемен өшірілді: " + e.getClass().getSimpleName());
            }
        }
    }

    private boolean onChat(String message) {
        String m = message.trim();
        if (!m.toLowerCase().startsWith(".alih")) return true;
        String[] a = m.split("\\s+");

        if (a.length >= 2 && a[1].equalsIgnoreCase("ignore")) {
            String sub = a.length >= 3 ? a[2].toLowerCase() : "list";
            if (sub.equals("add") && a.length >= 4) {
                Util.IGNORED.add(Util.norm(a[3]));
                Config.save();
                Util.msg("Тізімге қосылды: " + a[3]);
            } else if (sub.equals("remove") && a.length >= 4) {
                Util.msg(Util.IGNORED.remove(Util.norm(a[3])) ? "Тізімнен алынды: " + a[3] : "Тізімде жоқ: " + a[3]);
                Config.save();
            } else {
                Util.msg("Ignore тізімі: " + (Util.IGNORED.isEmpty() ? "бос" : String.join(", ", Util.IGNORED))
                        + "  (.alih ignore add/remove <ник>)");
            }
        } else if (a.length >= 2 && a[1].equalsIgnoreCase("mark")) {
            for (Module mod : MODULES) {
                if (mod instanceof AutoMark am) am.clear();
            }
            Util.msg("АвтоОтметка тазаланды");
        } else if (a.length >= 2 && a[1].equalsIgnoreCase("clear")) {
            ElytraMace.lockedId = null;
            Util.msg("Белгіленген нысана тазаланды");
        } else {
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.execute(() -> mc.setScreen(new MenuScreen()));
        }
        return false;
    }
}
